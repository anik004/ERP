import os
import sys
from sys import *
import paramiko
from paramiko import *
import re

#---------------------------- Function to check the Availability of the database -------------------------------
def availability(hostname, username, password, user, instance, green, scriptloc, mailfile):
	a = 0
	dbname = ''
	if not dbname:
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		dbname = stdout.readlines()

	mail = open(mailfile,"a")
	mail.write("<table style=\"widht:100%\">\n")
	mail.write("  <tr>\n")

	port = 22

	transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/count.txt"
        remote = "/tmp/count.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countI.txt"
        remote = "/tmp/countI.txt"
        sftp.put(local, remote)

	for name in dbname:
		if name == "SYSTEMDB":

			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/count.txt'\" | sudo bash"
			print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			counter = (stdout.read()).strip()

			if int(counter) == 3:
				green = green + 1
				a = a + 1
			elif int(counter) == 0:
				green = green - 1
				a = a - 1

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " \"'\"select host,service_name,detail,active_status from m_services where service_name='\"\\\'nameserver\\\'\"'\"'\"'\" | sudo bash"
			print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			cName = stdout.readlines()

			mail.write("<tr>\n")
			mail.write("<td colspan=\"4\"><font color='blue'> Availablity of " + name + " Database</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Service Name</th>\n")
			mail.write("     <th>Details</th>\n")
			mail.write("     <th>Active Status</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")
			i = 0

			for line in cName:
				if line == "YES":
					mail.write("<td bgcolor='LimeGreen'>" + line + "</td>\n")
				elif line == "NO":
					mail.write("<td bgcolor='red'>" + line + "</td>\n")
				elif line == "STARTING":
					mail.write("<td bgcolor='yellow'>" + line + "</td>\n")
				elif line == "STOPPING":
					mail.write("<td bgcolor='yellow'>" + line + "</td>\n")
				else:
					mail.write("<td>" + line + "</td>\n")
				i = i + 1
				rem = i % 4
				if rem == 0:
					mail.write("<tr>\n")
					mail.write("</tr>\n")
		else:
                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countI.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        counter = (stdout.read()).strip()

			if counter == 2:
				green = green + 1
				a = a + 1
			elif counter == 1:
				green = green - 1
				a = a + 1
			else:
				green = green - 2
				a = a - 2

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name  + " \"'\"select host,service_name,detail,active_status from m_services where service_name in ('\"\\\'indexserver\\\')\"'\"'\"'\" | sudo bash"
			print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			cNameI = stdout.readlines()

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " \"'\"select host,service_name,detail,active_status from m_services where service_name in ('\"\\\'xsengine\\\')\"'\"'\"'\" | sudo bash"
			print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			cNameX = stdout.readlines()

			mail.write("<tr>\n")
			mail.write("<td colspan=\"4\"><font color='blue'> Availablity of " + name + " Database</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Service Name</th>\n")
			mail.write("     <th>Details</th>\n")
			mail.write("     <th>Active Status</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for lineI in cNameI:
				if lineI == "YES":
					mail.write("<td bgcolor='LimeGreen'>" + lineI + "</td>\n")
				elif lineI == "NO":
					mail.write("<td bgcolor='red'>" + lineI + "</td>\n") 
				elif lineI == "STARTING":
					mail.write("<td bgcolor='yellow'>" + lineI + "</td>\n")
				elif lineI == "STOPPING":
					mail.write("<td bgcolor='yellow'>" + lineI + "</td>\n")
				else:
					mail.write("<td>" + lineI + "</td>\n")
			mail.write(" </tr>\n")
			mail.write(" <tr>\n")

			for lineX in cNameX:
				if lineX == "YES":
					mail.write("<td bgcolor='LimeGreen'>" + lineX + "</td>\n")
				elif lineX == "NO":
					mail.write("<td bgcolor='red'>" + lineX + "</td>\n")
				elif lineX == "STARTING":
					mail.write("<td bgcolor='yellow'>" + lineX + "</td>\n")
				elif lineX == "STOPPING":
					mail.write("<td bgcolor='yellow'>" + lineX + "</td>\n")
				else:
					mail.write("<td>" + lineX + "</td>\n")

		mail.write("</tr>\n")

	mail.write("  </tr>\n")
	mail.write("</table>\n")
	if a == 5:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important ><font size=\"5\"><b>Green: All the DB Services are up and running</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>Please check if alls the DB are up and running</b></font></p>\n")
	mail.close()
	sftp.close()
	transport.close()
	return green

#------------------------------------------ Function to check the Disk Usage ----------------------------
def diskUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):
	d = 0
	dbname = ''
	if not dbname:
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

	mail = open(mailfile,"a")
	mail.write("<table style=\"widht:100%\">\n")
	mail.write("<tr>\n")

	port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/countDiskData.txt"
        remote = "/tmp/countDiskData.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countDiskLog.txt"
        remote = "/tmp/countDiskLog.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countDiskTrace.txt"
        remote = "/tmp/countDiskTrace.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceTraceName.txt"
        remote = "/tmp/diskSpaceTraceName.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceDataName.txt"
        remote = "/tmp/diskSpaceDataName.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceLogName.txt"
        remote = "/tmp/diskSpaceLogName.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceLogIndex.txt"
        remote = "/tmp/diskSpaceLogIndex.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceDataIndex.txt"
        remote = "/tmp/diskSpaceDataIndex.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceTraceIndex.txt"
	remote = "/tmp/diskSpaceTraceIndex.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceTraceXS.txt"
        remote = "/tmp/diskSpaceTraceXS.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceLogXS.txt"
        remote = "/tmp/diskSpaceLogXS.txt"
        sftp.put(local, remote)

	local = scriptloc + "/diskSpaceDataXS.txt"
        remote = "/tmp/diskSpaceDataXS.txt"
        sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countDiskData.txt'\" | sudo bash"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		counter1 = stdout.readlines()

		command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countDiskLog.txt'\" | sudo bash"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		counter2 = stdout.readlines()

		command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countDiskTrace.txt'\" | sudo bash"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		counter3 = stdout.readlines()

		for count1 in counter1:
			if re.match(r"[0-9]", str(count1)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-9][0-9]", str(count1)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-6][0-9][0-9]", str(count1)):
				green = green + 1
				d = d + 1
			elif re.match(r"[7][0-6][0-9]", str(count1)):
				green = green + 1
				d = d + 1
			elif re.match(r"[7][7-9][0-9]", str(count1)):
				green = green - 1
				d = d - 1
			elif re.match(r"[8-9][0-9][0-9]", str(count1)):
				green = green - 1
				d = d - 1
			elif re.match(r"[1][0-1][0-4][0-9]", str(count1)):
				green = green - 1
				d = d - 1
			elif re.match(r"[1][1][5-9][0-9]", str(count1)):
				green = green - 2
				d = d - 2
			elif re.match(r"[1][2-5][0-3][0-4]", str(count1)):
				green = green - 2
				d = d - 2

		for count2 in counter2:
			if re.match(r"[0-9]", str(count2)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-9][0-9]", str(count2)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-3][0-4][0-9]", str(count2)):
				green = green + 1
				d = d + 1
			elif re.match(r"[3][5-9][0-9]", str(count2)):
				green = green - 1
				d = d - 1
			elif re.match(r"[4][0-9][0-9]", str(count2)):
				green = green - 1
				d = d - 1
			elif re.match(r"[5][0][0-9]", str(count2)):
				green = green - 2
				d = d - 2
			elif re.match(r"[5][1][0-1]", str(count2)):
				green = green - 2
				d = d - 2

		for count3 in counter3:
			if re.match(r"0", str(count3)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-9]", str(count3)):
				green = green + 1
				d = d + 1
			elif re.match(r"[0-9][0-9]", str(count3)):
				green = green + 1
				d = d + 1
			elif re.match(r"[1][0-9][0-9]", str(count3)):
				green = green + 1
				d = d + 1
			elif re.match(r"[1][0-4][0-9]", str(count3)):
				green = green + 1
				d = d + 1
			elif re.match(r"[1][5-9][0-9]", str(count3)):
				green = green - 1
				d = d - 1
			elif re.match(r"[2][0-4][0-9]", str(count3)):
				green = green - 2
				d = d - 2
			elif re.match(r"[2][4][0-9]", str(count3)):
				green = green - 2
				d = d - 2
			elif re.match(r"[2][5][0-6]", str(count3)):
				green = green - 2
				d = d - 2
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceTraceName.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                tName = stdout.readlines()

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceDataName.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dName = stdout.readlines()

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceLogName.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                lName = stdout.readlines()

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceLogIndex.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                lindex = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceDataIndex.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dindex = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceTraceIndex.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                tndex = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceTraceXS.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                txs = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceLogXS.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                lxs = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/diskSpaceDataXS.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dxs = stdout.readlines()

		if name == "SYSTEMDB"
			mail.write("<tr>\n")
			mail.write("<td colspan=\"6\"><font color='blue'> Disk Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Service Name</th>\n")
			mail.write("     <th>Usage</th>\n")
			mail.write("     <th>Used Disk Space (GB) </th>\n")
			mail.write("     <th>Total Disk Usage (GB) </th>\n")
			mail.write("     <th>Total Disk Size (GB) </th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")
			mail.write("<tr>\n")
			
			for dline in dName:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-7][0-6][0-7]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dline in lName:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-3][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[3][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[4][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[5][0][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[5][1][0-1]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for tline in tName:
				if re.match(r"[0-9]", str(tline)):
					mail.write("<td bgcolor='LimeGreen'>" + tline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(tline)):
					mail.write("<td bgcolor='LimeGreen'>" + tline + "</td>\n")
				elif re.match(r"[1][0-9][0-9]", str(tline)):
					mail.write("<td bgcolor='LimeGreen'>" + tline + "</td>\n")
				elif re.match(r"[1][0-4][0-9]", str(tline)):
					mail.write("<td bgcolor='LimeGreen'>" + tline + "</td>\n")
				elif re.match(r"[1][5-9][0-9]", str(tline)):
					mail.write("<td bgcolor='yellow'>" + tline + "</td>\n")
				elif re.match(r"[2][0-4][0-9]", str(tline)):
					mail.write("<td bgcolor='red'>" + tline + "</td>\n")
				elif re.match(r"[2][4][0-9]", str(tline)):
					mail.write("<td bgcolor='red'>" + tline + "</td>\n")
				elif re.match(r"[2][5][0-5]", str(tline)):
					mail.write("<td bgcolor='red'>" + tline + "</td>\n")
				else:
					mail.write("<td>" + tline + "</td>\n")

			mail.write("</tr>\n")

		else:
			mail.write("<tr>\n")
			mail.write("<td colspan=\"6\"><font color='blue'> Disk Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Service Name</th>\n")
			mail.write("     <th>Usage</th>\n")
			mail.write("     <th>Used Disk Space (GB) </th>\n")
			mail.write("     <th>Total Disk Usage (GB) </th>\n")
			mail.write("     <th>Total Disk Size (GB) </th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")
			mail.write("<tr>\n")
			mail.write("<tr>\n")

			for dline in lindex:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-3][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[3][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[4][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[5][0][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[5][1][0-1]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dline in dindex:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-7][0-6][0-7]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dline in tndex:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[2][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[2][4][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[2][5][0-5]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")

			for dline in lxs:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline))
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-3][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[3][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[4][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[5][0][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[5][1][0-1]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dline in dxs:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", strs(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-7][0-6][0-7]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dline in txs:
				if re.match(r"[0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][0-9][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='LimeGreen'>" + dline + "</td>\n")
				elif re.match(r"[1][5-9][0-9]", str(dline)):
					mail.write("<td bgcolor='yellow'>" + dline + "</td>\n")
				elif re.match(r"[2][0-4][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[2][4][0-9]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				elif re.match(r"[2][5][0-5]", str(dline)):
					mail.write("<td bgcolor='red'>" + dline + "</td>\n")
				else:
					mail.write("<td>" + dline + "</td>\n")
			mail.write("</tr>\n")
	mail.write("</tr>\n")
	mail.write("</table>\n")
	if d == 59:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: Disk Usage of HANA DB are under threshold</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>PLease check disk usage for HANA DB</b></font></p>\n")

	sftp.close()
	transport.close()
	mail.close()
	return green

#-----------------------------------------------Function to check the volume usage ------------------------------
def volumeUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):
	v = 0
	dbname = ''
	if not dbname:
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile = scriptloc + "/errorSection/VolumeUsageError_" + name + ".txt"
        error = open(errorfile, "w+")

	local = scriptloc + "/volumeSize.txt"
        remote = "/tmp/volumeSize.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeDataNam.txt"
        remote = "/tmp/countVolumeDataNam.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeLogNam.txt"
        remote = "/tmp/countVolumeLogNam.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeDataInd.txt"
        remote = "/tmp/countVolumeDataInd.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeLogInd.txt"
        remote = "/tmp/countVolumeLogInd.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeDataxs.txt"
        remote = "/tmp/countVolumeDataxs.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countVolumeLogxs.txt"
        remote = "/tmp/countVolumeLogxs.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeN.txt"
	remote = "/tmp/volumeSizeN.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeI.txt"
        remote = "/tmp/volumeSizeI.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeX.txt"
        remote = "/tmp/volumeSizeX.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeNL.txt"
        remote = "/tmp/volumeSizeNL.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeIL.txt"
	remote = "/tmp/volumeSizeIL.txt"
        sftp.put(local, remote)

	local = scriptloc + "/volumeSizeXL.txt"
        remote = "/tmp/volumeSizeXL.txt"
        sftp.put(local, remote)

	for name in dbname:

		if name == "SYSTEMDB":
			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataNam.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count1 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogNam.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count2 = stdout.readlines()

			for count in count1:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-6][0-9][0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[7][0-6][0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
					v = v - 1
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
					print command
					stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
					out = (stdout.read()).strip()
					error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
					v = v - 1
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
					v = v - 1
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
					v = v - 2
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count2:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re. match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-3][0-4][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[3][5-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

		elif name == "BFC":

			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataInd.txt'\" | sudo bash"
			print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			count3 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count4 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count5 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count6 = stdout.readlines()

			for count in count3:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-6][0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][0-6][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count4:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-3][0-4][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[3][5-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count5:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-6][0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][0-6][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count6:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-3][0-4][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[3][5-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

		elif name == "MFC":

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count3 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count4 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count5 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count6 = stdout.readlines()

			for count in count3:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-6][0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][0-6][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count4:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-3][0-4][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[3][5-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count5:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-6][0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][0-6][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count6:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-3][0-4][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[3][5-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

		elif name == "FIM":

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count3 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count4 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count5 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count6 = stdout.readlines()

			for count in count3:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-7][0-6][0-7]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count4:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-2][0-5][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[2][6-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[3-4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count5:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-7][0-6][0-7]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count6:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-2][0-5][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[2][6-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[3-4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

		elif name == "BIP":

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count3 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogInd.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count4 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeDataxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count5 = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countVolumeLogxs.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count6 = stdout.readlines()

			for count in count3:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-7][0-6][0-7]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count4:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-2][0-5][0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[2][6-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[3-4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count5:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-7][0-6][0-7]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[7][7-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[8-9][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][0-1][0-4][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][1][5-9][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[1][2-5][0-3][0-4]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count6:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					v = v + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[0-2][0-5][0-9]", str(count)):
					green = green + 1
                                        v = v + 1
				elif re.match(r"[2][6-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
					error.write(out)
				elif re.match(r"[3-4][0-9][0-9]", str(count)):
					green = green - 1
                                        v = v - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][0][0-9]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[5][1][0-1]", str(count)):
					green = green - 2
                                        v = v - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/volumeSize.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeN.txt'\" | sudo bash"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		nname = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeI.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                iName = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeX.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                xName = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeNL.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                nlname = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeIL.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                ilname = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/volumeSizeXL.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                xlname = stdout.readlines()

		if name == "SYSTEMDB":
			mail.write("<tr>\n")
			mail.write("<td colspan=\"9\"><font color='blue'> Volume Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Port</th>\n")
			mail.write("     <th>Service </th>\n")
			mail.write("     <th>Usage </th>\n")
			mail.write("     <th>Path</th>\n")
			mail.write("     <th>Data Size (GB)</th>\n")
			mail.write("     <th>Log Size (GB) </th>\n")
			mail.write("     <th>Used Size (GB) </th>\n")
			mail.write("     <th>Total Size (GB)</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for dname in nname:
				if re.match(r"[0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dbname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				else:
					mail.write("<td>" + dname + "</td>\n")

			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for dname in nlname:
				if re.match(r"[0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-3][0-4][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[3][5-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[4][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[5][0][0-9]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				elif re.match(r"[5][1][0-1]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				else:
					mail.write("<td>" + dname + "</td>\n")

			mail.write("  </tr>\n")

		else:

			mail.write("<tr>\n")
			mail.write("<td colspan=\"9\"><font color='blue'> Volume Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Port</th>\n")
			mail.write("     <th>Service </th>\n")
			mail.write("     <th>Usage </th>\n")
			mail.write("     <th>Path</th>\n")
			mail.write("     <th>Data Size (GB)</th>\n")
			mail.write("     <th>Log Size (GB) </th>\n")
			mail.write("     <th>Used Size (GB) </th>\n")
			mail.write("     <th>Total Size (GB)</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for dname in iName:
				if re.match(r"[0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				else:
                                        mail.write("<td>" + dname + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dname in ilname:
				if re.match(r"[0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[0-9][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-3][0-4][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[3][5-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[4][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[5][0][0-9]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				elif re.match(r"[5][1][0-1]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
                                else:
                                        mail.write("<td>" + dname + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for dname in xName:
				if re.match(r"[0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[0-9][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[0-6][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][0-6][0-9]", str(dname)):
					mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
				elif re.match(r"[7][7-9][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[8-9][0-9][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][0-1][0-4][0-9]", str(dname)):
					mail.write("<td bgcolor='yellow'>" + dname + "</td>\n")
				elif re.match(r"[1][1][5-9][0-9]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
				elif re.match(r"[1][2-5][0-3][0-4]", str(dname)):
					mail.write("<td bgcolor='red'>" + dname + "</td>\n")
                                else:
                                        mail.write("<td>" + dname + "</td>\n")

			mail.write("</tr>\n")
                        mail.write("<tr>\n")

			for dname in xlname:
                                if re.match(r"[0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[0-9][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[0-3][0-4][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[3][5-9][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[4][0-9][0-9]", str(dname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + dname + "</td>\n")
                                elif re.match(r"[5][0][0-9]", str(dname)):
                                        mail.write("<td bgcolor='red'>" + dname + "</td>\n")
                                elif re.match(r"[5][1][0-1]", str(dname)):
                                        mail.write("<td bgcolor='red'>" + dname + "</td>\n")
                                else:
                                        mail.write("<td>" + dname + "</td>\n")

			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	if v == 18:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: Volume Usage of HANA DB are under threshold</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>PLease check Volume usage for HANA DB</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#----------------------------------------------Function to check the service memory usage ---------------------------------
def serviceMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):
	m = 0
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile = scriptloc + "/errorSection/MemoryUsageError_" + name + ".txt"
        error = open(errorfile, "w+")

	local = scriptloc + "/countNameServerMem.txt"
        remote = "/tmp/countNameServerMem.txt"
        sftp.put(local, remote)

	local = scriptloc + "/nameservermem.txt"
        remote = "/tmp/nameservermem.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memName.txt"
        remote = "/tmp/memName.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memCompile.txt"
        remote = "/tmp/memCompile.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memPreProcessor.txt"
        remote = "/tmp/memPreProcessor.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memDaemon.txt"
        remote = "/tmp/memDaemon.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memWebDispatcher.txt"
        remote = "/tmp/memWebDispatcher.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countIndMem.txt"
        remote = "/tmp/countIndMem.txt"
        sftp.put(local,remote)

	local = scriptloc + "/countXSMem.txt"
        remote = "/tmp/countXSMem.txt"
	sftp.put(local, remote)

	local = scriptloc + "/indexServerMem.txt"
        remote = "/tmp/indexServerMem.txt"
	sftp.put(local, remote)

	local = scriptloc + "/memIndex.txt"
        remote = "/tmp/memIndex.txt"
        sftp.put(local, remote)

	local = scriptloc + "/memXS.txt"
        remote = "/tmp/memXS.txt"
        sftp.put(local, remote)

	for name in dbname:

		if name == "SYSTEMDB":
			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countNameServerMem.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count1 = stdout.readlines() 

			for count in count1:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					m = m + 1
				elif re.match(r"[0-6][0-9]", str(count)):
					green = green + 1
					m = m + 1
				elif re.match(r"[7-8][0-9]", str(count)):
					green = green - 1
					m = m - 1

					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/nameservermem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[9][0-9]", str(count)):
					green = green - 2
					m = m - 2

                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/nameservermem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memName.txt'\" | sudo bash"
	                print command
        	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                	memName = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memCompile.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        memCompile = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memPreProcessor.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        memPreProcessor = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memDaemon.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        memDaemon = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memWebDispatcher.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        memWebDispatcher = stdout.readlines()

			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'> Service Memory Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Port</th>\n")
			mail.write("     <th>Service </th>\n")
			mail.write("     <th>Used Memory (GB) </th>\n")
			mail.write("     <th>Allocated Memory (GB) </th>\n")
			mail.write("  </tr>\n")

			i = 0
			mail.write("<tr>\n")

			for mname in memName:
				if re.match(r"[0-9]", str(mname)):
					mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
				elif re.match(r"[0-6][0-9]", str(mname)):
					mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
				elif re.match(r"[8][0-9]", str(mname)):
					mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
				elif re.match(r"[9][0-5]", str(mname)):
					mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
				elif re.match(r"[9][5-9]", str(mname)):
					mail.write("<td bgcolor='red'>" + mname + "</td>\n")
				else:
					mail.write("<td>" + mname + "</td>\n")

				i = i + 1
				rem = i % 5
				if rem == 0:
					mail.write("<tr>\n")
					mail.write("</tr>\n")

			mail.write("</tr>\n")
			j = 0
			mail.write("<tr>\n")

			for mname in memCompile:
				if re.match(r"[0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[0-6][0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[8][0-9]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][0-5]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][5-9]", str(mname)):
                                        mail.write("<td bgcolor='red'>" + mname + "</td>\n")
                                else:
                                        mail.write("<td>" + mname + "</td>\n")

                                j = j + 1
                                rem = j % 5
                                if rem == 0:
                                        mail.write("<tr>\n")
                                        mail.write("</tr>\n")

                        mail.write("</tr>\n")
                        k = 0
                        mail.write("<tr>\n")

			for mname in memPreProcessor:
                                if re.match(r"[0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[0-6][0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[8][0-9]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][0-5]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][5-9]", str(mname)):
                                        mail.write("<td bgcolor='red'>" + mname + "</td>\n")
                                else:
                                        mail.write("<td>" + mname + "</td>\n")

                                k = k + 1
                                rem = k % 5
                                if rem == 0:
                                        mail.write("<tr>\n")
                                        mail.write("</tr>\n")

                        mail.write("</tr>\n")
                        l = 0
                        mail.write("<tr>\n")

			for mname in memWebDispatcher:
                                if re.match(r"[0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[0-6][0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[8][0-9]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][0-5]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[9][5-9]", str(mname)):
                                        mail.write("<td bgcolor='red'>" + mname + "</td>\n")
                                else:
                                        mail.write("<td>" + mname + "</td>\n")

                                l = l + 1
                                rem = l % 5
                                if rem == 0:
                                        mail.write("<tr>\n")
                                        mail.write("</tr>\n")

                        mail.write("</tr>\n")

		else:

			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countIndMem.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count1 = stdout.readlines()

			command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countXSMem.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count2 = stdout.readlines()

			for count in count1:
				if re.match(r"[0-9]", str(count)):
					green = green + 1
					m = m + 1
				elif re.match(r"[0-9][0-9]", str(count)):
					green = green + 1
					m = m + 1
				elif re.match(r"[0-2][0-9][0-9]", str(count)):
					green = green + 1
                                        m = m + 1
				elif re.match(r"[3][0-9][0-9]", str(count)):
					green = green - 1
					m = m - 1
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/indexServerMem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
				elif re.match(r"[4-5][0-9][0-9]", str(count)):
					green = green - 2
					m = m - 2
					command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/indexServerMem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			for count in count2:
				if re.match(r"[0-9]", str(count)):
                                        green = green + 1
                                        m = m + 1
                                elif re.match(r"[0-9][0-9]", str(count)):
                                        green = green + 1
                                        m = m + 1
                                elif re.match(r"[0-2][0-9][0-9]", str(count)):
                                        green = green + 1
                                        m = m + 1
                                elif re.match(r"[3][0-9][0-9]", str(count)):
                                        green = green - 1
                                        m = m - 1
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/indexServerMem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)
                                elif re.match(r"[4-5][0-9][0-9]", str(count)):
                                        green = green - 2
                                        m = m - 2
                                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/indexServerMem.txt'\" | sudo bash"
                                        print command
                                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                        out = (stdout.read()).strip()
                                        error.write(out)

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memIndex.txt'\" | sudo bash"
	                print command
        	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                	memIndex = stdout.readlines()

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/memXS.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        memXS = stdout.readlines()

			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'> Service Memory Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Port</th>\n")
			mail.write("     <th>Service </th>\n")
			mail.write("     <th>Used Memory (GB) </th>\n")
			mail.write("     <th>Allocated Memory (GB) </th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for mname in memIndex:
				if re.match(r"[0-9]", str(mname)):
					mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
				elif re.match(r"[0-9][0-9]", str(mname)):
					mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
				elif re.match(r"[0-2][0-9][0-9]", str(mname)):
					mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
				elif re.match(r"[3][0-9][0-9]", str(mname)):
					mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
				elif re.match(r"[4-5][0-9][0-9]", str(mname)):
					mail.write("<td bgcolor='red'>" + mname + "</td>\n")
				else:
					mail.write("<td>" + mname + "</td>\n")

			mail.write("</tr>\n")
			mail.write("<tr>\n")

			for mname in memXS:
				if re.match(r"[0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[0-9][0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[0-2][0-9][0-9]", str(mname)):
                                        mail.write("<td bgcolor='LimeGreen'>" + mname + "</td>\n")
                                elif re.match(r"[3][0-9][0-9]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                elif re.match(r"[4-5][0-9][0-9]", str(mname)):
                                        mail.write("<td bgcolor='yellow'>" + mname + "</td>\n")
                                else:
                                        mail.write("<td>" + mname + "</td>\n")

			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	if m == 11:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: Service memory Usage of HANA DB are under threshold</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>Please Service memory Usage for HANA DB</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#------------------------------------------------Function to check the instance memory usage ----------------------------
def instanceMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):
	dbname = ''
	if not dbname:
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/hanaUsedMemory.txt"
        remote = "/tmp/hanaUsedMemory.txt"
	sftp.put(local, remote)

	local = scriptloc + "/hanaUsedMemoryName.txt"
        remote = "/tmp/hanaUsedMemoryName.txt"
	sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/hanaUsedMemory.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                memInstance = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/hanaUsedMemoryName.txt.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                memInstanceName = stdout.readlines()

		if name == "SYSTEMDB":
			mail.write("<tr>\n")
			mail.write("<td colspan=\"3\"><font color='blue'> Instance Memory Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Used Memory (GB)</th>\n")
			mail.write("     <th>Allocation Limit (GB)</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for mname in memInstanceName:
				mail.write("<td>" + mname + "</td>\n")

			mail.write("</tr>\n")

		else:
			mail.write("<tr>\n")
                        mail.write("<td colspan=\"3\"><font color='blue'> Instance Memory Usage for " + name + "</font></td>\n")
                        mail.write("</tr>\n")
                        mail.write("  <tr>\n")
                        mail.write("     <th>Hostname</th>\n")
                        mail.write("     <th>Used Memory (GB)</th>\n")
                        mail.write("     <th>Allocation Limit (GB)</th>\n")
                        mail.write("  </tr>\n")
                        mail.write("<tr>\n")

                        for mname in memInstance:
                                mail.write("<td>" + mname + "</td>\n")

                        mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#-----------------------------------------------Function to check peak memory usage --------------------------------
def peakMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/peakMemoryUsed.txt"
        remote = "/tmp/peakMemoryUsed.txt"
        sftp.put(local, remote)

	local = scriptloc + "/peakMemoryIndex.txt"
        remote = "/tmp/peakMemoryIndex.txt"
        sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/peakMemoryUsed.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                memPeak = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/peakMemoryIndex.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                memPeakIndx = stdout.readlines()

		if name == "SYSTEMDB":

			mail.write("<tr>\n")
			mail.write("<td colspan=\"3\"><font color='blue'> Instance Memory Usage for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Hostname</th>\n")
			mail.write("     <th>Server Time</th>\n")
			mail.write("     <th>Peak used (GB)</th>\n")
			mail.write("  </tr>\n")
			mail.write("<tr>\n")

			for mname in memPeak:
				mail.write("<td>" + mname + "</td>\n")
			mail.write("</tr>\n")

		else:

			mail.write("<tr>\n")
                        mail.write("<td colspan=\"3\"><font color='blue'> Instance Memory Usage for " + name + "</font></td>\n")
                        mail.write("</tr>\n")
                        mail.write("  <tr>\n")
                        mail.write("     <th>Hostname</th>\n")
                        mail.write("     <th>Server Time</th>\n")
                        mail.write("     <th>Peak used (GB)</th>\n")
                        mail.write("  </tr>\n")
                        mail.write("<tr>\n")

                        for mname in memPeakIndx:
                                mail.write("<td>" + mname + "</td>\n")
                        mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#--------------------------------------Function to check the resident memory usage ------------------------------
def residentMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile):

	mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/residentMemory.txt"
	remote = "/tmp/residentMemory.txt"
	sftp.put(local, remote)
	command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -u SYSTEM -I /tmp/residentMemory.txt'\" | sudo bash"
        print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        memResident = stdout.readlines()

	mail.write("  <tr>\n")
	mail.write("     <th>Hostname</th>\n")
	mail.write("     <th>Physical Memory (GB)</th>\n")
	mail.write("     <th>Resident (GB)</th>\n")
	mail.write("  </tr>\n")

	i = 0

	mail.write("<tr>\n")

	for mname in memResident:

		mail.write("<td>" + mname + "</td>\n")
		i = i + 1
		rem = i % 3
		if rem == 0:
			mail.write("<tr>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#----------------------------------------------Function to check the cpu utilization -------------------------------
def cpuUtilization(hostname, username, password, user, instance, green, scriptloc, mailfile):
	c = 0
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/countCPU2Days.txt"
        remote = "/tmp/countCPU2Days.txt"
        sftp.put(local, remote)

	local = scriptloc + "/cpuUtilization2days.txt"
        remote = "/tmp/cpuUtilization2days.txt"
        sftp.put(local, remote)

	errorfile = scriptloc + "/errorSection/CPUUsageError_" + name + ".txt"
        error = open(errorfile, "w+")

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xjaC -i " + instance + " -U m" + name + " -I /tmp/countCPU2Days.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                count = (stdout.read()).strip()

		command = "echo " + count + " | cut -c1-4"
		print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                value1 = (stdout.read()).strip()
		command = "echo " + count + " | cut -c6-9"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                value2 = (stdout.read()).strip()
		command = "echo \"scale=2;(" + value1 + " + " + value2 + ") / 2\" | bc"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                counter = (stdout.read()).strip()
		command = "echo \"" + counter + " < 10.00 \"| bc"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                comp1 = (stdout.read()).strip()
		command = "echo \"" + counter + " > 10.00 \"| bc"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                comp2 = (stdout.read()).strip()
		command = "echo \"" + counter + " < 20.00 \"| bc"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                comp3 = (stdout.read()).strip()

		if comp1 == 1:
			green = green + 1
			c = c + 1
		elif comp2 == 1 and comp3 == 1:
			green = green - 1
			c = c - 1
			command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/cpuUtilization2days.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = (stdout.read()).strip()
                        error.write(out)
		else:
			green = green - 2
                        c = c - 2
                        command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/cpuUtilization2days.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = (stdout.read()).strip()
                        error.write(out)

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/cpuUtilization2days.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                nCPU = stdout.readlines()

		mail.write("<tr>\n")
		mail.write("<td colspan=\"7\"><font color='blue'> CPU utilization for " + name + "</font></td>\n")
		mail.write("</tr>\n")
		mail.write("  <tr>\n")
		mail.write("     <th>Snapshot time</th>\n")
		mail.write("     <th>Hostname</th>\n")
		mail.write("     <th>CPU Busy (%)</th>\n")
		mail.write("     <th>Avg No of CPUs busy with user activities</th>\n")
		mail.write("     <th>Avg No of CPUs busy with system activities</th>\n")
		mail.write("     <th>Avg No of CPUs waiting for I/O</th>\n")
		mail.write("     <th>Avg No of CPUs being idle</th>\n")
		mail.write("  </tr>\n")
		mail.write("<tr>\n")

		i = 0
		for cname in nCPU:
			if re.match(r"[0].[0-9][0-9]", str(cname)):
				mail.write("<td bgcolor='LimeGreen'>" + cname + "</td>\n")
			elif re.match(r"[1].[0][0]", str(cname)):
				mail.write("<td bgcolor='LimeGreen'>" + cname + "</td>\n")
			elif re.match(r"[1].[0-9][0-9]", str(cname)):
				if  comp1 == 1:
					mail.write("<td bgcolor='LimeGreen'>" + cname + "</td>\n")
				elif comp2 == 1 and comp3 == 1:
					mail.write("<td bgcolor='yellow'>" + cname + "</td>\n")
				else:
					mail.write("<td bgcolor='red'>" + cname + "</td>\n")
			elif re.match(r"[2].[0-9][0-9]", str(cname)):
				if  comp1 == 1:
                                        mail.write("<td bgcolor='LimeGreen'>" + cname + "</td>\n")
                                elif comp2 == 1 and comp3 == 1:
                                        mail.write("<td bgcolor='yellow'>" + cname + "</td>\n")
                                else:
                                        mail.write("<td bgcolor='red'>" + cname + "</td>\n")
			elif re.match(r"[3-9].[0-9][0-9]", str(cname)):
				if  comp1 == 1:
                                        mail.write("<td bgcolor='LimeGreen'>" + cname + "</td>\n")
                                elif comp2 == 1 and comp3 == 1:
                                        mail.write("<td bgcolor='yellow'>" + cname + "</td>\n")
                                else:
                                        mail.write("<td bgcolor='red'>" + cname + "</td>\n")
			else:
				mail.write("<td>" + name + "</td>\n")

			i = i + 1
			if i == 7:
				mail.write("<tr>\n")
				mail.write("</tr>\n")

		mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	if c == 5:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: CPU Utilization of HANA DB are under threshold</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>PLease check CPU Utilization for HANA DB</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#-----------------------------------------------Function to check the alerts --------------------------------------
def alerts(hostname, username, password, user, instance, green, scriptloc, mailfile):
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/alerts.txt"
        remote = "/tmp/alerts.txt"
        sftp.put(local, remote)

	local = scriptloc + "/countAlert.txt"
        remote = "/tmp/countAlert.txt"
        sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/alerts.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                alert = stdout.readlines()

                command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/countAlert.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                countAlerts = stdout.readlines()

		if countAlerts == 0:

			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'>No alert Information for " + name + "</font></td>\n")
			mail.write("</tr>\n")
		else:

			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'>Alert Information for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Alert time</th>\n")
			mail.write("     <th>Alert Name</th>\n")
			mail.write("     <th>Alert ID</th>\n")
			mail.write("     <th>Alert Details</th>\n")
			mail.write("     <th>User Action</th>\n")
			mail.write("  </tr>\n")

			i = 0
			mail.write("<tr>\n")
			for aname in alert:

				mail.write("<td width=\"800\">" + aname + "</td>\n")
				i = i + 1
				rem = i % 5
				if rem == 0:
					mail.write("<tr>\n")
					mail.write("</tr>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#---------------------------------------------------Function to check the backup -----------------------------
def backup(hostname, username, password, user, instance, green, scriptloc, mailfile):

	b = 0
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile = scriptloc + "/errorSection/backupError_" + name + ".txt"
        error = open(errorfile, "w+")

	local = scriptloc + "/countBackupCatalog.txt"
        remote = "/tmp/countBackupCatalog.txt"
        sftp.put(local, remote)

	local = scriptloc + "/errorBackup.txt"
	remote = "/tmp/errorBackup.txt"
	sftp.put(local, remote)

	local = scriptloc + "/errorBackupFailed.txt"
        remote = "/tmp/errorBackupFailed.txt"
        sftp.put(local, remote)

	local = scriptloc + "/errorBackupCancel.txt"
        remote = "/tmp/errorBackupCancel.txt"
        sftp.put(local, remote)

	local = scriptloc + "/errorBackupCancelled.txt"
        remote = "/tmp/errorBackupCancelled.txt"
        sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -U m" + name + " -I /tmp/countBackupCatalog.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                count = stdout.readlines()

		if count != 0:
			green = green - 2
			b = b - 2
			command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/errorBackup.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = (stdout.read()).strip()
                        error.write(out)

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/errorBackupFailed.txt'\" | sudo bash"
                	print command
        	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	                fbackup = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/errorBackupCancel.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        cpbackup = stdout.readlines()

                        command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/errorBackupCancelled.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        cbackup = stdout.readlines()

			c = 0
			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'>Error Backup Information for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Backup ID</th>\n")
			mail.write("     <th>Backup Type</th>\n")
			mail.write("     <th>Start Time</th>\n")
			mail.write("     <th>End Time</th>\n")
			mail.write("     <th>Bakcup State</th>\n")
			mail.write("  </tr>\n")

			if fbackup:
				mail.write("<tr>\n")
				for fname in fbackup:
					mail.write("<td bgcolor='yellow'>" + fname + "</td>\n")
					c = c + 1
					rem = c % 5
					if rem == 0:
						mail.write("<tr>\n")
						mail.write("</tr>\n")
				mail.write("</tr>\n")

			elif cpbackup:
				mail.write("<tr>\n")
				for cname in cpbackup:
					mail.write("<td bgcolor='yellow'>" + cname + "</td>\n")
					c = c + 1
                                        rem = c % 5
                                        if rem == 0:
                                                mail.write("<tr>\n")
                                                mail.write("</tr>\n")
                                mail.write("</tr>\n")

			elif cbackup:
				mail.write("<tr>\n")
                                for cname in cbackup:
                                        mail.write("<td bgcolor='yellow'>" + cname + "</td>\n")
                                        c = c + 1
                                        rem = c % 5
                                        if rem == 0:
                                                mail.write("<tr>\n")
                                                mail.write("</tr>\n")
                                mail.write("</tr>\n")

		else:
			green = green + 1
			b = b + 1
			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"  bgcolor='LimeGreen'>No Backup  failure observed for " + name + " from last monitoring check</td>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")
	if b == 5:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: No errors found in backup for HANA DB</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>PLease check backup catalog for errors</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#---------------------------------------------Function to check long running backup -------------------------------
def longRunningBackup(hostname, username, password, user, instance, green, scriptloc, mailfile):

	l = 0
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile = scriptloc + "/errorSection/longRunningBakcup_" + name + ".txt"
        error = open(errorfile, "w+")

	local = scriptloc + "/longRunningBackup.txt"
        remote = "/tmp/longRunningBackup.txt"
        sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/longRunningBackup.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                backupID = stdout.readlines()

		if not backupID:
			green = green + 1
			l = l + 1
			mail.write("<tr>\n")
			mail.write("<td bgcolor='LimeGreen'>There are no long running full data backups for database " + name + "</td>\n")
			mail.write("</tr>\n")
		else:
			green = green - 2
			l = l - 2
			command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/longRunningBackup.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = (stdout.read()).strip()
                        error.write(out)
			mail.write("<tr>\n")
			mail.write("<td bgcolor='red'>Cancel the long running data backup with backup ID " + backupID + " for database " + name + "</td>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")
	if l == 5:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: No Long running full data backup found for HANA DB</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>Please cancel the long running full data backup</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#-----------------------------------------------Function to check the blocked transaction --------------------------
def blockedTransaction(hostname, username, password, user, instance, green, scriptloc, mailfile):

	t = 0
	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile = scriptloc + "/errorSection/longRunningBakcup_" + name + ".txt"
        error = open(errorfile, "w+")

	local = scriptloc + "/countBlockedTrans.txt"
        remote = "/tmp/countBlockedTrans.txt"
        sftp.put(local, remote)

	local = scriptloc + "/longRunningBackup.txt"
        remote = "/tmp/longRunningBackup.txt"
        sftp.put(local, remote)

	local = scriptloc + "/blockedTrans.txt"
	remote = "/tmp/blockedTrans.txt"
	sftp.put(local, remote)

	for name in dbname:

		command = "echo 'su - " + user + " -c '\"'hdbsql -xja -i " + instance + " -U m" + name + " -I /tmp/countBlockedTrans.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                counter = stdout.readlines()

		if counter == 0:
			green = green + 1
			t = t + 1
			mail.write("<tr>\n")
			mail.write("<td bgcolor='LimeGreen'>No blocked transactions found in database " + name + "</td>\n")
			mail.write("</tr>\n")
		else:
			green = green - 2
			t = t - 2
			command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/longRunningBackup.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = (stdout.read()).strip()
                        error.write(out)

			command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/blockedTrans.txt'\" | sudo bash"
                	print command
        	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	                blocked = stdout.readlines()

			mail.write("<tr>\n")
			mail.write("<td colspan=\"14\"><font color='blue'>Blocked transaction Information for " + name + "</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Host</th>\n")
			mail.write("     <th>Port</th>\n")
			mail.write("     <th>Blocked Transaction ID</th>\n")
			mail.write("     <th>Blocked Connection ID</th>\n")
			mail.write("     <th>Locked Owner Transaction ID</th>\n")
			mail.write("     <th>Locked Owner Connection ID</th>\n")
			mail.write("     <th>Blocked Time</th>\n")
			mail.write("     <th>Waiting Record ID</th>\n")
			mail.write("     <th>Waiting Schema Name</th>\n")
			mail.write("     <th>Waiting Table Name</th>\n")
			mail.write("     <th>Waiting Object Name</th>\n")
			mail.write("     <th>Waiting Object Type</th>\n")
			mail.write("     <th>Lock Type</th>\n")
			mail.write("     <th>Lock Mode</th>\n")
			mail.write("  </tr>\n")

			mail.write("<tr>\n")
			for bname in blocked:
				mail.write("<td>" + bname + "</td>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")
	if t == 5:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:green\" !important><font size=\"5\"><b>Green: No transaction blocking found in HANA DB</b></font></p>\n")
	else:
		mail.write("<p class='mar1'>Summary:</p>\n")
		mail.write("<p class='mar1' style=\"color:red\" !important><font size=\"5\"><b>Please check the blocked transactions and take necessary actions</b></font></p>\n")

	error.close()
	mail.close()
	sftp.close()
	transport.close()
	return green

#------------------------------------------------------Function to check the key KPI's -----------------------------------------
def keyKPI(hostname, username, password, user, instance, green, scriptloc, mailfile):

	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	errorfile1 = scriptloc + "/errorSection/crashOOM_" + name + ".txt"
        crasherror = open(errorfile1, "w+")

	errorfile2 = scriptloc + "/errorSection/memtable_" + name + ".txt"
        memerror = open(errorfile2, "w+")

	errorfile3 = scriptloc + "/errorSection/unloads_" + name + ".txt"
        unloadserror = open(errorfile3, "w+")

	errorfile4 = scriptloc + "/errorSection/tableDelta_" + name + ".txt"
        deltaerror = open(errorfile4, "w+")

	errorfile5 = scriptloc + "/errorSection/rowStoreMVCCVersions" + name + ".txt"
        mvccerror = open(errorfile5, "w+")

	local = scriptloc + "/countCrashOOM.txt"
	remote = "/tmp/countCrashOOM.txt"
	sftp.put(local, remote)

	local = scriptloc + "/crashOOM.txt"
	remote = "/tmp/crashOOM.txt"
	sftp.put(local, remote)

	local = scriptloc + "/perUsedMem.txt"
	remote = "/tmp/perUsedMem.txt"
	sftp.put(local, remote)

	local = scriptloc + "/memoryUsageTables.txt"
	remote = "/tmp/memoryUsageTables.txt"
	sftp.put(local, remote)

	local = scriptloc + "/unloadsNum.txt"
	remote = "/tmp/unloadsNum.txt"
	sftp.put(local, remote)

	local = scriptloc + "/unloads.txt"
	remote = "/tmp/unloads.txt"
	sftp.put(local, remote)

	local = scriptloc + "/deltaGB.txt"
	remote = "/tmp/deltaGB.txt"
	sftp.put(local, remote)

	local = scriptloc + "/tableDelta.txt"
	remote = "/tmp/tableDelta.txt"
	sftp.put(local, remote)

	local = scriptloc + "/mvccValue.txt"
	remote = "/tmp/mvccValue.txt"
	sftp.put(local, remote)

	local = scriptloc + "/rowStoreMVCCVersions.txt"
	remote = "/tmp/rowStoreMVCCVersions.txt"
	sftp.put(local, remote)

	for name in dbname:
		if name == "BFC" or name == "FIM" or name == "BIP" or name == "MFC":
			mail.write("<tr>\n")
			mail.write("<td colspan=\"5\"><font color='blue'> Other KPI's for " + name + " Database</font></td>\n")
			mail.write("</tr>\n")
			mail.write("  <tr>\n")
			mail.write("     <th>Crash/OOM/RTE Dump</th>\n")
			mail.write("     <th>Mem. Usage of tables (<50%)</th>\n")
			mail.write("     <th>Column unloads due to low mem.</th>\n")
			mail.write("     <th>Tables with delta size </th>\n")
			mail.write("     <th>Row store MVCC active versions </th>\n")
			mail.write("  </tr>\n")

			mail.write("<tr>\n")

			command = "echo 'su - " + user + " -c '\"'hdbsql -xjaC -i " + instance + " -U m" + name + " -I /tmp/countCrashOOM.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count = (stdout.read()).strip()

			if int(count) != 0:
				command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/crashOOM.txt'\" | sudo bash"
                                print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                out = (stdout.read()).strip()
                                crasherror.write(out)
				mail.write("  <td bgcolor='yellow'>Crash/OOM/RTE Dump found, check trace</td>\n")
			else:
				mail.write("  <td bgcolor='LimeGreen'>No Crash/OOM/RTE Dump</td>\n")

			command = "echo 'su - " + user + " -c '\"'hdbsql -xjaCQ -i " + instance + " -U m" + name + " -I /tmp/perUsedMem.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        perUsed = (stdout.read()).strip()

			if int(perUsed) > 50:
				command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/memoryUsageTables.txt'\" | sudo bash"
                                print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                out = (stdout.read()).strip()
                                memerror.write(out)
				mail.write("  <td bgcolor='red'>" + perUsed + " Check error attachment</td>\n")
			else:
				mail.write("  <td bgcolor='LimeGreen'>No high table memory usage observerd</td>\n")

			command = "echo 'su - " + user + " -c '\"'hdbsql -xjaCQ -i " + instance + " -U m" + name + " -I /tmp/unloadsNum.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count = stdout.readlines()

			i = 0

			for each in count:
				if each == "":
					i = i + 1
				elif each == 0:
					i = i + 1
			if i == 2:
				mail.write("<td bgcolor='LimeGreen'>No unloads occurred</td>\n")
			elif i == 1:
				mail.write("<td bgcolor='LimeGreen'>No unloads occurred</td>\n")
			else:
				command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/unloads.txt'\" | sudo bash"
                                print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                out = (stdout.read()).strip()
                                unloadserror.write(out)
				mail.write("  <td bgcolor='red'>Unloads Occurred </td>\n")

			command = "echo 'su - " + user + " -c '\"'hdbsql -xjaC -i " + instance + " -U m" + name + " -I /tmp/deltaGB.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        count = (stdout.read()).strip()

			command = "echo " + count + " | bc"
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			value = (stdout.read()).strip()

			command = "echo \"" + value + " < 5.00\" | bc"
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			comp = (stdout.read()).strip()

			if int(comp) == 1:
				mail.write(" <td bgcolor='LimeGreen'>No table with detla size > 5GB </td>\n")
			else:
				command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/tableDelta.txt'\" | sudo bash"
                                print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                out = (stdout.read()).strip()
                                deltaerror.write(out)
				mail.write("  <td>Please check DB for tables with delta > 5GB</tdb>\n")

			command = "echo 'su - " + user + " -c '\"'hdbsql -xjaC -i " + instance + " -U m" + name + " -I /tmp/mvccValue.txt'\" | sudo bash"
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        versions = (stdout.read()).strip()
			if int(versions) < 8000000:
				mail.write("<td bgcolor='LimeGreen'>MVCC Row Store versions under thershold</td>\n")
			else:
				command = "echo 'su - " + user + " -c '\"'hdbsql -xjCA -i " + instance + " -U m" + name + " -I /tmp/rowStoreMVCCVersions.txt'\" | sudo bash"
                                print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                out = (stdout.read()).strip()
                                mvccerror.write(out)
				mail.write("<td bgcolor='red'>Please check Rowstore for " + name + " Database</td>\n")
			mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	crasherror.close()
	memerror.close()
	unloadserror.close()
	deltaerror.close()
	mvccerror.close()
	sftp.close()
	transport.close()
	return green

#------------------------------------------------------Function to check host information ------------------------------
def hostInfo(hostname, username, password, user, instance, green, scriptloc, mailfile):

	mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/hostStatus.txt"
	remote = "/tmp/hostStatus.txt"
	sftp.put(local, remote)

	command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -u SYSTEM -I /tmp/hostStatus.txt'\" | sudo bash"
        print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        host = stdout.readlines()

	mail.write("<td colspan="7"><font color='blue'>Host Information</font></td>\n")
	mail.write("</tr>\n")
	mail.write("  <tr>\n")
	mail.write("     <th>Host</th>\n")
	mail.write("     <th>Host Active</th>\n")
	mail.write("     <th>Host Status</th>\n")
	mail.write("     <th>Failover Actual Group</th>\n")
	mail.write("     <th>Nameserver Actual Role</th>\n")
	mail.write("     <th>Indexserver Actual Role</th>\n")
	mail.write("     <th>Storage Partition</th>\n")
	mail.write("  </tr>\n")

	i = 0
	mail.write("<tr>\n")

	for each in host:
		mail.write("<td width="800">" + each + "</td>\n")
		i = i + 1
		rem = i % 7
		if rem == 0:
			mail.write("<tr>\n")
			mail.write("</tr>\n")
	mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#---------------------------------------------------Function to check the replication information -----------------------------
def replicationInfo(hostname, username, password, user, instance, green, scriptloc, mailfile):

	dbname = ''
	if not dbname:
                command = "echo 'su - " + user + " -c '\"'hdbsql -xajC -i " + instance + " -u SYSTEM \"'\"select database_name from m_databases where active_status='\"\\\'YES\\\'\"'\"'\"'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                dbname = stdout.readlines()

        mail = open(mailfile,"a")
        mail.write("<table style=\"widht:100%\">\n")
        mail.write("  <tr>\n")

        port = 22

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)

	local = scriptloc + "/replication.txt"
	remote = "/tmp/replication.txt"
	sftp.put(local, remote)

	r = 0
	mail.write("<td colspan="13"><font color='blue'>Replication Information</font></td>\n")
	mail.write("<tr>\n")
	mail.write("  <th>Host</th>\n")
	mail.write("  <th>Port</th>\n")
	mail.write("  <th>Site Name</th>\n")
	mail.write("  <th>Secondary Host</th>\n")
	mail.write("  <th>Secondary Port</th>\n")
	mail.write("  <th>Secondary Site Name</th>\n")
	mail.write("  <th>Secondary Active Status</th>\n")
	mail.write("  <th>Secondary Reconnect Count</th>\n")
	mail.write("  <th>Secondary Fully Recoverable</th>\n")
	mail.write("  <th>Replication Mode</th>\n")
	mail.write("  <th>Replication Status</th>\n")
	mail.write("  <th>Replication Status Details</th>\n")
	mail.write("  <th>Async Buffer Full Count</th>\n")
	mail.write("</tr>\n")

	for name in dbname:
		command = "echo 'su - " + user + " -c '\"'hdbsql -xajCQ -i " + instance + " -U m" + name + " -I /tmp/replication.txt'\" | sudo bash"
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                replica = stdout.readlines()

		mail.write("<tr>\n")
		for each in replica:
			if each == "ACTIVE":
				mail.write("<td bgcolor='LimeGreen' width=\"800\">" + each + "</td>\n")
			else:
				mail.write("<td width=\"800\">" + each + "</td>\n")
			r = r + 1
			rem = r % 13
			if rem == 0:
				mail.write("<tr>\n")
				mail.write("</tr>\n")
		mail.write("</tr>\n")

	mail.write("</tr>\n")
	mail.write("</table>\n")

	mail.close()
	sftp.close()
	transport.close()
	return green

#-----------------------------------------------------Main Execution ----------------------------------------
try:

	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	db_sid = argv[4]
	scriptloc = argv[5]

	user = sid.lower() + 'adm'
        prof_path = "/usr/sap/" + db_sid.upper() + "/SYS/profile"

	green = 0

	mailfile = scriptloc + '/hana_monitoring_mail.txt'

	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()
        
	command = "echo \" su - " + user + " -c \"\'\"cd " + prof_path + ";ls\"\'\' | grep -i \"" + db_sid.upper() + "_HDB\" |  grep -i " + hostname + "  | grep -v \"\.\"\'| sudo bash "
        print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        profilefile = ''.join(stdout.readlines()).strip()
        print profilefile

        profilefile1 = profilefile.split("_")[1]
        print profilefile1
        instance = profilefile1[-2:]
        print instance

	mail = open(mailfile,"w+")
	mail.write("<HTML>\n")
	mail.write("<HEAD>\n")
	mail.write("<STYLE>\n")
	mail.write(" body {
                background-color: HoneyDew;
                border: 1px solid black;
                }\n")
	mail.write("table, th, td {
                margin-top: 0.7cm;
                margin-left:1cm;
                border: 1px solid black;
                border-collapse: collapse;
                table-layout: auto;
                }\n")
	mail.write("table {
		font-family:Palatino Linotype;	
		}\n")
	mail.write("th,td {
                padding: 15px;
                }\n")
	mail.write("td {
                text-align: center;
                }\n")
	mail.write("th {
    		font-weight: bold;
		}\n")
	mail.write("p.mar1 {
                margin-top: 1cm;
                margin-left:1cm;
		font-family:Palatino Linotype;
		 
	        }\n")
	mail.write("h2.head {
                font-family:Palatino Linotype;
		text-align: center;
                color:CornflowerBlue;
                margin-top: 1cm;
                }\n")
	mail.write("a:link {
	        color: black; 
	        background-color: transparent; 
	        text-decoration: none;
		}\n")
	mail.write("a:visited {
    		color: blue;
		background-color: transparent;
		text-decoration: none;
		}\n")
	mail.write("a:hover {
		color: red;
     		background-color: transparent;
		text-decoration: underline;
		}\n")
	mail.write("a:active {
		color: yellow;
		background-color: transparent;
		text-decoration: underline;
		}\n")
	mail.write("</STYLE>\n")
	mail.write("<TITLE>\n")
	mail.write("  eKO HANA Monitoring for " + db_sid + "\n")
	mail.write("  </TITLE>\n")
	mail.write("</HEAD>\n")
	mail.write("<BODY>\n")
	mail.write("<h2 class='head'id='top' >\"eKO HANA Monitoring for " + db_sid + "\"</h2>\n")

	#---------------------create links in the same table---------------------------

	mail.write("<p class='mar1' id='top'>Content (Click to jump on the section)</p>\n")
	mail.write("<ul style='list-style-type:square'>\n")
	mail.write("<li><a href='#C1'>Availablity of HANA Database</a></p>\n")
	mail.write("<li><a href='#C2'>Host information for Multi Node HANA DB</a></p>\n")
	mail.write("<li><a href='#C16'>Replication Information for DR</a></p>\n")
	mail.write("<li><a href='#C3'>Disk Usage of HANA Database</a></p>\n")
	mail.write("<li><a href='#C4'>Volume Usage of HANA Database</a></p>\n")
	mail.write("<li><a href='#C5'>Memory Usage of HANA Database</a></p>\n")
	mail.write("<ul style='list-style-type:square'>\n")
	mail.write("<li><a href='#C6'> Service Memory Usage of HANA Database</a></p>\n")
	mail.write("<li><a href='#C7'>Instance Memory Usage of HANA Database</a></p>\n")
	mail.write("<li><a href='#C8'>Peak Memory Usage of HANA Database</a></p>\n")
	mail.write("<li><a href='#C9'>Resident Memory Usage of HANA Database</a></p>\n")
	mail.write("</ul>\n")
	mail.write("<li><a href='#C10'>CPU Utilization of HANA Database</a></p>\n")
	mail.write("<li><a href='#C11'>Alert Information for HANA Database</a></p>\n")
	mail.write("<li><a href='#C12'>Error Backup Information for HANA Database</a></p>\n")
	mail.write("<li><a href='#C13'>Long running full data backup for HANA Database</a></p>\n")
	mail.write("<li><a href='#C14'>Blocked transaction information for HANA Database</a></p>\n")
	mail.write("<li><a href='#C15'>Miscellaneous KPIs for HANA Database for last 2 days</a></p>\n")
	mail.write("</ul>\n")
	mail.close()

	#---------------------------Start function calling----------------------------------

	mail = open(mailfile,"a")
	mail.write("<p class='mar1' id='C1' style='margin-top: 1.5cm' !important>1. Availablity of HANA Database</p>\n")
	mail.close()
	green = availability(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C2'>2. Host information for Multi Node HANA DB</p>\n")
	mail.close()
	green = hostInfo(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C16'>3. Replication Information for DR</p>\n")
	mail.close()
	green = replicationInfo(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C3'>4. Disk Usage of HANA Database</p>\n")
	mail.close()
	green = diskUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C4'>5.Volume Usage of HANA Database</p>\n")
	mail.close()
	green = volumeUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C5'>6.Memory Usage of HANA Database</p>\n")
	mail.write("<p class='mar1' id='C6'>6.1 Service Memory Usage of HANA Database</p>\n")
	mail.close()
	green = serviceMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C7'>6.2 Instance Memory Usage of HANA Database</p>\n")
	mail.close()
	green = instanceMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C8'>6.3 Peak Memory Usage of HANA Database</p>\n")
	mail.close()
	green = peakMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C9'>6.4 Resident Memory Usage of HANA Database</p>\n")
	mail.close()
	green = residentMemoryUsage(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C10'>7. CPU Utilization of HANA Database</p>\n")
	mail.close()
	green = cpuUtilization(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfle,"a")
	mail.write("<p class='mar1' style='text-align:right'  style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C11'>8. Alert Information for HANA Database</p>\n")
	mail.close()
	green = alerts(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right'  style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C12'>9. Error Backup Information for HANA Database</p>\n")
	mail.close()
	green = backup(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right'  style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C13'>10. Long running full data backup for HANA Database</p>\n")
	mail.close()
	green = longRunningBackup(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right'  style='margin-right:1cm' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C14'>11. Blocked transaction information for HANA Database</p>\n")
	mail.close()
	green = blockedTransaction(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right' !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("<p class='mar1' id='C15'>12. Miscellaneous KPIs for HANA Database for last 2 days</p>\n")
	mail.close()
	green = keyKPI(hostname, username, password, user, instance, green, scriptloc, mailfile)
	mail = open(mailfile,"a")
	mail.write("<p class='mar1' style='text-align:right'  style='margin-right:1cm'  !important><a href='#top'> Back To Top</a></p>\n")
	mail.write("</BODY>\n")
	mail.write("</HTML>\n")
	mail.close()
	print "green = " + green

	#-------------------------- SSH connection close -----------------------------
        channel.close()
        client.close()

except Exception as e:
        print str(e)
        exc_type, exc_obj, tb = sys.exc_info()
        lineno = tb.tb_lineno
        print lineno
