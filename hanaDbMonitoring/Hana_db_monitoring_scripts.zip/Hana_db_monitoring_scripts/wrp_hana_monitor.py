import sys
from sys import *
import os
import re
import subprocess
from subprocess import *
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText

def Send_Mail(mailfile, status):
        HtmlPage = mailfile
        fromaddr = 'erp@capgemini.com'
        MAILTO = 'erp_transformation.in@capgemini.com'
#       os.system('export HTML_MAIL_OUTPUT_FILE_NAME = HtmlPage'
        HTML_MAIL_OUTPUT_FILE_NAME = HtmlPage
        subprocess.Popen('export HTML_MAIL_OUTPUT_FILE_NAME',shell=True)
#       os.environ[HTML_MAIL_OUTPUT_FILE_NAME] = HtmlPage
#       HtmlPage=MAIN_DR + "/Baseline_Check.html"
#       fromaddr = "erptransformation@gmail.com"
        fp = open(HtmlPage, 'r')
        msge = fp.read()
        fp.close()
        body = msge
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = MAILTO
        msg['Subject'] = str(status + ":Hana DB Monitoring report")
        msg.attach(MIMEText(body, 'html'))
        server = smtplib.SMTP('localhost')
        server.sendmail(fromaddr, MAILTO, msg.as_string())
        server.quit()


try:
	hostname = argv[1]
        username = argv[2]
        password = argv[3]
        db_sid = argv[4]
        scriptloc = argv[5]

	mailfile = scriptloc + "/hana_monitoring_mail.txt"
	command = "python hana_monitor_multinode.py " + hostname + " " + username + " " + password + " " + db_sid + " " + scriptloc
	print command
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	print out

	out = (out.strip()).split('\n')
	for each in out:
		if "green" in each.strip():
			counter = (each.strip()).split("=")[1]
	print counter

	if re.match(r"113", str(counter)):
		status = "Green"
		Send_Mail(mailfile, status)
	elif re.match(r"[1][1][0-2]", str(counter)):
		status = "Yellow"
		Send_Mail(mailfile, status)
	elif re.match(r"[1][0][0-9]", str(counter)):
		status = "Yellow"
		Send_Mail(mailfile,status)
	elif re.match(r"[0-9][0-9]", str(counter)):
		status = "Red"
		Send_Mail(mailfile,status)


except Exception as e:
        print str(e)
        exc_type, exc_obj, tb = sys.exc_info()
        lineno = tb.tb_lineno
        print lineno
	
