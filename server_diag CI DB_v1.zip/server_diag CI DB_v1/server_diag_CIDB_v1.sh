#!/bin/bash

##################################################################################################################################################
## Purpose : This script will collect the OS load,Memory,I/O activity,filesystem usage,SAP process table, Database connectivityand activity.
## Author : Jesna Jose
## Version : 1.0
##################################################################################################################################################

####################################### Script Variables ############################################################

DATE=`date '+%Y_%m_%d_%H_%M_%S'`
PWD=`pwd`
LOCATION=${PWD}"/Server_diagnostic_"${DATE}

echo -n  "Enter the SAPSID : "
read APPSID
echo -n  "Enter the DBSID : "
read DBSID

#APPSID=`env | grep "SAPSYSTEMNAME" | cut -d "=" -f 2`
#DBSID=`env | grep "ORACLE_SID" |  cut -d "=" -f 2`
OSNAME1=`uname`

OSNAME=`echo $OSNAME1 | tr '[:lower:]' '[:upper:]'`
SID=`echo $APPSID | tr '[:lower:]' '[:upper:]'`
ASID=`echo $APPSID | tr '[:upper:]' '[:lower:]'`
DSID=`echo $DBSID | tr '[:upper:]' '[:lower:]'`
DBSID=`echo $DBSID | tr '[:lower:]' '[:upper:]'`


mkdir ${LOCATION} ; chmod -R 777  ${LOCATION}

echo ""
echo "****************************************************************************************"
echo "Running server Diagnostic script...."


################################### TOP COMMAND ###################################################################


echo " " >> ${LOCATION}"/TOP_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log" 
echo "#################################################################################" >> ${LOCATION}"/TOP_output.log" 
echo "			TOP command		" >> ${LOCATION}"/TOP_output.log"
echo "#################################################################################" >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo "****************************************************************************************"
echo ""
echo "Executing Top command...."
top -b -n 1 >> ${LOCATION}"/TOP_output.log"
echo "Writing the top command output into the file "${LOCATION}"/TOP_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >>  ${LOCATION}"/TOP_output.log"


##################################### VMSTAT COMMAND #################################################################



echo " " >> ${LOCATION}"/VMstat_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/VMstat_output.log"
echo "			VMSTAT COMMAND		" >> ${LOCATION}"/VMstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo ""
echo "Executing Vmstat command...."
vmstat >> ${LOCATION}"/VMstat_output.log"
echo "Writing the Vmstat command output into the file "${LOCATION}"/VMstat_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/VMstat_output.log"



##################################### IOSTAT ############################################################################


echo " " >> ${LOCATION}"/IOstat_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"

echo "#################################################################################" >> ${LOCATION}"/IOstat_output.log"
echo "			IOSTAT COMMAND		" >> ${LOCATION}"/IOstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo ""
echo "Executing iostat command...."
iostat >> ${LOCATION}"/IOstat_output.log"
echo "Writing the iostat command output into the file "${LOCATION}"/IOstat_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/IOstat_output.log"


##################################### space check ########################################################################


echo " " >> ${LOCATION}"/File_system_usage.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"

echo "#################################################################################" >>  ${LOCATION}"/File_system_usage.log"
echo "                  FILE SYSTEM USAGE            " >>  ${LOCATION}"/File_system_usage.log"
echo "#################################################################################" >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
if [ "${OSNAME}" == AIX ]; then
echo ""
echo "Executing df -gt command...."
df -gt >> ${LOCATION}"/File_system_usage.log"
echo "Writing the df -gt command output into the file "${LOCATION}"/File_system_usage.log"
echo ""
echo "****************************************************************************************"
else
echo ""
echo "Executing df -h command...."
df -h >>  ${LOCATION}"/File_system_usage.log"
echo "Writing the df -h  command output into the file "${LOCATION}"/File_system_usage.log"
echo ""
echo "****************************************************************************************"
fi
echo "****************************************************************************************" >>  ${LOCATION}"/File_system_usage.log"


#####################################   DPMON COMMAND   ###########################################################################



PROFILEFILE=`sudo su - "${ASID}"adm -c "ls /sapmnt/'${SID}'/profile | grep '${SID}' | grep -v '\.' | grep 'DVEBMGS' | grep -- '${HOSTNAME}''$'"`
#echo ${PROFILEFILE}
echo " " >> ${LOCATION}"/DPMON.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >>  ${LOCATION}"/DPMON.log"
echo " " >>  ${LOCATION}"/DPMON.log"
echo " " >>  ${LOCATION}"/DPMON.log"


echo "#################################################################################" >> ${LOCATION}"/DPMON.log"
echo "                  DPMON COMMAND            " >> ${LOCATION}"/DPMON.log"
echo "#################################################################################" >> ${LOCATION}"/DPMON.log"
echo " " >> ${LOCATION}"/DPMON.log"
echo " " >> ${LOCATION}"/DPMON.log"
echo ""
echo "Executing DPMON COMMAND...."
sudo su - "${ASID}"adm -c "echo q | dpmon pf=/sapmnt/'${SID}'/profile/'${PROFILEFILE}' l" >> ${LOCATION}"/DPMON.log"
echo "Writing the dpmon command output into the file "${LOCATION}"/DPMON.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/DPMON.log"



#####################################  DATABASE CONNECTIVITY ########################################################################

echo " "
#echo "Logging in as DB user ora"${DSID}
#echo ""
mkdir ${PWD}"/backup_files_"${DATE};chmod 777 ${PWD}"/backup_files_"${DATE}
STATUS=`sudo su - "${ASID}"adm -c 'R3trans -d'`
echo "Executing R3trans Command...."
echo ""


echo " " >> ${LOCATION}"/R3trans_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/R3trans_output.log"
echo " " >>  ${LOCATION}"/R3trans_output.log"
echo " " >>  ${LOCATION}"/R3trans_output.log"
echo "#################################################################################" >> ${LOCATION}"/R3trans_output.log"
echo "                  DATABASE CONNECTIVITY            " >> ${LOCATION}"/R3trans_output.log"
echo "#################################################################################" >> ${LOCATION}"/R3trans_output.log"
echo " " >> ${LOCATION}"/R3trans_output.log"
echo " " >> ${LOCATION}"/R3trans_output.log"

echo ${STATUS} >>  ${LOCATION}"/R3trans_output.log"

RETURNVALUE=`echo "${STATUS}"| tail -1 | awk -F " " '{print \$NF}'`

if [ "${RETURNVALUE}" == "(0000)." ]; then

echo R3trans is successfull >> ${LOCATION}"/R3trans_output.log"
else

#echo "Logging in as DB user ora"${DSID}" to find the trans.log path...."
echo ""
TRACEFILELOC=`sudo su - "${ASID}"adm -c 'pwd'`
echo "Copying trans.log "${TRACEFILELOC}"/trans.log to "${LOCATION}"/trans.log"
echo ""
echo "Copying trans.log "${TRACEFILELOC}"/trans.log to "${LOCATION}"/trans.log >> "${LOCATION}"/R3trans_output.log"
sudo su - "${ASID}"adm -c "cp -rf '${TRACEFILELOC}'/trans.log '${LOCATION}'/trans.log"
FILEC=`ls "${LOCATION}"/trans.log | grep trans.log`

if [ -z ${FILEC} ]; then

echo "Unable to copy the file "${TRACEFILELOC}"/trans.log"
echo ""
echo "" >> ${LOCATION}"/R3trans_output.log"
echo "Unable to copy the file "${TRACEFILELOC}"/trans.log" >> ${LOCATION}"/R3trans_output.log"

else

echo "File "${TRACEFILELOC}"/trans.log is copied to "${LOCATION}"/trans.log successfully"
echo "" >> ${LOCATION}"/R3trans_output.log"
echo "File "${TRACEFILELOC}"/trans.log is copied to "${LOCATION}"/trans.log successfully" >> ${LOCATION}"/R3trans_output.log"
fi

fi
echo ""
echo "" >> ${LOCATION}"/R3trans_output.log"
echo "" >> ${LOCATION}"/R3trans_output.log"
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/R3trans_output.log"

#####################################  DATABASE ACTIVITIES  #############################################


echo ""
echo "Logging in as  ora"${DSID}
echo "Executing SQLs for the collecton of database activities...." 
sudo su - ora"${DSID}" -c 'echo exit | sqlplus / as sysdba @/oracle/'${DBSID}'/SQL_script.sql'
DBLOC=`sudo su - ora"${DSID}" -c "pwd"`
#echo ${DBLOC}
echo "Writing the SQLs output in the file "
echo ""
echo "****************************************************************************************"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/active_sessions.log ; mv '${DBLOC}'/active_sessions.log '${LOCATION}'/active_sessions.log"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/top5_cpu_statements.log ; mv '${DBLOC}'/top5_cpu_statements.log '${LOCATION}'/top5_cpu_statements.log"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/top5_locked_objects.log ; mv '${DBLOC}'/top5_locked_objects.log '${LOCATION}'/top5_locked_objects.log"


#####################################  BACKUP OF SAP FILES #############################################


echo ""
echo "Executing backup of files from work location...."


FILELIST=`sudo su "${ASID}"adm  -c "cd /usr/sap/'${SID}'/DVE*/work ; ls -rt | tail -20"` # awk -F " " '{print \$9}''`
#echo ${FILELST}
#FILELIST=`echo ${FILELST} | tail -20 | awk -F " " '{print \$9}'`

#echo ${FILELIST}
echo "Creating backup file location "${PWD}"/backup_files_"${DATE}


for FILE in $(echo $FILELIST | sed "s/ / /g")
do

sudo su "${ASID}"adm -c "cp -rf /usr/sap/"${SID}"/DVE*/work/"${FILE}" ${PWD}"/backup_files_"${DATE}"/"${FILE} ; chmod 777 ${PWD}"/backup_files_"${DATE}"/"${FILE}"

FL=`ls "${PWD}"/backup_files_"${DATE}"/"${FILE}" | grep "${FILE}"`

if [ -z ${FL} ]; then

echo "Unable to copy the file /usr/sap/"${SID}"/DVE*/work/"${FILE}

else

echo "Backup of the file ${FILE} is completed"

fi
done

echo ""
echo "****************************************************************************************"



##################################### BACKUP OF ALERT.LOG #################################################


echo ""
echo "Executing backup of alert log...."

FILELIST1=`sudo su - ora"${DSID}" -c "ls /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log | grep alert_'${DBSID}'.log"`
echo "Fetching the alert log from /oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace location"

if [ -z ${FILELIST1} ]; then

echo "Unable to find the file /oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace/alert_"${DBSID}".log"

else

echo "Copying the alert log to "${LOCATION}" location " 
#udo su - ora"${DSID}" -c "cp -rf /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log '${PWD}'/backup_files_'${DATE}'/alert_'${DBSID}'.log ; chmod 777 '${PWD}'/backup_files_'${DATE}'/alert_'${DBSID}'.log"
sudo su - ora"${DSID}" -c "cat  /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log | tail -1000 >> '${LOCATION}'/alert_'${DBSID}'.log"

FILELIST2=`ls "${LOCATION}"/alert_"${DBSID}".log | grep alert_"${DBSID}".log`

if [ -z ${FILELIST2} ]; then

echo "Unable to copy the file oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace/alert_"${DBSID}".log to "${LOCATION}"/alert_"${DBSID}".log"

else

echo "Backup of the file alert.log is completed"

fi

fi
echo ""
echo "****************************************************************************************"


########################################################################################################################

