Spool active_sessions.log;
SET ECHO OFF
SET PAGES 999
SET LINESIZE 255
SET HEADING OFF
set term off
set feed off
set trimspool on
set verify off

BREAK ON who skip 3
--
--      START OF PROGRAM
--
--
PROMPT The following are the currently active sessions
SELECT 'Session '||s.sid
       ||','|| s.serial# 
       ||' '|| s.username 
       ||' logged on from '||s.machine
       ||' with OS id '||p.spid
       ||' on '||TO_CHAR(s.logon_time, 'DD-MON-YYYY HH24:MI') 
       ||'. Currently running '||s.module
       ||' '||s.action  AS who
  FROM v$session s,
       v$process p
 WHERE s.status='ACTIVE'
   AND s.username IS NOT NULL
   AND P.ADDR=S.PADDR
/
--
--
--      END OF PROGRAM
--
--
SET ECHO ON
Spool off;

* CPU.SQL


rem
rem SQL by CPU Usage (v$sqlarea)
rem
column sql_text format a40 word_wrapped heading 'SQL|Text'
column cpu_time heading 'CPU|Time'
column elapsed_time heading 'Elapsed|Time'
column disk_reads heading 'Disk|Reads'
column buffer_gets heading 'Buffer|Gets'
column rows_processed heading 'Rows|Processed'

set pages 55 lines 132
set trimspool on
set term off
set feed off
set verify off
SET ECHO OFF
ttitle 'SQL By CPU Usage'

spool top5_cpu_statements.log

select * from 
(select sql_text, 
cpu_time/1000000 cpu_time, 
elapsed_time/1000000 elapsed_time, 
disk_reads, 
buffer_gets, 
rows_processed 
from v$sqlarea 
order by cpu_time desc, disk_reads desc
) 
where rownum < 21 and rownum <=5
/
spool off
set pages 22 lines 80
ttitle off
set term off
set feed off
set trimspool on
set verify off
spool top5_locked_objects.log
select OBJECT_ID,SESSION_ID,OS_USER_NAME,PROCESS,LOCKED_MODE from v$locked_object where rownum<6;
SET ECHO ON
spool off
