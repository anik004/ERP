################################################################
#  Script Name: authmodule
#  Author: Pramodini Prakash
#  Description: Module to check if authentication of the user is successful.
################################################################

import subprocess
import log4erp
from log4erp import *
import time

def auth(hostname,username,password,appsid,path,seq_no,logfile,string):
    command = 'c:\\python27\\python.exe ' + path.rstrip() + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"exit\"'
    write(logfile, command)
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile, time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
    if 'Errno Connection error' in out:
        print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Please check the hostname that you have provide : ' + hostname + '_' + appsid.upper() + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid.upper()
        write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Please check the hostname that you have provide : ' + hostname + '_' + appsid.upper() + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid.upper())
        exit()
    elif 'dialect used' in out:
        #print 'SSS:P:Authentication check successful : ' + hostname + "_" + appsid.upper() + "_" + seq_no
        write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:Authentication check successful : ' + hostname + '_' + appsid.upper() + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid.upper())
    else:
        print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed : ' + hostname + '_' + appsid.upper() + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid.upper()
        write(logfile, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed : ' + hostname + '_' + appsid.upper() + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid.upper())
        exit()
