################################################################
#  Script Name: Dbstop_orawin
#  Author: Pramodini Prakash
#  Description: Stops the Oracle database.
################################################################

import paramiko
from paramiko import *
from sys import *
from log4erp import *
import subprocess
from subprocess import *
import time

try:
#    if argv[1] == "--u":
#        print "Usage: python sapstart.py <Target database host> <Target database root> <Target database root passwd> <Target Database SID> <Refresh ID>"
#    else:
#     if len(argv) < 5:
#        print "SSSI:F: Argument/s missing for the script [Error Code - 1302]"
#     else:

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    location =argv[4]
    logfile1 = argv[5]
    db_sid = argv[6]
#	drive =argv[7]
    app_sid = argv[7]
    logfile2 = argv[8]
    seqno = argv[9]
    string = argv[10]

    user_db = "ora" + db_sid.lower()

#    client = SSHClient()
#    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#    client.connect(hostname,username = username_db, password = password_db)
#    channel = client.invoke_shell()

    command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "wmic logicaldisk get name"'
    write(logfile1,command)
    #print command
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
    #print out
    status = command.returncode
    drive = ''

    out = out.split('\n')
    for i in out:
        if ':' in i:
            a = i[1]
            command = 'c:\\python27\\python ' + location.strip("\\")  + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "cd\ & ' + a + ': & dir oracle\\' + db_sid.upper() + ' /AD"'
            write(logfile1,command)
            #print command
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
            #print out
            status = command.returncode

            if "File Not Found" not in out:
                out = out.split('\n')
                #print out
                for i in out:
                    #print i
                    if "Directory of" in i:
                        #print i[14]
                        drive = i[14]
                        break
    if drive == '':
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2,log)
        exit()
	
    """command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "dir ' + drive.strip(":") + ':\\oracle\\' + db_sid.upper() + '"'
#	print command
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
#	print out
        status = command.returncode
#	print status

#	command = "ls /oracle/" + db_sid.upper() + " >&1 /dev/null"
#       print command
#        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#        status = stdout.channel.recv_exit_status()
#       print status

        if status != 0:
            print "SSSI:F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect"
            log = 'POST:F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect'
	    write (logfile,log)
            exit()"""

    command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' " set ORACLE_SID=' + db_sid.upper() + ' && echo shutdown immediate | sqlplus / as sysdba "'
    write(logfile1,command)
#	print command 
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
#	print out
    status = command.returncode
#	print status

	#write(logfile,'PRE:I: DB Triggered')
#        command = 'sudo su - ' + user_db + ' -c \'echo "shutdown immediate" | sqlplus / as sysdba\''
        #print command
#        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#        status = stdout.channel.recv_exit_status()
        #print status

    if "ORACLE not available" in out:
        print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has already been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has already been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)

    elif "Database closed." in out:
#        if status == 0 or status == 1:
        print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)

        command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "lsnrctl stop"'
        write(logfile1,command)
#	    print command
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
#	    print out
        status = command.returncode
#	    print status

#            command = 'sudo su - ' + user_db + ' -c \'lsnrctl stop\''
#            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#            status = stdout.channel.recv_exit_status()

        if ":no listener" in out:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has already been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has already been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write(logfile2, log)

        elif "The command completed successfully" in out:
#            if status == 0 or status == 1:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write(logfile2, log)
        else:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Listener is not successfully stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Listener is not successfully stopped on the target server - ( ' +  hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write (logfile2, log)

    else:
        print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Database is not successfully stopped on the target server on the target server - ( '+ hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Database is not successfully stopped on the target server on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)
#        channel.close()
#        client.close()
	
except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif str(e) == "list index out of range":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
        write(logfile2,'SSSI:F: Argument/s missing for the script [Error Code - 1302]')
    elif str(e) == "Authentication failed.":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno + ':'+ string + ':' + hostname + ':' + app_sid)
    elif str(e) == "[Errno 110] Connection timed out":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "getaddrinfo failed" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "invalid decimal" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" +string + ":" + hostname + ":" + app_sid)
