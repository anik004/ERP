################################################################
#  Script Name: Dbstart_orawin
#  Author: Pramodini Prakash
#  Description: Starts the Oracle database.
################################################################

import paramiko
from paramiko import *
from sys import *
from log4erp import *
import subprocess
from subprocess import *
import time 

# target IP - argv[1]
# Login User Name - argv[2]
# Login User Password - argv[3]
# Database SID - argv[4]

try:
#    if argv[1] == "--u":
#        print "python startdb.py <Target Host> <Target Login User Name> <Target Login User Password> <Target Database SID>"
#    if len(argv) < 5:
#        print "SSSI:F:  Argument/s missing for the script [Error Code - 1202]"

#    else:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    location = argv[4]   #script path
    logfile1 = argv[5]
    db_sid = argv[6]
#	drive =argv[7] #drive where oracle is
    app_sid = argv[7]
    logfile2 = argv[8]
    seqno = argv[9]
    string = argv[10]

    user = "ora" + argv[6].lower()

#    client = SSHClient()
#    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#    client.connect(hostname,username = username, password = password)
#    channel = client.invoke_shell()
#
    command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "wmic logicaldisk get name"'
    write(logfile1,command)
    #print command
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
    #print out
    status = command.returncode
    drive = ''

    out = out.split('\n')
    for i in out:
        if ':' in i:
            a = i[1]
            command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "cd\ & ' + a + ': & dir oracle\\' + db_sid.upper() + ' /AD"'
            write(logfile1,command)
            #print command
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
            #print out
            status = command.returncode

            if "File Not Found" not in out:
                out = out.split('\n')
                #print out
                for i in out:
                    #print i
                    if "Directory of" in i:
                        #print i[14]
                        drive = i[14]
                        break
    if drive == '':
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2,log)
        exit()
	
    """command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "dir ' + drive.strip(":") + ':\\oracle\\' + db_sid.upper() + '"'
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
#	print out
	status = command.returncode
#	print status
#	command = "ls /oracle/" + db_sid.upper() + " >&1 /dev/null"
#        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#        status = stdout.channel.recv_exit_status()

        if status != 0:
            print "SSSI:F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect"
            log = 'POST:F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect'
            write (logfile,log)
            exit()"""

    command = 'c:\\python27\\python ' + location.strip("\\") +  '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' " set ORACLE_SID=' + db_sid.upper() + ' && echo startup | sqlplus / as sysdba "'
    write(logfile1,command)
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " +out)
#	print out
    status = command.returncode
#	print status

#        command = 'su - ' + user + ' -c \'echo "startup" | sqlplus / as sysdba\''
#        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#	status = stdout.channel.recv_exit_status()

    if "already-running" in out:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The Database has already been started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has already been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)
	    
    elif "Database opened." in out:
#        if status == 0 or status == 1:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The Database has been started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)

        command = 'c:\\python27\\python ' + location.strip("\\") + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "lsnrctl start"'
        write(logfile1,command)
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
#	    print out
        status = command.returncode
#	    print status
		
#	    command = 'sudo su - ' + user + ' -c \'lsnrctl start\''
#            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#            status = stdout.channel.recv_exit_status()
 
        if "already been started" in out:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has already been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has already been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write(logfile2, log)

        elif "The command completed successfully" in out:
#            if status == 0 or status == 1:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write(logfile2, log)
        else:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The listener has not been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The listener has not been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write(logfile2, log)
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The database has not been started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Database has not been started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
        write (logfile2, log)
#        channel.close()
#        client.close()

except Exception as e:
#    exc_type, exc_obj, exc_tb = sys.exc_info()
    if str(e) == "[Errno -2] Name or service not known":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname+ ':' + app_sid)
    elif str(e) == "list index out of range":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
        write(logfile2,'SSSI:F: Argument/s missing for the script [Error Code - 1302]')
    elif str(e) == "Authentication failed.":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif str(e) == "[Errno 110] Connection timed out":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "getaddrinfo failed" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    elif "invalid decimal" in str(e):
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
        write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid #+ " " + str(exc_tb.tb_lineno)
        write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":"  + hostname + ":" + app_sid)


