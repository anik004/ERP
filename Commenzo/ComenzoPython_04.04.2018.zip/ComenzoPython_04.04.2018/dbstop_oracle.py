################################################################
#  Script Name: Dbstop_oracle
#  Author: Pramodini Prakash
#  Description: Stops the Oracle database.
################################################################

import paramiko
from paramiko import *
from sys import *
from log4erp import *
import time

try:
#    if argv[1] == "--u":
#        print "Usage: python sapstart.py <Target database host> <Target database root> <Target database root passwd> <Target Database SID> <Refresh ID>"
#    else:
#     if len(argv) < 5:
#        print "SSSI:F: Argument/s missing for the script [Error Code - 1302]"
#     else:

        hostname = argv[1]
        username_db = argv[2]
        password_db = argv[3]
        db_sid = argv[4]
        logfile1 = argv[5]
	app_sid = argv[6]
	logfile2 = argv[7]
	seqno = argv[8]
	string = argv[9]

        user_db = "ora" + db_sid.lower()

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        #client.connect(hostname,username = username, password = password)
        #channel = client.invoke_shell()


        client.connect(hostname,username = username_db, password = password_db)
        channel = client.invoke_shell()

	command = "ls /oracle/" + db_sid.upper() + " >&1 /dev/null"
	write(logfile1,command)
#       print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
#       print status

        #command = "sudo su - " + username_db + " -c \'chmod 777 /oracle/" + db_sid.upper()  + "/sapreorg/\'"
        #print command
        #stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
       # print stdout.channel.recv_exit_status()

        if status != 0:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
	    write (logfile2,log)
            exit()


	#write(logfile,'PRE:I: DB Triggered')
#        command = 'sudo su - ' + user_db + ' -c \'echo "shutdown immediate" | sqlplus / as sysdba\''
	command = "echo \"su - " + user_db + " -c \"\"'echo \"'\"shutdown immediate\" | sqlplus / as sysdba'\"'\"|sudo bash"
	write(logfile1,command)
        #print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
        #print status
        if status == 0 or status == 1:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The Database has been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write (logfile2, log)
#            command = 'sudo su - ' + user_db + ' -c \'lsnrctl stop\''
	    command = "echo \"su - " + user_db + " -c \"\\\"\"lsnrctl stop\"\\\"|sudo bash"
	    write(logfile1,command)
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            status = stdout.channel.recv_exit_status()
	    stdout = stdout.readlines()
	    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))

            if status == 0 or status == 1:
                print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
                log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The listener has been stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
                write(logfile2, log)
            else:
                print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Listener is not successfully stopped on the target server - ( ' + hostname + ') :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
                log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Listener is not successfully stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
                write (logfile2, log)

        else:
            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Database is not successfully stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The Database is not successfully stopped on the target server - ( ' + hostname + ' ) :' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write (logfile2, log)
        channel.close()
        client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "list index out of range":
                print "SSS" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
                write(logfile2,'SSSI:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "getaddrinfo failed" in str(e):
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid) 
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "invalid decimal" in str(e):
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     else:
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
		write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

