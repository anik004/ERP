################################################################
#  Script Name: stoplin
#  Author: Pramodini Prakash
#  Description: Stops the SAP system.
################################################################

from sys import *
import sys
import paramiko
from paramiko import *
import log4erp
from log4erp import *
import lauthmodule
from lauthmodule import *
import pingmodule
from pingmodule import *
import time

def sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1,logfile2,string,db_type):
    try:
        ping(hostname,appsid,seq_no,logfile1,string)
        auth(hostname,username,password,appsid,dbsid,string,seq_no,logfile1,db_type)

#################################################### FOLDER EXISTENCE CHECK ON REMOTE SERVER #####################################

	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

	user = appsid.lower() + "adm"

	#command = "sudo su - " + user + " -c 'cd " + kernel_path + "'"
	command = "echo \" su - " + user + " -c \'cd " + kernel_path + " \'\"|sudo bash" 
	write(logfile1, command)
	#print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	#print stdout
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))

	if status == 0:

        #################   CHECKING PROFILE PATH EXISTENCE ON REMOTE SERVER ###################################

#	    command = "sudo su - " + user + " -c 'cd " + profile_path + "'"
	    command = "echo \" su - " + user + " -c \'cd " + profile_path + " \'\"|sudo bash"
            write(logfile1, command)
            #print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            status = stdout.channel.recv_exit_status()
	    stdout = stdout.readlines()
	    #print stdout
	    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))

	    if status == 0:
                profile_path = profile_path

		command = "cd " + profile_path + ";ls "
		write(logfile1,command)
                #print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                out = stdout.readlines()
		write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(out))

                inst = ""
                for file in out:
                    file = file.split()
                    for instance in file:
                        if appsid.upper() in instance:
#			    if "ASCS" in instance:
#				continue
                            if "." not in instance:
		#		print instance
		#		print type(instance)
                                inst = instance + " " + inst
#                print inst
                instance_no = inst.split("\n")
#		print instance_no

                instance = ""
                for ins in instance_no:
                        ins = ins.split("_")
#			print ins
#			print string
#			if string.upper() == "AI" and "D" in ins[1] and len(ins[1]) == 3:
#			    print ins
#		            ins = ins[1][-2:]
#		            instance = instance + " " + ins
		        if "DVEBMGS" in ins[1]:
#			    print ins
		            ins = ins[1][-2:]
#			    print ins
		            instance = instance + " " + ins
			elif "D" in ins[1] and len(ins[1]) == 3:
			    ins = ins[1][-2:]
			    instance = instance + " " + ins
			if string == "CI" and "ASCS" in ins[1]:
			    ins = ins[1][-2:]
			    instance = instance + " " + ins
#		print instance
                instance = instance.split()
#                print instance


##################################################### SAP STATUS CHECK = RUNNING/STOPPED/INTERMEDIATE ###########################
                for ins in instance:
		    if sys_type.lower() == 'abap':
#                        command = 'sudo su - ' + user + ' -c \'sapcontrol -nr ' + ins + ' -function GetProcessList\''
			 command = "echo \"su - " + user + " -c \'sapcontrol -nr " + ins + " -function GetProcessList\'\" | sudo bash"
    #                    print command
                    elif sys_type.lower() == 'java':
#                        command = 'sudo su - ' + user + ' -c \'sapcontrol -nr ' + ins + ' -function J2EEGetProcessList\''
			 command = "echo \"su - " + user + " -c \'sapcontrol -nr " + ins + " -function J2EEGetProcessList\'\" | sudo bash"
		    write(logfile1,command)
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    status = stdout.channel.recv_exit_status()
                    out = stdout.readlines()
		    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(out))
#                    print out
#                   print status


                    for i in out:
			if "NIECONN_REFUSED" in i:
                            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " +  ins + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " +  ins + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                            exit()
                        i = (str(i)).split(',')
                        if len(i) == 7:
                            status = i[2].strip()
                            #print status
                            if 'GREEN' in status:
                                out = 'SSSI:F:The server ' + hostname + ' is up and running :' + appsid
                                break
                            elif 'YELLOW' in status:
                                out = 'SSSI:F:The server '+ hostname + ' is running with warning : ' + appsid
                                break

                    if ":F:" in out:

    ##################################################### STOPPING SAP ON REMOTE SERVER ##############################################################

			if sys_type.lower() == "abap":
	                   # command = 'sudo su - ' + user + ' -c "stopsap r3 "'
			    command = "echo \"su - " + user + " -c \"\\\"\"stopsap r3 "+  "\"\\\"|sudo bash"
			    write(logfile1,command)
            	            #print command
	                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	                    status = stdout.channel.recv_exit_status()
	                    stdout = stdout.readlines()
			    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
	                    #print status
	                    if status == 0:
			        print "SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The SAP service has been stopped on the target server - ( " + hostname + ") :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        log = "SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The SAP service has been stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        write (logfile2, log)
        		    else:
	                        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The SAP server has not been successfully stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
            	                log = "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The SAP server has not been successfully stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" +seq_no + ":" + string + ":" + hostname + ":" + appsid
                	        write (logfile2, log)
	                        exit()
	                elif sys_type.lower() == "java":
#	                    command = 'sudo su - ' + user + ' -c "stopsap j2ee "'
			    command = "echo \"su - " + user + " -c \"\\\"\"stopsap j2ee "+  "\"\\\"|sudo bash"
			    write(logfile1,command)
	                    #print command
	                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	                    status = stdout.channel.recv_exit_status()
			    stdout = stdout.readlines()
			    write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
	                    if status == 0:
	                        print "SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The SAP service has been stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        log = "SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The SAP service has been stopped on the target server - ( " + hostname + "):" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        write (logfile2, log)
	                    else:
	                        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The SAP server has not been successfully stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        log = "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The SAP server has not been successfully stopped on the target server - ( " + hostname + " ):" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
	                        write (logfile2, log)
	                        exit()
			
#			command = 'sudo su - ' + user + ' -c \'cleanipc ' + ins+ ' remove\''
			command = "echo \"su - " + user + " -c \'cleanipc " + ins + " remove\'\" | sudo bash"
			write(logfile1,command)
		        #print command
		        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		        status = stdout.channel.recv_exit_status()
			stdout = stdout.readlines()
			write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
		        #print status
#			command = 'sudo su - ' + user + ' -c \'cleanipc ' + ins+ ' remove\''
			command = "echo \"su - " + user + " -c \'cleanipc " + ins + " remove\'\" | sudo bash"
                        write(logfile1,command)
                        #print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        status = stdout.channel.recv_exit_status()
                        stdout = stdout.readlines()
                        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
		        if status == 0:
		            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The CLEANIPC has been successfully completed on the target server - ( '+ hostname + ') :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
		            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The CLEANIPC has been successfully completed on the target server - ( ' + hostname + ') :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
		            write (logfile2, log)
		        else:
		            print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The CLEANIPC has not been successfully done on the target server - ( ' + hostname + ') :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
		            log = 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:The CLEANIPC has not been successfully done on the target server - ( ' + hostname + ' ) :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
		            write (logfile2, log)

                    else:
                        print 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + ins + ' is already stopped : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                        write (logfile2, 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + ins + ' is already stopped : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)
            else:
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                exit()
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" +string + ":" + hostname + ":" + appsid
            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
            exit()

    except Exception as e:
#	exc_type, exc_obj, exc_tb = sys.exc_info()
        if str(e) == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "
	    write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script ")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e)+ ": " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid#+ " " + str(exc_tb.tb_lineno)
            write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ":" + hostname + " " + appsid + " " + seq_no + ":" + string + ":" + hostname + ":" + appsid)


################################################### STOPPING DB ON REMOTE SERVER ##########################################################

#def dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1,logfile2):
def dbstop(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,string):
    try:
        ping(hostname, appsid, seq_no, logfile1, string)
        auth(hostname,username,password,appsid,dbsid,string,seq_no,logfile1,db_type)

        command = "python " + scriptloc.rstrip("/") + "/dbstop " + hostname + " " + username + " " + password + " " + dbsid + " " + db_type + " " + scriptloc + " " + osname + " " + logfile1 + " " + appsid + " " + logfile2 + " " + seq_no + " " + string
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
	out = (out.strip()).split('\n')
        for each in out:
            each = each.strip()
       	    status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
	    if status == 'F':
	        exit()

    except Exception as e:
#	exc_type, exc_obj, exc_tb = sys.exc_info()
        if str(e) == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script"
	    write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid#+ " "  + str(exc_tb.tb_lineno)
            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid)


try:
            hostname = argv[1].lower()
            username = argv[2]
            password = argv[3]
            appsid = argv[4].upper()
            kernel_path = argv[5]
            scriptloc = argv[6]
            sys_type = argv[7]  # ABAP/JAVA
            profile_path = argv[8]
            db_type = argv[9]
            ai_ci_db = argv[10]
            seq_no = argv[11]
            logfile1 = argv[12]
            logfile2 = argv[13]
            dbsid = argv[14]
            osname = argv[15]

            if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
		write(logfile2,"SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The SAP system is stopping:" + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid)
                sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1, logfile2, ai_ci_db, db_type)
            elif ai_ci_db.upper() == "DB":
                #if db_type == "MSS":
                    #dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1, logfile2)
                dbstop(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,ai_ci_db)


except Exception as e:
#    exc_type, exc_obj, exc_tb = sys.exc_info()
    if str(e) == "list index out of range":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script"
	write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script")
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid#+ " " + str(exc_tb.tb_lineno)
        write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid)
