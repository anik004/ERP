################################################################
#  Script Name: wdb_login_wrp
#  Author: Pramodini Prakash
#  Description: Calls the DB login scripts based on the DB type.
################################################################

import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *


try:


	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	dbtype = argv[4].lower()
	dbsid = argv[5]
	dbuser = argv[6]
	dbpasswd = argv[7]
	location = argv[8]

	if dbtype == "ora":
		command = "c:\\python27\\python " + location.rstrip("\\") + "\win04 " + hostname + " " + username + " " + password + " " + dbsid + " " + dbuser + " " + dbpasswd + " " + location
        	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
        	print out	

	elif dbtype == "ada":
		command = "c:\\python27\\python " + location.rstrip("\\") + "\win06 " 
	        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	out, err = command.communicate()
        	print out

	elif dbtype == "db6":
		command = "c:\\python27\\python " + location.rstrip("\\") + "\win05 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

	elif dbtype == "mss":
		command = "c:\\python27\\python " + location.rstrip("\\") + "\win08 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

	elif dbtype == "syb":
		command = "c:\\python27\\python " + location.rstrip("\\") + "\win07 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out


except Exception as e:
    print "WDB_LOGIN_WRP:F:" + str(e)
