################################################################
#  Script Name: user_access_win
#  Author: Pramodini Prakash
#  Description: Checks if the user exists.
################################################################

import os
import getpass
import subprocess
import re
from sys import *
from log4erp import *

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
#    location = argv[4]
    command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"exit\"'
    #print command
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    if 'STATUS_LOGON_FAILURE' in out:
        print 'USER_EXISTENCE:F:user existance check for the ' + hostname + ' is failed'
    else:
        print 'USER_EXISTENCE:P:user existance check for the ' + hostname + ' is successful'

except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
               print "USER_EXISTENCE:F:GERR_0201:Hostname unknown"
        elif str(e).strip() == "list index out of range":
               print "USER_EXISTENCE:F:GERR_0202:Argument/s missing for the script"
        elif str(e) == "Authentication failed.":
               print "USER_EXISTENCE:F:GERR_0203:Authentication failed."
        elif str(e) == "[Errno 110] Connection timed out":
               print "USER_EXISTENCE:F:GERR_0204:Host Unreachable"
        elif "getaddrinfo failed" in str(e):
               print "USER_EXISTENCE:F:GERR_0205: Please check the hostname that you have provide"
        elif "[Errno None] Unable to connect to port 22" in str(e):
               print "USER_EXISTENCE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
        else:
               print "USER_EXISTENCE:F: " + str(e)
