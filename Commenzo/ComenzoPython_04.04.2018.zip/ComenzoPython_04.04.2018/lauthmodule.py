################################################################
#  Script Name: lauthmodule
#  Author: Pramodini Prakash
#  Description: Module to check if authentication of the user is successful. 
################################################################

import paramiko
from paramiko import *
import log4erp
from log4erp import *
import time

def auth(hostname,username,password,appsid,dbsid,string,seqno,logfile,dbtype):
	if string.lower() == "db":
		if dbtype.lower() == "ora":
                    user = "ora" + dbsid.lower()
                elif dbtype.lower() == "db6":
                    user = "db2" + dbsid.lower()
                elif dbtype.lower() == "hdb":
                    user = dbsid.lower() + "adm"
                elif dbtype.lower() == "syb":
                    user = dbsid.lower() + "adm"
        #        elif dbtype.lower() == "ada":
        #            user = 
        else:
                user = appsid.lower() + "adm"

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

        command="sudo su - root '-c grep -iw ^" + user+ " /etc/passwd'"
	write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	write(logfile,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
        if status == 1:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:Authentication failed : " + hostname + "_" + appsid.upper() + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:Authentication failed : " + hostname + "_" + appsid.upper() + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid)
		exit()
        else:
#                print "USER_EXISTENCE:P:User existence check for " + user + " using sudo user ( " + username + " ) is successful : " + hostname + "_" + appsid.upper() + "_" + seqno
		write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:Authentication successful : " + hostname + "_" + appsid.upper() + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid)
        channel.close()
        client.close()
