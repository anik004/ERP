print 'SSS:W:The database type "DB2" is not supported'
