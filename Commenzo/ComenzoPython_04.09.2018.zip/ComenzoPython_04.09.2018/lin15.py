print 'SSS:W:The database type "Hana" is not supported'
