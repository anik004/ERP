print 'SSS:W:The database type "Sybase" is not supported'
