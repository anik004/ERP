print 'SSS:W:The database type "MaxDB" is not supported'
