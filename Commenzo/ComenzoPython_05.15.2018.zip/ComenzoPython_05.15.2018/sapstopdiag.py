################################################################
#  Script Name: sapstopdiag
#  Author: Pramodini Prakash
#  Description: Stops the Diagnostic agent.
################################################################

import paramiko
from paramiko import *
from sys import *
from log4erp import *
import re
import time

try:
#    if argv[1] == "--u":
#        print "Usage: python sapstopapp.py <Target application Host> <Target application Login User Name> <Target application User Password> <Target Application SID> <Instance ID> <Instance Host> <reference ID>"
#    else:
#   if len(argv) < 5:
#        print "SAPSTOPDIAG:F:  Argument/s missing for the script [Error Code - 1202]"
#   else:

        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        logfile = argv[5] + ".log"
        host = argv[4]
	seq_no = argv[6]
	string = argv[7]

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()
	
	command = 'echo \"su - dapadm\"| sudo bash'
#       print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.readlines()[0]
#       print str(status)
        a= "su: user dapadm does not exist"
#       print a
        if str(status).strip() == str(a):
        	print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The user dapadm does not exist and SMDA96 agent does not exist:" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                log=" SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The user dapadm does not exist and SMDA96 agent does not exist:" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                write (logfile, log)
           	exit()
#	command = 'sudo su - dapadm -c "stopsap SMDA96"'
	command = "echo \"su - dapadm  -c \"\\\"\" stopsap SMDA96 \"\\\"|sudo bash"
        #print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
        if status == 0:
                print "SAPSTOPDIAG:P: The SMDA96 agent has been stopped on the target server (HOSTNAME - " + host + "):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                log = "SAPSTOPDIAG:P:The SMDA96 agent has been stopped on the target server (HOSTNAME - " + host + "):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                write (logfile, log)
		"""

		command = 'sudo su - dapadm -c "stopsap sapstartsrv "'
	        #print command
        	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        status = stdout.channel.recv_exit_status()
        	if status == 0:
                	print "SAPSTOPDIAG:P: The sapstartsrv service has been stopped on the target server (HOSTNAME - " + host + ")"
	                log = "SAPSTOPDIAG:P:The sapstartsrv service has been stopped on the target server (HOSTNAME - " + host + ")"
        	        write (logfile, log)
		"""	
#		command = 'sudo su - dapadm -c "cleanipc 96 remove"'
		command = "echo \"su - dapadm  -c \"\\\"\"cleanipc 96 remove\"\\\"|sudo bash"
		#print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		status = stdout.channel.recv_exit_status()
		#print status
#		command = 'sudo su - dapadm -c "cleanipc 96 remove"'
		command = "echo \"su - dapadm  -c \"\\\"\"cleanipc 96 remove\"\\\"|sudo bash"
                #print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()

		if status == 0:
		#	print 'SAPSTOPDIAG:P: The CLEANIPC has been successfully completed on the target server (HOSTNAME - ' + host + ')'
		#	log = 'SAPSTOPDIAG:P:The CLEANIPC has been successfully completed on the target server (HOSTNAME - ' + host + ')'
			print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The CLEANIPC has been successfully completed on the target server (HOSTNAME - " + host +" ):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
			log = " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The CLEANIPC has been successfully completed on the target server (HOSTNAME - " + host + "):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
			write (logfile, log)
		else:
#			print 'SAPSTOPDIAG:F: The CLEANIPC has not been successfully done on the target server (HOSTNAME - ' + host + ')'
#		        log = 'SAPSTOPDIAG:F:The CLEANIPC has not been successfully done on the target server (HOSTNAME - ' + host + ')'
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The CLEANIPC has not been successfully done on the target server (HOSTNAME - " + host + "):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
			log = "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The CLEANIPC has not been successfully done on the target server (HOSTNAME - " + host + "):" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"


		        write (logfile, log)

	        """
		else:
        	        print "SAPSTOPDIAG:F: The sapstartsrv server has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
                	log = "SAPSTOPDIAG:F:The sapstartsrv server has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
	                write (logfile, log)
		"""
        	       
        else:
#                print "SAPSTOPDIAG:F: The SMDA96 agent has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The SMDA96 agent has not been successfully stopped on the target server (HOSTNAME - " + host + ") :" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

#               log = "SAPSTOPDIAG:F:The SMDA96 agent has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
		log = " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The SMDA96 agent has not been successfully stopped on the target server (HOSTNAME - " + host + ") :" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                write (logfile, log)
            
        channel.close()
        client.close()
except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
#                print "SAPSTOPDIAG:F:GERR_1201:Hostname unknown"
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:SAPSTOPDIAG:F:GERR_1201:Hostname unknown (HOSTNAME - " + host + ") :" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

                write(logfile," SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:Hostname unknown [Error Code - 1201](HOSTNAME - " + host + ") :" + host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")

     elif str(e) == "list index out of range":
#                print "SAPSTOPDIAG:F:GERR_1202:Argument/s missing for the script"
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script"

#                write(logfile," SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")

     elif str(e) == "Authentication failed.":
  #              print "SAPSTOPDIAG:F:GERR_1203:Authentication failed."
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1203:Authentication failed. (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

#                write(logfile," SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1203:Authentication failed.(HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

     elif str(e) == "[Errno 110] Connection timed out":
#                print "SAPSTOPDIAG:F:GERR_1204:Host Unreachable"
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1204:Host Unreachable (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

                write(logfile," SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1204:Host Unreachable (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")

     elif "getaddrinfo failed" in str(e):
#                print "SAPSTOPDIAG:F:GERR_1205: Please check the hostname that you have provide"
		print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1205: Please check the hostname that you have provide (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"


                write(logfile," SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1205: Please check the hostname that you have provide (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
#                print "SAPSTOPDIAG:F:GERR_1206:Host Unreachable or Unable to connect to port 22"
		 print " SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1206:Host Unreachable or Unable to connect to port 22 (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"
                 write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:Host Unreachable or Unable to connect to port 22 [Error Code - 1206](HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")
     elif "invalid decimal" in str(e):
#                print "SAPSTOPDIAG:F:GERR_1207:Unknown Error:" + str(e)
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:GERR_1207:Unknown Error: (HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

                write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:Unknown Error:" + str(e) + "[Error Code - 1207](HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP")
     else:
#                print "SAPSTOPDIAG:F:" + str(e)
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S")+ ":F:" + str(e) + "(HOSTNAME - " + host + ") :"+ host + "_DAP _" + seq_no + ":" + string + ":" + host + ":DAP"

               
