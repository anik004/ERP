################################################################
#  Script Name: wrp_startstop
#  Author: Pramodini Prakash
#  Description: Wrapper to call the start/stop script based on the action.
################################################################

from sys import *
import sys
import paramiko
from paramiko import *
import subprocess
import log4erp
from log4erp import *
import os
import time

################################################################################################################
############################################### start function #################################################
################################################################################################################
def startsap(hostname,username,password,appsid,kernel_path,scriptloc,sys_type,profile_path,db_type,ai_ci_db,seqno,logfile1,logfile2,dbsid,osname):
    try:
        if osname.lower() == "windows":
            command = "c:\\python27\\python.exe " + scriptloc.strip("\\") + "\startwin " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seqno + " " + logfile1 + " " + logfile2 + " " + dbsid + " " + osname
            #print command
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print out
            out = (out.strip()).split('\n')
            for each in out:
                each = each.strip()
                if "SSS" in each:
                    status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
                    #print status
                    if status == 'F':
                        exit()
        else:
            command = "python " + scriptloc.rstrip("/") + "/startlin " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seqno + " " + logfile1 + " " + logfile2 + " " + dbsid + " " + osname
#            print command
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print out
            out = (out.strip()).split('\n')
            for each in out:
                each = each.strip()
                status = (each.split('\n')[len(each.split('\n')) - 2]).split(":")[2]
                #print status
                if status == 'F':
                    exit()

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        if str(e) == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script " + " " + str(exc_tb.tb_lineno)
	    write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script ")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db + ":" + hostname + ":" + appsid
            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db + ":" + hostname + ":" + appsid)

##################################################################################################################
####################################### Stop function ############################################################
##################################################################################################################
def stopsap(hostname,username,password,appsid,kernel_path,scriptloc,sys_type,profile_path,db_type,ai_ci_db,seqno,logfile1,logfile2,dbsid,osname):
    try:
        if osname.lower() == "windows":
            command = "c:\\python27\\python.exe " + scriptloc.strip("\\") + "\stopwin " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seqno + " " + logfile1 + " " + logfile2 + " " + dbsid + " " + osname
            #print command
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print out
            out = (out.strip()).split('\n')
            for each in out:
                #print each
                each = each.strip()
                if "SSS" in each:
                    status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
                    if status == 'F':
                        exit()
        else:
            command = "python " + scriptloc.rstrip("/") + "/stoplin " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seqno + " " + logfile1 + " " + logfile2 + " " + dbsid + " " + osname
 #           print command
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print out
            out = (out.strip()).split('\n')
            for each in out:
                each = each.strip()
                status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
                if status == 'F':
                    exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "
	    write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script ")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db + ":" + hostname + ":" + appsid
            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db + ":" + hostname + ":" + appsid)

################################################################################################################
############################################# main logic start #################################################
################################################################################################################
try:
    file_path = argv[1]
    seqno = argv[2]
    list1 = open(file_path)
    main_list = list1.readlines()

    seno = ''
    dict_sid = {}
#    all_sid = ''

########################################### get the data ####################################
    for each in main_list:
        l = each.split("|")
        if l[9] == seno:
            dict_sid[seno].append(each)
        else:
            seno = l[9]
#            all_sid = all_sid + " " + sid
            dict_sid[seno] = [each] ############ dicto for each SID

#    all_sid = all_sid.split() ################# List of the SIDs

    if seqno in dict_sid.keys():
##############################################################################
        len_list = len(dict_sid[seqno])
##############################################################################
        start = 0
        for each in dict_sid[seqno]:
            start = start + each.count("|START|") ####### Start Count
        print "start: " + str(start)

###############################################################################
        stop = 0
        for each in dict_sid[seqno]:
            stop = stop + each.count("|STOP|") ########## Stop Count
        print "Stop: " + str(stop)

###############################################################################
        restart = 0
        for each in dict_sid[seqno]:
            restart = restart + each.count("|RESTART|") ## Restart Count
        print "restart: " + str(restart)

###############################################################################
        if len_list == start: ######################## for start
            for each in reversed(dict_sid[seqno]):
                arg = each.replace("|"," ")
                arg = arg.split()
                #print arg
                startsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

        elif len_list == stop: ###################### for stop
            for each in dict_sid[seqno]:
                arg = each.replace("|"," ")
                arg = arg.split()
#		print arg[5] + "|" + arg[7] + "|" + arg[8] + "|" + arg[1] + "|" + arg[11] + "|" + arg[15] + "|" + arg[3] + "|" + arg[12] + "|" + arg[13] + "|" + arg[4] + "|" + arg[14] +"ourref.log|" + arg[0] + "|" +arg[2] + "|" + arg[6]
                stopsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

        elif len_list == restart: ################## for restart
            for each in dict_sid[seqno]:
                arg = each.replace("|"," ")
                arg = arg.split()
                stopsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])
            for each in reversed(dict_sid[seqno]):
                arg = each.replace("|"," ")
                arg = arg.split()
                startsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

        elif len_list > restart: ################# for combination of start, stop and restart
            res_list1 = []
            res_list2 = []
            for each in dict_sid[seqno]:
                if "|CI|" in each:
                    res_list1.append(each)
                if "|DB|" in each:
                    res_list1.append(each)
            for each in dict_sid[seqno]:
                if "|AI|" in each:
                    res_list2.append(each)
            for each in res_list2:
                if "|STOP|" in each:
                    arg = each.replace("|"," ")
                    arg = arg.split()
                    stopsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])
            for each in res_list1:
                arg = each.replace("|"," ")
                arg = arg.split()
                stopsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

            for each in reversed(res_list1):
                arg = each.replace("|"," ")
                arg = arg.split()
                startsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

            for each in res_list2:
                if "|START|" in each:
                    arg = each.replace("|"," ")
                    arg = arg.split()
                    startsap(arg[5],arg[7],arg[8],arg[1],arg[11],arg[15],arg[3],arg[12],arg[13],arg[4],arg[14],"ourref.log",arg[0] + ".log",arg[2],arg[6])

    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The sequence number " + seqno + " passed is wrong"
	write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The sequence number " + seqno + " passed is wrong")

    print "EOE"

    list1.close()

############################################################################################
################################# Exception and Error ######################################
############################################################################################
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()

    """if str(e) == "list index out of range":
                print "list index out of range"
#            print "WRP_STARTSTOP:F:GERR_1202:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seqno
        else:
#            print "WRP_STARTSTOP:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno
#            write(logfile1, "WRP_STARTSTOP:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seqno)
                print "error: " + str(e) #+ " " + str(exc_tb.tb_lineno)"""

    if str(e) == "list index out of range":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "+ " " + str(exc_tb.tb_lineno)
	write(argv[0],"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script ")
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) #+ " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db
        write(argv[0], "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " " + str(exc_tb.tb_lineno))#+ " : " + hostname + "_" + appsid + "_" + seqno + ":" + ai_ci_db)

