################################################################
#  Script Name: win_chk_wrp
#  Author: Pramodini Prakash
#  Description: Wrapper to call the check script.
################################################################

import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *


try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	dbsid = argv[5]
	string = argv[6]
	dbtype = argv[7]
	dbuser = argv[8]
	dbpasswd = argv[9]
	location = argv[10]

	command = "c:\\python27\\python " + location.rstrip("\\") + "\ping " + hostname + " " + string
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out

	command = "c:\\python27\\python " + location.rstrip("\\") + "\user_access_win " + hostname + " " + username + " " + password + " " + location
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out

	command = "c:\\python27\\python " + location.rstrip("\\") + "\wdb_login_wrp " + hostname + " " + username + " " + password + " " + dbtype + " " + dbsid + " " + dbuser + " " + dbpasswd + " " + location
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out

except Exception as e:
    print "WIN_CHK_WRP:F:" + str(e)
