################################################################
#  Script Name: startwin
#  Author: Pramodini Prakash
#  Description: Starts the SAP system.
################################################################

import re
import log4erp
from log4erp import *
from sys import *
import sys
import subprocess
import os
import authmodule
from authmodule import *
import pingmodule
from pingmodule import *
import time

def sapstart(hostname,username,password,appsid,sys_type,profile_path,kernel_path,script_loc,seq_no,logfile1, logfile2,string):
    try:
        ping(hostname, appsid, seq_no, logfile1,string)
        auth(hostname, username, password, appsid, script_loc, seq_no, logfile1,string)
        
        #################################################### FOLDER EXISTENCE CHECK ON REMOTE SERVER #####################################


        command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + kernel_path + '"'
        #print command
        write(logfile1,command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)

        #################   CHECKING PROFILE PATH EXISTENCE ON REMOTE SERVER ###################################

        if "True" in out:
            command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + profile_path + '"'
            #print command
            write(logfile1,command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            #print out
            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)

            if "True" in out:
                profile_path = profile_path
                command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' " dir ' + profile_path + ' " '
                #print command
                write(logfile1,command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                #print out
                write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") +  " " + out)
                a = out.split("\n")
                #print a
                b = hostname + "."
                #print hostname
                arr = ""
                a = a[5:]
                #print a
                for dirs in a:
                    #print hostname
                    if hostname in dirs:
                        #print dirs
                        if b in dirs or "sapmnt" in dirs: #or "ASCS" in dirs:
                            c = ""
                        else:
                            #print dirs
                            c = dirs.split()
                            c = c[-1]
                            #print c
                            arr = arr +" " + c
                arr = arr.split(" ")
                arr = filter(None,arr)
                #print arr

                inst = " "
                for p in arr:
                    instance = p.split("_")
                    if string == "AI" and "D" in instance[1] or "ASCS" in instance[1] and len(instance[1]) == 3 :
                            ins = instance[1][-2:]
                            inst = ins + " " + inst
                    elif string == "CI" and "DVEBMGS" in instance[1] or "ASCS" in instance[1]:
                            ins = instance[1][-2:]
                            #print ins
                            inst = ins + " " + inst

                inst = inst.split(" ")
                inst = filter(None,inst)
    
                #print inst
        

        ##################################################### SAP STATUS CHECK = RUNNING/STOPPED/INTERMEDIATE ###########################

                for ins in reversed(inst):
                        #print ins
                        if sys_type.lower() == 'abap':
                            command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function GetProcessList' + '\"'
                            write(logfile1, command)
                            #print command
                        elif sys_type.lower() == 'java':
                            command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function J2EEGetProcessList' + '\"'
                            write(logfile1, command)

                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        #print "-----------------"
                        #print out
                        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)    

                        if "NIECONN_REFUSED" in out:
                            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " + ins + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " + ins + " passed is incorrect :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                            exit()

                        out = out.split("\n")

                        for i in out:
                            i = (str(i)).split(',')
                            if len(i) == 7:
                                status = i[2].strip()
                                #print status
                                #if 'GREEN' in status:
                                #    out = 'SSSI:P:The server ' + hostname + ' is up and running :' + appsid
                                if 'YELLOW' in status:
                                    out = 'SSSI:F:The server '+ hostname + ' is running with warning : ' + appsid
                                    break
                                elif 'GRAY' in status:
                                    out = 'SSSI:F:The server ' + hostname + ' is stopped :' + appsid
                                    break
                                elif 'GREEN' in status:
                                    out = 'SSSI:P:'
                                else:
                                    out = 'SSSI:F:The server ' + hostname + ' is stopped :' + appsid

                        #print out
                        #status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]

                        if ":F:" in out:

                            #################################################################KILLING SAP PROCESSES########################################################
                            command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "tasklist | findstr sap "'
                            write(logfile1,command)
                            command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                            out, err = command.communicate()
                            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
                            #print out
                            out = (out.strip()).split()
                            services = []
                            for each in out:
                                if "sap" in each:
                                    if "sapstartsrv.exe" in each:
                                        continue
                                    services += [each]

                            #print services

                            for each in services:
                                command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "taskkill /IM ' + each + ' /F"'
                                write(logfile1,command)
                                #print command
                                command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
                                #print out

                                out = (out.strip()).split("\n")
                                #print out

                                for each in out:
                                    if 'SUCCESS' in each:
                                        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":I: The processes related to the SAP has been stopped in the target application server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                                        log = "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":I: The processes related to the SAP has been stopped in the target application server - ( " + hostname + " ) :" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                                        write (logfile2, log)


                ##################################################### STARTING SAP ON REMOTE SERVER ##############################################################

                            if sys_type.lower() == 'abap':
                                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & startsap.exe name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                                write(logfile1,command)
                                #print command
                            elif sys_type.lower() == 'java':
                                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & startsap.exe j2ee name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                                write(logfile1,command)

                            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                            out, err = command.communicate()
                            #print out
                            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)

                            if "STARTSAP failed" in out:
                                print 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:The sap system has not been started on the target server - ( ' + hostname + ') : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                                write (logfile2, 'SSSI:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:The sap system has not been started on the target server - ( ' + hostname + ') : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)
                                exit()
                            else:
                                print 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system has been started successfully on the target server - ( ' + hostname + ') : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                                write (logfile2, 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system has been started successfully on the target server - ( ' + hostname + ') : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)
                        else:
                            print 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system is already started on the target server - ( ' + hostname + ' ) :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                            write (logfile2, 'SSSH:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system is already started on the target server - ( ' + hostname + ') :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)

            else:
                print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                exit()

        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
            write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
            exit()

    except Exception as e:
#        exc_type, exc_obj, exc_tb = sys.exc_info()
        if str(e) == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script" #+ " " + str(exc_tb.tb_lineno)
	    write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid #+ " " + str(exc_tb.tb_lineno)
            write(logfile2, "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no + ":" +string + ":" + hostname + ":" + appsid)


#def dbstart(hostname, username, password, appsid, script_loc, seq_no, logfile1, logfile2):
def dbstart(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,string):
    try:
        ping(hostname, appsid, seq_no, logfile1,string)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1,string)

        command = "c:\\python27\\python.exe " + scriptloc + "\dbstart " + hostname + " " + username + " " + password + " " + dbsid + " " + db_type + " " + scriptloc + " " + osname + " " + logfile1 + " " + appsid + " " + logfile2 + " " + seq_no + " " + string
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
        out = (out.strip()).split('\n')
        for each in out:
            each = each.strip()
            status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
            if status == 'F':
                exit()


    except Exception as e:
#        exc_type, exc_obj, exc_tb = sys.exc_info()
        if str(e).strip() == "list index out of range":
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_3002:Argument/s missing for sapstartapp script" #+ " " + str(exc_tb.tb_lineno)
	    write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_3002:Argument/s missing for sapstartapp script")
        else:
            print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid# + " " + str(exc_tb.tb_lineno)
            write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" +string + ":" + hostname + ":" + appsid)

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    appsid = argv[4].upper()
    kernel_path = argv[5]
    scriptloc = argv[6]
    sys_type = argv[7]  # ABAP/JAVA
    profile_path = argv[8]
    db_type = argv[9]
    ai_ci_db = argv[10]
    seq_no = argv[11]
    logfile1 = argv[12]
    logfile2 = argv[13]
    dbsid = argv[14]
    osname = argv[15]

    if ai_ci_db.upper() == "CI" or ai_ci_db.upper() == "AI":
	write(logfile2,"SSSH:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The SAP system is starting:" + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid)
        sapstart(hostname, username, password, appsid, sys_type, profile_path, kernel_path, scriptloc, seq_no, logfile1, logfile2,ai_ci_db)

    elif ai_ci_db.upper() == "DB":
        #if db_type == "MSS":
            #dbstart(hostname, username, password, appsid, scriptloc, seq_no, logfile1, logfile2)
	    dbstart(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,ai_ci_db)


except Exception as e:
#    exc_type, exc_obj, exc_tb = sys.exc_info()
    if str(e).strip() == "list index out of range":
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_3002:Argument/s missing for sapstartapp script"# + " " + str(exc_tb.tb_lineno)
	write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_3002:Argument/s missing for sapstartapp script")
    else:
        print "SSSI:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid #+ " " + str(exc_tb.tb_lineno)
        write(logfile2,"SSSI:" + time.strftime("%Y-%m-%d-%H-%M-%S") + ":F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" + ai_ci_db + ":" + hostname + ":" + appsid)
