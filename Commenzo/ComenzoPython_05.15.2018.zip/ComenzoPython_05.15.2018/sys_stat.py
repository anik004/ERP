################################################################
#  Script Name: sys_stat
#  Author: Pramodini Prakash
#  Description: Checks whether the system is up or not.
################################################################

import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	app_sid = argv[4]
	user = app_sid.lower() + 'adm'
	kernel_path = argv[5]
	os_name = argv[6]
	sys_type = argv[7]
	location = argv[8]   #script_path
	instance = argv[9]
#	print kernel_path
	db_sid = argv[10]
	string = argv[11]
	db_type = argv[12].lower()
#	profile_path = argv[13]

	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
	channel = client.invoke_shell()

	"""
	kernel_path="sudo su - " + user  + " -c \"which disp+work | sed 's/\/disp+work//'\""
        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        kernel_path=stdout.readlines()
        kernel_path=kernel_path[0]
        kernel_path=kernel_path.strip()
#	print kernel_path
	
	command = kernel_path + '/sapcontrol -nr 00 -function GetSystemInstanceList | grep -i --color=never ' + hostname
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	output = stdout.readlines()
#	print output
	for each in output:
		each = each.split(',')
	#	print each[len(each) - 1].strip()
		color= each[len(each) - 1].strip()
	#	print each[5].strip()
		ser= each[5].strip()
		#print each[0]
		if color == 'GRAY':
			print "SSS:F:The server "+ hostname + ' is stopped' 
			exit()
		if color == 'YELLOW':
			print 'SSS:F:The server '+ hostname + ' is running with warning '
			exit()
#		if color == 'GREEN':
#			print ser+ ' is running in the ' + hostname

	"""
#	print command
	if string == "AI" or string == "CI":
		if os_name.lower() == 'windows':
			if sys_type.lower() == 'abap':
				command = 'c:\python27\python ' + location.strip('\\') + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + instance + ' -function GetProcessList' + '\"'
			elif sys_type.lower() == 'java':
				command = 'c:\python27\python ' + location.strip('\\') + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + instance + ' -function J2EEGetProcessList' + '\"'
	    #print command
    			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    			out, err = command.communicate()
	    		status = command.returncode

		else:
			if sys_type.lower() == 'abap':
	                	#command = 'sudo su - ' + user  + ' -c \'sapcontrol -nr ' + instance + ' -function GetProcessList\''
				command = "echo \"su - " + user + ' -c \'sapcontrol -nr ' + instance + " -function GetProcessList\'\" | sudo bash"
				
	        	elif sys_type.lower() == 'java':
				command = "echo \"su - " + user + ' -c \'sapcontrol -nr ' + instance + " -function J2EEGetProcessList\'\" | sudo bash"
#        	        	command = 'sudo su - ' + user  + ' -c \'sapcontrol -nr ' + instance + ' -function J2EEGetProcessList\''
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        	status = stdout.channel.recv_exit_status()
			out = stdout.readlines()
	#		print out
	#		print status
		for i in out:
			
			i = (str(i)).split(',')
	#		i = i.split(',')
			if len(i) == 7:
				status = i[2].strip()
	#			print status
				server = i[1].strip() 
				if status == 'GREEN':
					print 'SSS:P:The server ' + hostname + ' is up and running'
					exit()
				if status == 'YELLOW':
			 		print 'SSS:F:The server '+ hostname + ' is running with warning'
					exit()
				if status == 'GRAY':
			 		print 'SSS:F:The server ' + hostname + ' is stopped' 
					exit()
	#	print 'SSS:P:The server ' + hostname + ' is up and running'
	
	
	elif string == "DB":
		if db_type == "ora":
			command = "python " + location.rstrip("/") + "/db_check " + hostname + " " + username + " " + password + " " + db_sid + " " + db_type
			command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	        	out, err = command.communicate()
			print out

		elif db_type == "hdb":

			user =  db_sid.lower() + "adm"
			profile_path = "/usr/sap/" + db_sid.upper() + "/SYS/profile"

			command = "cd " + profile_path + ";ls"
			print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
			print out

			inst = ""
			for file in out:
				file = file.split()
			        for instance in file:
			            if db_sid.upper() in instance:
			                inst = instance + " " + inst

			instance_no = inst.split()
			print instance_no

			if len(inst) == 0:
			        print "WRPHANASTART:F:could not find the instance no"
			else:
			        for ins in instance_no:
			            ins = ins.split("_")
			            ins = ins[1][-2:]

			            command = 'echo "su - ' + user + ' -c "\\"/usr/sap/hostctrl/exe/sapcontrol -nr ' + ins + ' -function GetProcessList \\"""|sudo bash'
			            print command
			            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			            out = stdout.readlines()
			            print out

				    for i in out:
			                i = (str(i)).split(',')
			                if len(i) == 7:
			                    status = i[2].strip()
			      #              print status
			                    if 'GREEN' in status:
			                        print 'SSS:P:The server ' + hostname + ' is up and running'
						exit()
			                    elif 'YELLOW' in status:
			                        print 'SSS:F:The server ' + hostname + ' is running with warning'
						exit()
			                    elif 'GRAY' in status:
			                        print 'SSS:F:The server ' + hostname + ' is stopped '
			                        exit()

		
		elif db_type == "db6":
			
                        command = "ps -eaf | grep -i db2sysc | grep -i " + db_sid.lower() + "adm | grep -v \"grep\""
			print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = stdout.read()
                        print out	


			if "db2sysc" in str(out):
				print 'SSS:P:Database is running'
				exit()
			else:
				print 'SSS:F:Database is down'
				exit()

		elif db_type == "syb":

			db_user = argv[13]
			db_pass = argv[14]

#			command = 'echo "su - ' + db_sid.lower() + 'adm -c \\\"isql -U' + db_user + ' -P' + db_pass + ' -S' + db_sid.upper() + ' -X\\\"" | sudo bash'
			command = 'echo "su - syb' + db_sid.lower() + ' -c \\\"ps -ef | grep syb' + db_sid.lower() + '\\\"" | sudo bash'
                        print command
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        out = stdout.read()
                        print out

#			if ">" in str(out) or "ct_connect()" not in str(out):
			if "dataserver" in str(out) and "backupserver" in str(out) and "jsagent" in str(out):
				print 'SSS:P:Database is running'
                                exit()
                        else:
                                print 'SSS:F:Database is down'
                                exit()

	channel.close()
	client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "status:F:GERR_1101:Hostname unknown"
 #               write(logfile,'PRE:F:Hostname unknown [Error Code - 1101]')
     elif str(e) == "list index out of range":
                print "status:F:GERR_1102:Argument/s missing for the script"
  #              write(logfile,'PRE:F:Argument/s missing for the script [Error Code - 1102]')
     elif str(e) == "Authentication failed.":
                print "status:F:GERR_1103:Authentication failed."
#                write(logfile,'PRE:F:Authentication failed.[Error Code - 1103]')
     elif str(e) == "[Errno 110] Connection timed out":
                print "status:F:GERR_0504:Host Unreachable"
   #             write(logfile,'PRE:F:GERR_0504:Host Unreachable')
     elif "getaddrinfo failed" in str(e):
                print "status:F:GERR_0505: Please check the hostname that you have provide"
    #            write(logfile,'PRE:F:GERR_0505: Please check the hostname that you have provide')
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "status:F:GERR_0506:Host Unreachable or Unable to connect to port 22"
     #           write(logfile,'PRE:F:GERR_0506:Host Unreachable or Unable to connect to port 22')
     elif "invalid decimal" in str(e):
                print "status:F:GERR_0507:Unknown Error:" + str(e)
      #          write(logfile,'PRE:F:GERR_0507:Unknown Error:' + str(e))
     else:
                print "status:F:" + str(e)

