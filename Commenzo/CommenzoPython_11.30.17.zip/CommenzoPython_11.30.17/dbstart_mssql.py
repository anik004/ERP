from sys import *
import subprocess
import os
import time
from log4erp import *


try:	
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	location = argv[4].rstrip('\\')
	logfile1 = argv[5]
	app_sid = argv[7]
	logfile2 = argv[8]
	seqno = argv[9]
	string = argv[10]

	final = []
###################################### FETCHING SERVICES STARTING WITH SQL #####################################

	command = 'c:\\python27\\python.exe '+location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SQL\\" "'
	#print command
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
	#print out
	out = (out.strip()).split()
	#print out
	for each in out:
		if "SQL" in each:
			final += [each]
	#print final

###################################### FETCHING SERVICES STARTING WITH MSSQL #####################################

	command = 'c:\\python27\\python.exe '+location + '\wmiexec.py  ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: MSSQL\\" "'
	write(logfile1,command)
	#print command
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, time.strftime("%Y-%m-%d %H-%M-%S") + " " + out )
	#print out
	out = (out.strip()).split()
	#print out
	for each in out:
	        if "MSSQL" in each:
	                final += [each]
	#print final
	for ser in final:
		if "$SQL" in ser:
                        ser = ser.replace("$","\$")
                        #print ser
###################################### STARTING ALL THE DB SERVICES #####################################
		command = 'c:\\python27\\python.exe '+location + '\wmiexec.py  ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "net start "' + ser + '" "'
		write(logfile1,command)
		#print command
		command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1, time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
		if "service has already been started" in out:
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has been already started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
			write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has been already started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
		elif "service was started successfully" in out:
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser +"has been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
			write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser +"has been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
		else:
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The service " + ser + " has not been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname  + ":" + app_sid
			write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The service " + ser + " has not been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
			exit()
	print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: DB has been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
	write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: DB has been started successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "list index out of range":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
               # write(logfile,'SSS:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "getaddrinfo failed" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "invalid decimal" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     else:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
		write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

