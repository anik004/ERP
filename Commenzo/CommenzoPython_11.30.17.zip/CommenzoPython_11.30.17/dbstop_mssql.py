import log4erp
from log4erp import *
from sys import *
import subprocess
import time

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	location = argv[4].strip("\\")		#script location
	logfile1 = argv[5]
	app_sid = argv[7]
	logfile2 = argv[8]
	seqno = argv[9]
	string = argv[10]

	final = []

###################################### FETCHING SERVICES STARTING WITH SQL #####################################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SQL\\" "'
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
	#print out
	out = (out.strip()).split()
	#print out
	for each in out:
		if "SQL" in each:
			final += [each]
	#print final
###################################### FETCHING SERVICES STARTING WITH MSSQL #####################################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: MSSQL\\" "'
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
	#print out
	out = (out.strip()).split()
	#print out
	for each in out:
	        if "MSSQL" in each:
	                final += [each]
	#print final
	for ser in final:
		if "$SQL" in ser:
			ser = ser.replace("$","\$")
			#print ser
###################################### STOPPING ALL THE DB SERVICES #####################################

		command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "net stop "' + ser + '" "'
		write(logfile1,command)
		command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
		#print out
		if "service is not started" in out:
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has already been stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
			write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has already been stopped on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
		elif 'service was stopped successfully' in out:
			print "SSS: " + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has been stopped successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
			write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The service " + ser + " has been stopped successfully on the target server - ( " + hostname + " ) :" + hostname + "_" +  app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
		else:
			print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The service " + ser + " has not been stopped successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
			write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The service " + ser + " has not been stopped successfully on the target server -( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)
			exit()
	print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: DB has been stopped successfully on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
	write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: DB has been stopped successfully on the target server - ( " + hostname + " ) :" + hostname + "_" +  app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

except Exception as e:
	if str(e) == "list index out of range":
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
#		write(logfile2," SSS:F:GERR_1302:Argument/s missing for the script :" + hostname + "_" + app_sid + "_" + seqno)
	else:
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
		write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

