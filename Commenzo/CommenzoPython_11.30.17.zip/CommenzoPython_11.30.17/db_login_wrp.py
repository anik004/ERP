import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *


try:


	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	dbtype = argv[4].lower()
	dbsid = argv[5]
	dbuser = argv[6]
	dbpasswd = argv[7]
	location = argv[8]

	if dbtype == "ora":
		command = "python " + location.rstrip("/") + "/lin10 " + hostname + " " + username + " " + password + " " + dbsid + " " + dbuser + " " + dbpasswd
        	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
        	print out	

	elif dbtype == "ada":
		command = "python " + location.rstrip("/") + "/lin11 " 
	        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	out, err = command.communicate()
        	print out

	elif dbtype == "db6":
		command = "python " + location.rstrip("/") + "/lin12 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

	elif dbtype == "syb":
		command = "python " + location.rstrip("/") + "/lin14 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

	elif dbtype == "hdb":
		command = "python " + location.rstrip("/") + "/lin15 "
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

except Exception as e:
    print "DB_LOGIN_WRP:F:" + str(e)
