from sys import *
import sys
import subprocess
from subprocess import *
from log4erp import *
import time

try:
	hostname = argv[1]
	username_db = argv[2]
	password_db = argv[3]
	db_sid = argv[4]
	db_type = argv[5].lower()
#	drive = argv[6]
	location = argv[6]
	os_name =argv[7].lower()
	logfile1 = argv[8]
	appsid = argv[9]
	logfile2 = argv[10]
	seqno = argv[11]
	string = argv[12]

	if os_name == "windows":
		if db_type == "ora":
			dbname = "orawin"
		elif db_type == "db6":
			dbname = "db2win"
		elif db_type == "mss":
			dbname = "mssql"
		elif db_type == "syb":
			dbname = "sybwin"
		elif db_type == "ada":
			dbname = "maxdb"
	else:

		if db_type == "ora":
			dbname = "oracle"
		elif db_type == "db6":
			dbname = "db2"
		elif db_type == "hdb":
			dbname = "hana"
		elif db_type == "syb":
			dbname = "sybase"
		elif db_type == "ada":
			dbname = "maxdb"
	
	if os_name == "windows":
		command = "c:\\python27\\python " + location.strip("\\") + "\dbstart_" + dbname + " " + hostname + " " + username_db + " " + password_db + " " + location + " " + logfile1 + " " + db_sid + " " + appsid + " " + logfile2 + " " + seqno + " " + string
	else:
		command = "python " + location.rstrip("/") + "/dbstart_" + dbname + " " + hostname + " " + username_db + " " + password_db + " " + db_sid + " " + logfile1 + " " + appsid + " " + logfile2 + " " + seqno + " " + string
	
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	print out
	out = (out.strip()).split('\n')
	for each in out:
		each = each.strip()
		status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
		#print status
		if status == 'F':
			exit()
	"""if status == "F":
	    print "SSS:F:The script dbstart_" + dbname + ".py has failed:" + hostname + "_" + appsid + "_" + seqno
	    log = "SSS:" + time.strftime("%Y-%m-%d-%H-%M-%S") + ":F: The script dbstart_" + dbname + ".py has failed:" + hostname + "_" + appsid + "_" + seqno
	    write(logfile2,log)
	else:
	    print "SSS:P:The script dbstart_" + dbname + ".py has run successfully:" + hostname + "_" + appsid + "_" + seqno
            log = "SSS:" + time.strftime("%Y-%m-%d-%H-%M-%S") + ":P: The script dbstart_" + dbname + ".py has run successfully:" + hostname + "_" + appsid + "_" + seqno
            write(logfile2,log)"""


except Exception as e:
	#    exc_type, exc_obj, exc_tb = sys.exc_info()
	if str(e) == "[Errno -2] Name or service not known":
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1301:Hostname unknown:" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	elif str(e) == "list index out of range":
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1302:Argument/s missing for the script"
		#write(logfile,'SSS:F: Argument/s missing for the script [Error Code - 1302]')
	elif str(e) == "Authentication failed.":
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1303:Authentication failed.:" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	elif str(e) == "[Errno 110] Connection timed out":
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1304:Host Unreachable:" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	elif "getaddrinfo failed" in str(e):
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	elif "[Errno None] Unable to connect to port 22 on" in str(e):
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	elif "invalid decimal" in str(e):
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid
		write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + appsid + '_' + seqno + ':' + string + ':' + hostname + ':' + appsid)
	else:
		print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid #+ " " + str(exc_tb.tb_lineno)
		write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid)

