import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *


try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	dbsid = argv[5]
	string = argv[6]
	dbtype = argv[7]
	dbuser = argv[8]
	dbpasswd = argv[9]
	location = argv[10]

	command = "python " + location.rstrip("/") + "/ping " + hostname + " " + string + " " + location
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
	if dbtype == "ORA":
		command = "python " + location.rstrip("/") + "/sudo_access " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + string + " " + location
        	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
        	print out

	command = "python " + location.rstrip("/") + "/user_access_lin " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + string + " " + location
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out

	command = "python " + location.rstrip("/") + "/db_login_wrp " + hostname + " " + username + " " + password + " " + dbtype + " " + dbsid + " " + dbuser + " " + dbpasswd + " " + location
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out

except Exception as e:
    print "LIN_CHK_WRP:F:" + str(e)
