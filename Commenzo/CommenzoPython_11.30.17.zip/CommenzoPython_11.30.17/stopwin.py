#!/usr/bin/python
from sys import *
import subprocess
import log4erp
from log4erp import *
import authmodule
from authmodule import *
import pingmodule
from pingmodule import *
import time


def sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1,logfile2,string):
    try:
        ping(hostname,appsid,seq_no,logfile1,string)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1,string)
        
#################################################### FOLDER EXISTENCE CHECK ON REMOTE SERVER #####################################


        command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + kernel_path + '"'
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)

        if "True" in str(out):

        #################   CHECKING PROFILE PATH EXISTENCE ON REMOTE SERVER ###################################

            command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + profile_path + '"'
            #print command
            write(logfile1,command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            #print out
            write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)

            if "True" in str(out):
                profile_path = profile_path
                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' " dir ' + profile_path + ' " '
                #print command
                write(logfile1,command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                #print out
                write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
                a = out.split("\n")
                b = hostname + "."
                jj = "\\" + hostname
                #print jj
                arr = ""
                a = a[5:]
                for dirs in a:
                    if hostname in dirs:
                        #print dirs
                        if b in dirs or "sapmnt" in dirs: #or "ASCS" in dirs:
                            c = ""
                        else:
                            c = dirs.split()
                            c = c[-1]
                            arr = arr +" " + c
                arr = arr.split(" ")
                arr = filter(None,arr)
                #print arr
                #print "----------------"

                inst = " "
                for p in arr:
                   # print p
                    instance = p.split("_")
                    if string == "AI" and "D" in instance[1] or "ASCS" in instance[1] and len(instance[1]) == 3:
                            ins = instance[1][-2:]
                            inst = ins + " " + inst
                    elif string == "CI" and "DVEBMGS" in instance[1] or "ASCS" in instance[1]:
                            ins = instance[1][-2:]
                            inst = ins + " " + inst

                
                #print inst

                inst = inst.split(" ")
                #print "nn"
                #print inst
                inst = filter(None,inst)
    
                #print inst
                #exit()

##################################################### SAP STATUS CHECK = RUNNING/STOPPED/INTERMEDIATE ###########################
                for ins in inst:           
                    if sys_type.lower() == 'abap':
                        command = 'c:\\python27\\python.exe '+ scriptloc +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function GetProcessList' + '\"'
                        #print command
                        write(logfile1,command)
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
                        #print out
                    
                    elif sys_type.lower() == 'java':
                        command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function J2EEGetProcessList' + '\"'
                        write(logfile1,command)
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + out)
                        #print out

                

                    if "NIECONN_REFUSED" in out:
                        print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " +  str(ins) + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
                        write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The instance number " +  str(ins) + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                        exit()

                    out = out.split("\n")

                    for i in out:
                        i = (str(i)).split(',')
                        if len(i) == 7:
                            status = i[2].strip()
                            #print status
                            if 'GREEN' in status:
                                out = 'SSS:F:The server ' + hostname + ' is up and running :' + appsid
                                break
                            elif 'YELLOW' in status:
                                out = 'SSS:F:The server '+ hostname + ' is running with warning : ' + appsid
                                break

                    if ":F:" in out:

    ##################################################### STOPPING SAP ON REMOTE SERVER ##############################################################

                        if sys_type.lower() == "abap":
                            command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & stopsap.exe name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                            write(logfile1,command)
                        elif sys_type.lower() == "java":
                            command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & stopsap.exe j2ee name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                            write(logfile1,command)

                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") +  " " + out)

                        if "STOPSAP executed succesfully" in out:
                            print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + str(ins) + ' has been stopped successfully on the target server - ( ' + hostname + ') : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                            write (logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + str(ins) + ' has been stopped successfully on the target server - ( ' + hostname + ') :' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)
                        else:
                            print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Failed to stop the SAP Server : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                            write (logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:The sap system has not been stopped:' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)
                            exit()
                    else:
                        print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + str(ins) + ' is already stopped : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid
                        write (logfile2, 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The sap system for instance ' + str(ins) + ' is already stopped : ' + hostname + '_' + appsid + '_' + seq_no + ':' + string + ':' + hostname + ':' + appsid)

                    """ command = 'c:\\python27\\python.exe '+ scriptloc +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SAP\\" "'
                    #print command
                    write(logfile1, command)
                    command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    write(logfile1, out)
                    out = (out.strip()).split()
                    #print out
                    for each in out:
                        if "SAP" in each: 
                            command = 'c:\\python27\\python.exe '+ scriptloc +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "net stop "' + each + '" "'
                            #print command
                            write(logfile1, command)
                            command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                            out, err = command.communicate()
                            #print out
                            write(logfile1, out)
                            
                            if "service is not started" in out:
                                #print "DBSTOP_MSSQL:P: The service " + each + " has already been stopped : " + hostname + "_" + appsid + " " + seq_no
                                write(logfile2, "SSS:P: The service " + each + " has already been stopped :" + appsid )
                                
                            elif 'service was stopped successfully' in out:
                                #print "DBSTOP_MSSQL:P: The service " + each + " has been stopped successfully : " + hostname + "_" + appsid + " " + seq_no
                                write(logfile2,"SSS:P: The service " + each + " has been stopped successfully :" + appsid)
                            else:
                                print "SSS:F: The service " + each + " has not been stopped successfully :" + hostname + "_" + appsid + "_" + seq_no
                                write(logfile2, "SSS:F: The service " + each + " has not been stopped successfully :" + appsid)
                                exit()
                            #print "SSS:P: The SAP services has been stopped successfully :" + hostname + "_" + appsid + "_" + seq_no
                            write(logfile2,"SSS:P: The SAP services has been stopped successfully :" + hostname + "_" + appsid + "_" + seq_no)"""
            else:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" +string + ":" + hostname + ":" + appsid
                write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
                exit()       
        else:
            print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
            write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)
            exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "
        else:
            print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e)+ ": " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid
            write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ":" + hostname + "_" + appsid + "_" + seqno + ":" + string + ":" + hostname + ":" + appsid)


################################################### STOPPING DB ON REMOTE SERVER ##########################################################

#def dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1,logfile2):
def dbstop(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,string):
    try:
        ping(hostname, appsid, seq_no, logfile1, string)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1,string)

        command = "c:\\python27\\python.exe " + scriptloc + "\dbstop " + hostname + " " + username + " " + password + " " + dbsid + " " + db_type + " " + scriptloc + " " + osname + " " + logfile1 + " " + appsid + " " + logfile2 + " " + seq_no + " " +string
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
        out = (out.strip()).split('\n')
        for each in out:
            #print each
            each = each.strip()
            status = (each.split('\n')[len(each.split('\n')) - 2]).split(':')[2]
            # print status
            if status == 'F':
                exit()
        #status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[2]
        #if status == 'F':
            #exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "
        else:
            print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":"+ appsid
            write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ":" + hostname + "_" + appsid + "_" + seq_no + ":" + string + ":" + hostname + ":" + appsid)


try:
            hostname = argv[1]
            username = argv[2]
            password = argv[3]
            appsid = argv[4].upper()
            kernel_path = argv[5]
            scriptloc = argv[6]
            sys_type = argv[7]  # ABAP/JAVA
            profile_path = argv[8]
            db_type = argv[9]
            ai_ci_db = argv[10]
            seq_no = argv[11]
            logfile1 = argv[12]
            logfile2 = argv[13]
            dbsid = argv[14]
            osname = argv[15]

            if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
                sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1, logfile2, ai_ci_db)
            elif ai_ci_db.upper() == "DB":
                #if db_type == "MSS":
                    #dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1, logfile2)
		        dbstop(hostname,username,password,dbsid,db_type,scriptloc,osname,logfile1,logfile2,appsid,seq_no,ai_ci_db)


except Exception as e:
    if str(e) == "list index out of range":
        print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script "
    else:
        print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no +":"+ ai_ci_db + ":" + hostname + ":" + appsid
        write(logfile2, "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no + ":"+ ai_ci_db + ":" + hostname + ":" + appsid)


