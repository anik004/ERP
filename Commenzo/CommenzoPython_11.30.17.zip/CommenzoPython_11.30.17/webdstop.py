import paramiko
from paramiko import *
from sys import *
from log4erp import *
import re
import time

try:
#    if argv[1] == "--u":
#        print "Usage: python sapstopapp.py <Target application Host> <Target application Login User Name> <Target application User Password> <Target Application SID> <Instance ID> <Instance Host> <reference ID>"
#    else:
#   if len(argv) < 5:
#        print "WEBDSTOP:F:  Argument/s missing for the script [Error Code - 1202]"
#   else:

        hostname = argv[1]
        username = argv[2]
        password = argv[3]
	sid = argv[4].lower()
	instance = argv[5]
        logfile = argv[7] + ".log"
        host = argv[6]
	seqno = argv[8]
	string = argv[9]

	user = sid + "adm"
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()
	
#command = 'sudo su - ' + user

	command = 'echo \"su - ' + user + '\"|sudo bash'
#       print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.readlines()[0]
#       print str(status)
        a= "su: user " + user + "does not exist"
#       print a
        if str(status).strip() == str(a):
        	print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The user " + user + "does not exist:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                log="SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The user " + user + " does not exist:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write (logfile, log)
           	exit()
#	command = 'sudo su - ' + user + ' -c "stopsap"'
	command = "echo \"su - " + user + " -c \"\\\"\"stopsap \"\\\"|sudo bash"
        #print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
        if status == 0:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The web dispatcher has been stopped on the target server (HOSTNAME - " + host + "):" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                log = "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P:The web dispatcher has been stopped on the target server (HOSTNAME - " + host + "):" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write (logfile, log)

		"""
		command = 'sudo su - ' + user + ' -c "stopsap sapstartsrv "'
	        #print command
        	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        status = stdout.channel.recv_exit_status()
        	if status == 0:
                	print "WEBDSTOP:P: The sapstartsrv service has been stopped on the target server (HOSTNAME - " + host + ")"
	                log = "WEBDSTOP:P:The sapstartsrv service has been stopped on the target server (HOSTNAME - " + host + ")"
        	        write (logfile, log)
		"""
			
#		command = 'sudo su - ' + user + ' -c "cleanipc ' + instance + ' remove"'
		command = "echo \"su - " + user + " -c \'cleanipc " + instance+ ' remove;cleanipc ' + instance + " remove\'\" | sudo bash"
		#print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		status = stdout.channel.recv_exit_status()
		#print status
		#ommand = 'sudo su - ' + user + ' -c "cleanipc ' + instance + ' remove"'
		command = "echo \"su - " + user + " -c \'cleanipc " + instance+ ' remove;cleanipc ' + instance + " remove\'\" | sudo bash"
                #print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()
                #print status
		if status == 0:
		    	print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P: The CLEANIPC has been successfully completed on the target server (HOSTNAME - ' + host + '):' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid
		        log = 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':P:The CLEANIPC has been successfully completed on the target server (HOSTNAME - ' + host + '):' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid
		        write (logfile, log)
		else:
		        print 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: The CLEANIPC has not been successfully done on the target server (HOSTNAME - ' + host + '):' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid
		        log = 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:The CLEANIPC has not been successfully done on the target server (HOSTNAME - ' + host + '):' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid
		        write (logfile, log)

		"""
	        else:
        	        print "WEBDSTOP:F: The sapstartsrv server has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
                	log = "WEBDSTOP:F:The sapstartsrv server has not been successfully stopped on the target server (HOSTNAME - " + host + ")"
	                write (logfile, log)
		"""
        	       
        else:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The web dispatcher has not been successfully stopped on the target server (HOSTNAME - " + host + "):" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                log = "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:The web dispatcher has not been successfully stopped on the target server (HOSTNAME - " + host + "):" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write (logfile, log)
            
        channel.close()
        client.close()
except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1201:Hostname unknown:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Hostname unknown [Error Code - 1201]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     elif str(e) == "list index out of range":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1202:Argument/s missing for the script"
#                write(logfile,'WEBDSTOP:F:Argument/s missing for the script [Error Code - 1202]')
     elif str(e) == "Authentication failed.":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1203:Authentication failed.:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1203]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1204:Host Unreachable:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1204]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     elif "getaddrinfo failed" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1205: Please check the hostname that you have provide:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Please check the hostname that you have provide [Error Code - 1205]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1206:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable or Unable to connect to port 22 [Error Code - 1206]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     elif "invalid decimal" in str(e):
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:GERR_1207:Unknown Error:" + str(e) + ":" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
                write(logfile,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Unknown Error:' + str(e) + '[Error Code - 1207]:' + hostname + '_' + sid + '_' + seqno + ':' + string + ':' + hostname + ':' + sid)
     else:
                print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F:" + str(e) + ":" + hostname + "_" + sid + "_" + seqno + ":" + string + ":" + hostname + ":" + sid
               
