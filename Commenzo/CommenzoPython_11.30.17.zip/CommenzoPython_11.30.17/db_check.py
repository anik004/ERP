import os
from os import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *


try:
	hostname = argv[1]
        username = argv[2]
        password = argv[3]
        db_sid = argv[4]	
	db_type = argv[5]

	user = "ora" + argv[4].lower()

	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

#	command = 'sudo su - ' + user + ' -c \'echo "select * from T000;" | sqlplus / as sysdba\''
	command = 'echo "su - ' + user + ' -c "\'"echo \'\'\\\"select * from T000;\\\" | sqlplus / as sysdba"\' | sudo bash'
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	out = stdout.readlines()

	for each in out:
		if "ORACLE not available" in each:
			status = "fail"
			break
	if status == "fail":
		print "SSS:F:The database is not running"
	else:
		print "SSS:P:The database is up"

	channel.close()
        client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "DBSTART_ORACLE:F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno)
     elif str(e) == "list index out of range":
                print "DBSTART_ORACLE:F:GERR_1302:Argument/s missing for the script:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile,'DBSTART_ORACLE:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "DBSTART_ORACLE:F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno)
     elif str(e) == "[Errno 110] Connection timed out":
                print "DBSTART_ORACLE:F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "getaddrinfo failed" in str(e):
                print "DBSTART_ORACLE:F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "DBSTART_ORACLE:F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "invalid decimal" in str(e):
                print "DBSTART_ORACLE:F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + ' DBSTART_ORACLE:F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno)
     else:
                print "DBSTART_ORACLE:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,time.strftime("%c") + " DBSTART_ORACLE:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno)


