#!/usr/bin/python
from sys import *
import subprocess
import log4erp
from log4erp import *
import os

try:
    file_path = argv[1]
    old_file = argv[2]
    new_file = argv[3]
    error_code = argv[4]
    stepname = argv[5]
    
    fil = open(file_path)
    content = fil.readlines()

    arg_string = ""
    for each in content:
        arg_string = arg_string + "|" + each.rstrip()

    arg_string = arg_string.replace("|", " ")
    arg_string = arg_string.lstrip()
    argv = arg_string.split(" ")
    argv_len = len(argv) - 2

    for index in range(0,argv_len,17):
        hostname = argv[index]
        username = argv[index+1]
        password = argv[index+2]
        appsid = argv[index+3].upper()
        dbsid = argv[index+4].upper()
        kernel_path = argv[index+5]
        scriptloc = argv[index+6].rstrip('\\')
        t_osname = argv[index+7].lower()
	ker_refid = argv[index+9]
	logfile1 = scriptloc + "\\" + ker_refid + "_log"
        logfile2 = scriptloc + "\\" + "client_read_log"

	command = "c:\\python27\\python.exe " + scriptloc + "\wrp_checkfolder " + old_file + " " + scriptloc
	write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	if ":F:" in str(out):
		print out.strip() + ":" + step_name
                exit()
        else:
        	print out.strip() + ":" + step_name
		
		command = "c:\\python27\\python.exe " + scriptloc + "\wrp_rename " + old_file + " " + new_file + " " + scriptloc
		write(logfile1, command)
	        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	out, err = command.communicate()
	        if ":F:" in str(out):
        	        print out.strip() + ":" + step_name
                	exit()
	        else:
        	        print out.strip() + ":" + step_name

			command = "c:\\python27\\python.exe " + scriptloc + "\wrp_ker_chk " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + t_osname
			write(logfile1, command)
	                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	        out, err = command.communicate()
                	if ":F:" in str(out):
                        	print out.strip() + ":" + step_name
	                        exit()
        	        else:
                	        print out.strip() + ":" + step_name

				command = "c:\\python27\\python.exe " + scriptloc + "\wrp_sapstopindep " + file_path + " " + error_code + " " + stepname
				write(logfile1, command)
	                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	                out, err = command.communicate()
                	        if ":F:" in str(out):
                        	        print out.strip() + ":" + step_name
                                	exit()
	                        else:
        	                        print out.strip() + ":" + step_name

					command = "c:\\python27\\python.exe " + scriptloc + "\wrp_sapstopdep " + file_path + " " + error_code + " " + stepname
	                                write(logfile1, command)
        	                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	                out, err = command.communicate()
                        	        if ":F:" in str(out):
                                	        print out.strip() + ":" + step_name
                                        	exit()
	                                else:
        	                                print out.strip() + ":" + step_name

						command = "c:\\python27\\python.exe " + scriptloc + "\wrp_ker_up " + file_path + " " + error_code + " " + stepname
	                                        write(logfile1, command)
        	                                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	                        out, err = command.communicate()
                        	                if ":F:" in str(out):
                                	                print out.strip() + ":" + step_name
                                        	        exit()
	                                        else:
        	                                        print out.strip() + ":" + step_name

							command = "c:\\python27\\python.exe " + scriptloc + "\wrp_sapstartdep " + file_path + " " + error_code + " " + stepname
	                	                        write(logfile1, command)
        	                	                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	                	        out, err = command.communicate()
		                                        if ":F:" in str(out):
                		                                print out.strip() + ":" + step_name
                                		                exit()
		                                        else:
                		                                print out.strip() + ":" + step_name

								command = "c:\\python27\\python.exe " + scriptloc + "\wrp_sapstartindep " + file_path + " " + error_code + " " + stepname
			                                        write(logfile1, command)
                        			                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			                                        out, err = command.communicate()
                        			                if ":F:" in str(out):
                                                			print out.strip() + ":" + step_name
			                                                exit()
                        			                else:
                                                			print out.strip() + ":" + step_name

									command = "c:\\python27\\python.exe " + scriptloc + "\wrp_start_ai_dep " + file_path + " " + error_code + " " + stepname
				                                        write(logfile1, command)
                                				        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				                                        out, err = command.communicate()
                                				        if ":F:" in str(out):
				                                                print out.strip() + ":" + step_name
                                				                exit()
				                                        else:
                                				                print out.strip() + ":" + step_name

										command = "c:\\python27\\python.exe " + scriptloc + "\wrp_start_ai_indep " + file_path + " " + error_code + " " + stepname
					                                        write(logfile1, command)
                                        					command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
					                                        out, err = command.communicate()
                                        					if ":F:" in str(out):
					                                                print out.strip() + ":" + step_name
                                        					        exit()
					                                        else:
                                        					        print out.strip() + ":" + step_name

    fil.close()

except Exception as e:
    if str(e) == "list index out of range":
        print "WRP_FINAL:F:GERR_1202:Argument/s missing for the script"
    else:
        print "WRP_FINAL:F: " + str(e)

