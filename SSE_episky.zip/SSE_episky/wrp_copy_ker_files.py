from __future__ import division
from sys import *
from os import *
import subprocess


def ker(t_host, t_user, t_password, t_app_sid, t_kernelpath, t_scriptloc, re_execute,t_osname):
    try:
        sol_osname = name
        if sol_osname.lower() == "nt":
            if t_osname.lower() == "windows":
                path = t_scriptloc.rstrip('\\')
                command = "c:\\python27\\python.exe " + path + "\win55 " + t_host + " " + t_user + " " + t_password + " " + t_app_sid + " " + t_kernelpath + " " + t_scriptloc + " " + re_execute
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

        elif sol_osname.lower() == "posix":
            if t_osname == "windows":
                path = t_scriptloc.rstrip('/')
                command = "python " + path + "/lwin55 " + t_host + " " + t_user + " " + t_password + " " + t_app_sid + " " + t_kernelpath + " " + t_scriptloc + " " + re_execute
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out
        else:
            print " F: script not found"
    except Exception as e:
        if str(e).strip() == "list index out of range":
            print "WRPkernel_upgrade:F:GERR_0202:Argument/s missing for the script"
        else:
            print "WRPkernel_upgrade:F: " + str(e)


try:

    t_host = argv[1]
    t_user = argv[2]
    t_password = argv[3]
    t_app_sid = argv[4]
    t_kernelpath = argv[5]
    t_scriptloc = argv[6]
    re_execute = argv[7]
    t_osname = argv[8]

    ker_upgrade = ker(t_host, t_user, t_password, t_app_sid, t_kernelpath, t_scriptloc, re_execute, t_osname)

    print ker_upgrade
except Exception as e:
    print "WRPkernel_upgrade:F: " + str(e)
