command = "echo \"su - soladm -c \"\\\"\" which disp+work\"\\\"\" | sed \'s/\/disp+work//\' | grep -v \"MAIL\"\"|sudo bash "
print command
