#!/usr/bin/python
from sys import *
import subprocess
import log4erp
from log4erp import *
import os

def sapstart_dep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2, step_name):
    try:

	sol_osname = os.name
	if ai_ci_db.upper() == "DB":
            path_exist = os.path.isdir(scriptloc)
            if "False" in str(path_exist):
                print 'WRPSTOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no + ":" + step_name
                write(logfile1, 'WRPSTOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no)
                exit()


	    if sol_osname.lower() == "nt":
                if t_osname == "windows":
                    path = scriptloc
                    #print path
                    command = "c:\\python27\\python.exe " + path + "\win60 " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + tenant_type + " " + seq_no + " " + logfile1 + " " + logfile2
                    #print command
                    write(logfile1, command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    out = out.split('\n')
                    output = ''
                    for i in out:
                        if i.strip():
                            output = output + i.strip() + '\n'
                    if ":F:" in output:
                        print output.strip() + ":" + step_name
                        exit()
                    else:
                        print output.strip() + ":" + step_name

                elif t_osname.lower() == "suse_linux":
                    path = scriptloc
                    # print path
                    command = "c:\\python27\\python.exe " + path + "\win60 " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + tenant_type + " " + seq_no + " " + logfile1 + " " + logfile2
                    ##print command
                    write(logfile1, command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    out = out.split('\n')
                    output = ''
                    for i in out:
                        if i.strip():
                            output = output + i.strip() + '\n'
                    if ":F:" in output:
                        print output.strip() + ":" + step_name
                        exit()
                    else:
                        print output.strip() + ":" + step_name


	    elif sol_osname.lower() == "posix":
                if t_osname.lower() == "windows":
                    path = scriptloc.rstrip('/')
                    command = "c:\\python27\\python.exe " + path + "\lwin60 " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + tenant_type + " " + seq_no + " " + logfile1 + " " + logfile2
                    write(logfile1,command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    out = out.split('\n')
                    output = ''
                    for i in out:
                        if i.strip():
                            output = output + i.strip() + '\n'
                    if ":F:" in output:
                        print output.strip() + ":" + step_name
                        exit()
                    else:
                        print output.strip() + ":" + step_name

		elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux":
			path = scriptloc.rstrip('/')
			logfile1 = scriptloc + "/" + ker_refid + "_log.log"
                	logfile2 = scriptloc + "/" + "EpiskyClient_log.log"
			command  = "python " + path + "/lin62.py "  + hostname + " " + username + " " + password + " " + appsid + " " + sys_type + " " +kernel_path + " " + logfile1 + " " + logfile2 + " " + ai_ci_db + " " + dbsid + " " + path + " " + seq_no + " " + db_type + " " + profile_path + " " + tenant_type
			print command
			write(logfile1,command)
                    	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    	out, err = command.communicate()
                    	out = out.split('\n')
                    	output = ''
                    	for i in out:
                        	if i.strip():
                            		output = output + i.strip() + '\n'
                    	if ":F:" in output:
                        	print output.strip() + ":" + step_name
                        	exit()
                    	else:
                        	print output.strip()

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPSAPSTARTDEP_WRP:F:GERR_1202:Argument/s missing for the script"
        else:
            print "WRPSAPSTARTDEP_WRP:F: " + str(e) + ":" + hostname + "_" + appsid + "_" + seq_no + ":" + step_name



try:
    file_path = argv[1]
    error_code = argv[2]
    error_code = error_code.split("_")
    seq_no = error_code[2]
    step_name = argv[3]

    if seq_no == "0":
        content = ""
        for cont in reversed(open(file_path).readlines()):
            if "ddep" in cont:
                content = content + "|" + cont.rstrip()


        arg_string = content.replace("|", " ")
        arg_string = arg_string.lstrip()
        argv = arg_string.split(" ")
        argv_len = len(argv) - 2

        for index in range(0,argv_len,18):
                hostname = argv[index]
                username = argv[index+1]
                password = argv[index+2]
                appsid = argv[index+3].upper()
                dbsid = argv[index+4].upper()
                kernel_path = argv[index+5]
                scriptloc = argv[index+6].rstrip('\\')
                t_osname = argv[index+7].lower()
                ker_refid = argv[index+9]
                sys_type = argv[index+10]  # ABAP/JAVA
                profile_path = argv[index+11]
                db_type = argv[index+13]
                ai_ci_db = argv[index+14]
                tenant_type = argv[index+15]
                seq_no = argv[index+16]
                logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
                logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"
                sapstart_dep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1,logfile2, step_name)



    else:
        content = ""
        for cont in reversed(open(file_path).readlines()):
            content = content + "\n" + cont

        for line in content.split():
            if "ddep" in line:
                if line[-1] < seq_no or line[-1] == seq_no:
                    arg_string = line.replace("|"," ")
                    arg_string = arg_string.split()
                    hostname = arg_string[0]
                    username = arg_string[1]
                    password = arg_string[2]
                    appsid = arg_string[3].upper()
                    dbsid = arg_string[4].upper()
                    kernel_path = arg_string[5]
                    scriptloc = arg_string[6].rstrip('\\')
                    t_osname = arg_string[7].lower()
                    ker_refid = arg_string[9]
                    sys_type = arg_string[10]  # ABAP/JAVA
                    profile_path = arg_string[11]
                    db_type = arg_string[13]
                    ai_ci_db = arg_string[14]
                    tenant_type = arg_string[15]
                    seq_no = arg_string[16]
                    logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
                    logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"

                    sapstart_dep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type,profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2, step_name)


except Exception as e:
    if str(e) == "list index out of range":
        print "WRPSAPSTARTDEP_WRP:F:GERR_1202:Argument/s missing for the script"
    else:
        print "WRPSAPSTARTDEP_WRP:F: " + str(e)
