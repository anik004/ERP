command = "c:\\python27\\python.exe " + path + "\win59 " + hostname
print command
command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
out, err = command.communicate()
status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
if status == 'F':
    print out
    exit()

command = "c:\\python27\\python.exe " + path + "\win50 " + hostname + " " + username + " " + password + " " + appsid + " " + location
print command
command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
out, err = command.communicate()
status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
if status == 'F':
    print out
    exit()
