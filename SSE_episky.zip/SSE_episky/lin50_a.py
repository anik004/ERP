import paramiko
from sys import *
from paramiko import *
def func(t_host, t_user, t_pass, t_app_sid, t_db_sid, string, logfile, log, kr, re_execute):
        kernel_path="sudo su - " + user_app  + " -c \"which disp+work | sed 's/\/disp+work//'\" | grep -v \"MAIL\""
        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        kernel_path=stdout.readlines()[0].strip()
	bkp = kernel_path+'_bkp_'+ str(kr)
	if stdout.channel.recv_exit_status() == 0:
		command = "sudo ls " + bkp
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        	status = stdout.channel.recv_exit_status()
		if status == 0:
			print "WRPBACKUP_KERNEL:P:backup already exists : " + t_host + "_" + t_app_sid + "_" + re_execute
		else:
			command = "sudo chmod -R 777 " + kernel_path
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			command="sudo su - " + user_app + " -c \" cp -Rf " + kernel_path + " " + kernel_path + "_bkp_" + kr + " \" "
            		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			status = stdout.channel.recv_exit_status()
            		if status == 0:
				count_ori="sudo su - " + user_app + " -c \'ls " + kernel_path + " | wc -l\' | grep -v \"MAIL\" "
                		stdin, stdout, stderr = client.exec_command(count_ori, timeout=1000, get_pty=True)
                		count_ori=int(''.join(stdout.readlines()).strip())
                		count_bkp="sudo su - " + user_app + " -c \'ls " + bkp + " | wc -l\' | grep -v \"MAIL\" "
            	    		stdin, stdout, stderr = client.exec_command(count_bkp, timeout=1000, get_pty=True)
                		count_bkp=''.join(stdout.readlines()).strip()
				if (count_ori == count_bkp):
                    			print "WRPBACKUP_KERNEL:P: The kernel backup has been taken successfully on the target"
                		else:
                    			print "WRPBACKUP_KERNEL:F: The kernel backup is failed on the target"
            		else:
                		print "WRPBACKUP_KERNEL:F: The kernel backup is failed on the target"
        channel.close()
        client.close()
func(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9])
