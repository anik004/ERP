from sys import *
from os import *
import os
import log4erp
from log4erp import *

try:
    if argv[1] == "--u":
        print "python ping.py <Target Hostname> <sid>"
    else:
        t_host = argv[1]
        sid = argv[2]
        osname = name

        if osname == "nt":
            command = "ping -n 1 " + str(t_host) #+ " > /dev/null 2>&1"
            response = os.system(command)

        elif osname == "posix":
            command = "ping -c1 -i3 " + str(t_host) + " > /dev/null 2>&1"
            response = os.system(command)

        if response == 0:
            print "WRPPING:P: The connectivity check for Target Server is Successful : " + t_host + "_" + sid

        else:
            print "WRPPING:F: Please check the IP address. Unable to reach the Host : " + t_host + "_" + sid


            
except Exception as e:
    if str(e).strip() == "list index out of range":
        print "WRPPING:F:GERR_0202:Argument/s missing for the script"
    else:
        print "WRPPING:F: " + str(e)

