#!/usr/bin/c:\\python27\\python.exe
import os
import getpass
import subprocess
import re
from sys import *
import log4erp
from log4erp import *

try:
	hostname = argv[1]
	username = argv[2] 
	password = argv[3]
	appsid = argv[4]
	drive = argv[5]		#KERNEL PATH
	location = argv[6].rstrip()		#SCRIPT LOCATION]
	k_id = argv[7]
	ker_refid = argv[8]
	re_execute = argv[9]
	logfile1 = argv[10]
	logfile2 = argv[11]

	folder_path = drive[:1] + ':\\erp_trans'

################################### folder existence check remote #####################

	command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + drive + '"'
	write(logfile1, command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1,out)
	#print out
	if "True" in out:
		folder = (str(drive).strip()).split('\\')[-1]
		a = (str(drive).strip()).split('\\')[:-1]
		path = ""
		for i in a:
			path += i + "\\"
		kernel_backup_path = path +	folder + '_BKP_' + ker_refid
		write(logfile1, kernel_backup_path)
################################# COPY NEW KERNEL FILES TO ACTUAL KERNAL PATH ######################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SAP' + appsid.upper() + '\\" "'
        write(logfile1, command)
        command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)
        out = (out.strip()).split()
        print out
        for each in out:
                if "SAP" in each: 
                        command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "net stop "' + each + '" "'
                        write(logfile1, command)
                        command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        write(logfile1, out)
                            
                        if "service is not started" in out:
                            #print "DBSTOP_MSSQL:P: The service " + each + " has already been stopped : " + hostname + "_" + appsid + " " + seq_no
                            write(logfile2, "SAPSTOP:P: The service " + each + " has already been stopped :" + appsid )
                                
                        elif 'service was stopped successfully' in out:
                            #print "DBSTOP_MSSQL:P: The service " + each + " has been stopped successfully : " + hostname + "_" + appsid + " " + seq_no
                            write(logfile2,"SAPSTOP:P: The service " + each + " has been stopped successfully :" + appsid)
                        else:
                            print "WRPSAPSTOP:F: The service " + each + " has not been stopped successfully :" + hostname + "_" + appsid + "_" + re_execute
                            write(logfile2, "SAPSTOP:F: The service " + each + " has not been stopped successfully :" + appsid)
                            exit()
                        print "WRPSAPSTOP:P: The SAP services has been stopped successfully :" + hostname + "_" + appsid + "_" + re_execute
                        write(logfile2,"WRPSAPSTOP:P: The SAP services has been stopped successfully :" + hostname + "_" + appsid + "_" + re_execute)

	command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"xcopy ' + folder_path + ' ' + drive + ' /y\"'
	print command
	write(logfile1, command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1,out)
	if "copied" in out:
		command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "dir ' + drive + ' "'
		#print command
		write(logfile1, command)
		command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1,out)
		dirlist = out.strip().split('\n')
		for dirs in dirlist:
			#print dirs
			if (k_id + "_DBD.SAR") in dirs or (k_id + "_DBI.SAR") in dirs:
				#print dirs
				dirs = dirs.split()[-1]
				#print dirs
				command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' ' + '"' + drive[:1] + ': & cd ' + drive + ' & ' + kernel_backup_path + '\sapcar.exe -xvf ' + dirs +'" ' #':& cd ' + drive[:1] + ':\\erp_trans\sapcar.exe -xvf ' + dirs[-1] + '\"'
				#print command
				write(logfile1, command)
				command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
				out, err = command.communicate()
				write(logfile1,out)
				if command.returncode == 0:
					print "WRPextractfiles:P:" + dirs + "file extracted successfully:"+ hostname + "_" + appsid + "_" + re_execute
					write(logfile2,"extractfiles:P:" + dirs + "file extracted successfully:"+ hostname + "_" + appsid + "_" + re_execute)
				else:
					print "WRPextractfiles:F:file extraction failed:"+ hostname + "_" + appsid + "_" + re_execute
					write(logfile2, "extractfiles:F:file extraction failed:"+ hostname + "_" + appsid + "_" + re_execute)
					exit()
except Exception as e:
	if str(e).strip() == "list index out of range":
		print "WRPextractfiles:F:GERR_0202:Argument/s missing for the script:"++ hostname + "_" + appsid + "_" + re_execute
	else:
		print "WRPextractfiles:F: " + str(e)+ ":" + hostname + "_" + appsid + "_" + re_execute
		write(logfile2, "extractfiles:F: " + str(e)+":" + hostname + "_" + appsid + "_" + re_execute)
	     	    
