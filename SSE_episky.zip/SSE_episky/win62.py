from sys import *
import glob
from os import *
from subprocess import *
import os
import subprocess
import ntpath

try:
 
    if argv[1] == "--u":
        print "python check_folder.py <Folder name>"
    else:
		fold_name = argv[1]
		command = os.path.exists(fold_name.strip())
		out = command
	#	print out
	
		if str(out) == "True":
			for files in os.listdir(fold_name):
    				if files.endswith(".SAR"):
        				print files.strip()
				#path = fold_name + "/*.SAR"
				#print path
				#out = glob.glob(path)
			#print out
				#if out:
				#	for files in out:
				#		print ntpath.basename(files).strip()
	
		else:
			print "WRPCHECK_FOLDER:F: Folder " + fold_name + " does not exist"

except Exception as e:
	if str(e).strip() == "list index out of range":
		print "WRPCHECK_FOLDER:F:GERR_0202:Argument/s missing for the script"
	elif "Permission denied" in str(e):
		print "WRPCHECK_FOLDER:F:GERR_0206:Permission denied for the user"
	else:
		print "WRPCHECK_FOLDER:F " + str(e)
