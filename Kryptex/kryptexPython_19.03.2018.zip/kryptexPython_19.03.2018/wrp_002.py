################################################################
#  Script Name: wrp_002
#  Author: Jesna Jose
#  Description: Wrapper to call the Geminyo check scripts
################################################################

from os import *
from sys import *
from subprocess import *
import subprocess


try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	app_sid = argv[4]
	db_sid = argv[5]
	app_db = argv[6]
	os_name = argv[7]
	db_name = argv[8]
	#db_username = argv[9]
	#db_password = argv[10]
	#schema = argv[11]
	#system = argv[12]
	#s_hostname = argv[13]
	#s_username = argv[14]
	#s_password = argv[15]
	#s_db_sid = argv[16]
	string = 'target'


	#################### WINDOWS #################
	if os_name.lower() == 'win':
	##############################################

		command = 'python win00.py ' + hostname
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		command = 'python win01.py ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + argv[11] + ' ' + argv[12] + ' ' + argv[13] + ' ' + argv[14]
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		command = 'python lin03.py ' + hostname + ' ' + string
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		command = 'python lin03.py ' + argv[11] + ' ' + string
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		################ FOR APP ##################
                if app_db.lower() == 'ai' or app_db.lower() == 'ci':
                ###########################################

			command = 'python win03.py ' + hostname + ' ' + username + ' ' + password
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

		################ FOR ORA ##################
                if app_db.lower() == 'db' and db_name.lower() == 'ora':
                ###########################################

			command = 'python win03.py ' + hostname + ' ' + username + ' ' + password
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

			command = 'python win04.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR DB2 ##################
                elif app_db.lower() == 'db' and db_name.lower() == 'db6':
                ###########################################


			command = 'python win05.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR MAXDB ################
                elif app_db.lower() == 'db' and db_name.lower() == 'ada':
                ###########################################


			command = 'python win06.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR SYBASE ###############
                elif app_db.lower() == 'db' and db_name.lower() == 'syb':
                ###########################################

			command = 'python win07.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR MSSQL ################
                elif app_db.lower() == 'db' and db_name.lower() == 'mss':
                ###########################################


			command = 'python win08.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


	################## LINUX ####################
	else:
	#############################################

		command = 'python lin01.py ' + hostname
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		################### AIX ##############
		if os_name == 'aix':
		######################################
			
			command = 'python ax02.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[13] + ' ' + argv[14] + ' ' + argv[15] + ' ' + argv[16]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

		################# LINUX #############
		else:
		#####################################

			command = 'python lin02.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[13] + ' ' + argv[14] + ' ' + argv[15] + ' ' + argv[16]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

		command = 'python lin03.py ' + hostname + ' ' + 'target'
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		command = 'python lin03.py ' + argv[13] + ' ' + 'source'
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()
		
		################# FOR APP #################
		if app_db.lower() == 'ai' or app_db.lower() == 'ci':
		###########################################

			command = 'python lin04.py ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + app_db
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python lin09.py ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + app_db
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

		################ FOR ORA ##################
		if app_db.lower() == 'db' and db_name.lower() == 'ora':
		###########################################

			command = 'python lin04.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python lin10.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()
			
			command = 'python lin05.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python lin06.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' +  argv[11]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python lin07.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[12]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python lin09.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()


                ################ FOR MAXDB ################
                elif app_db.lower() == 'db' and db_name.lower() == 'ada':
                ###########################################


                        command = 'python lin11.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


                ################ FOR DB2 ##################
                elif app_db.lower() == 'db' and db_name.lower() == 'db6':
                ###########################################


                        command = 'python lin12.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


                ################ FOR SYBASE ###############
                elif app_db.lower() == 'db' and db_name.lower() == 'syb':
                ###########################################


                        command = 'python lin14.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

		############## SUSE ######################
		elif app_db.lower() == 'db' and os_name.lower() == 'sus' and db_name.lower() == 'hdb':
		##########################################

			
                        command = 'python lin15.py ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[9] + ' ' + argv[10]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

		############## SUSE ######################
		else:
		##########################################
			
			print "PRE:F:The OS and Database combination is wrongly entered"

		command = 'python lin08.py ' + hostname + ' ' + username + ' ' + password
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()


################# ERROR ##################
except Exception as e:
##########################################
    if str(e) == "[Errno -2] Name or service not known":
        print "PRE:F:GERR_0201:Hostname unknown"
    elif str(e).strip() == "list index out of range":
        print "PRE:F:GERR_0202:Argument/s missing for the script"
    elif str(e) == "Authentication failed.":
        print "PRE:F:GERR_0203:Authentication failed."
    elif str(e) == "[Errno 110] Connection timed out":
        print "PRE:F:GERR_0204:Host Unreachable"
    elif "getaddrinfo failed" in str(e):
        print "PRE:F:GERR_0205: Please check the hostname that you have provide"
    elif "[Errno None] Unable to connect to port 22" in str(e):
        print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
    else:
        print "PRE:F: " + str(e)
