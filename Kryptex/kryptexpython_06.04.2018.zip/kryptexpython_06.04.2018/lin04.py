#!/usr/bin/python
################################################################
#  Script Name: lin04
#  Author: Surabhi Priya
#  Description: Checks if the user exists.
################################################################


# target IP - $1
# database sid - $2
# application sid - $3
# schema passwd - $4
import paramiko
from sys import *
from paramiko import *
import subprocess
from subprocess import *

try:
#    if argv[1] == "--u":
 #       print "usage: python os_user_existence.py <Host> <sudo user> <sudo password> <sid> <DB/AI/CI> <Source/Target>"
  #  else:
	hostname=argv[1]
        sudo_user=argv[2]
	password=argv[3]
	database_sid=argv[4]
	string = argv[5]
	db_type = argv[6]
	if string.lower() == "db":
		if db_type.lower() == "db6":
			user = "db2" + database_sid.lower()
		elif db_type.lower() == "hdb":
			user = database_sid.lower() + "adm"
		elif db_type.lower() == "ora":
			user = "ora" + database_sid.lower()
		else:
	                user = database_sid.lower() + "adm"
		
	elif string.lower() == "app":
		user = database_sid.lower() + "adm"
	
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = sudo_user, password = password)
        channel = client.invoke_shell()
		
#	command="sudo su - root '-c grep -iw ^" + user+ " /etc/passwd'"
	command = "echo 'grep -iw ^" + user + " /etc/passwd'|sudo bash"
	print command 
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	status = stdout.channel.recv_exit_status()
	print status
	
	if status == 0:
	
		print "PRE:P:User existence check for " + sudo_user + " is successful on  server " + hostname
	else:
		print "PRE:F:User existence check for " + sudo_user + " is failed on  server " + hostname
	
        channel.close()
        client.close()
except Exception as e:
	if str(e) == "[Errno -2] Name or service not known":
        	print "PRE:F:GERR_0201:Hostname unknown"
	elif str(e).strip() == "list index out of range":
                print "PRE:F:GERR_0202:Argument/s missing for the script"
	elif str(e) == "Authentication failed.":
		print "PRE:F:GERR_0203:Authentication failed for the " + string + " system " + hostname + " for user " + sudo_user
	elif str(e) == "[Errno 110] Connection timed out":
		print "PRE:F:GERR_0204:Host Unreachable"
	elif "getaddrinfo failed" in str(e):
        	print "PRE:F:GERR_0205: Please check the hostname that you have provide"
	elif "[Errno None] Unable to connect to port 22 on" in str(e):
	        print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
    	else:
        	print "PRE:F: " + str(e)
