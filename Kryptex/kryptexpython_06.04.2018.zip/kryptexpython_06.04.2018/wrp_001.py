################################################################
#  Script Name: wrp_001
#  Author: Surabhi Priya
#  Description: Wrapper to call the kryptex scripts.
################################################################

from os import *
import os
from sys import *
from subprocess import *
import subprocess


try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	app_sid = argv[4]
	db_sid = argv[5]
	app_db = argv[6]
	os_name = argv[7]
	db_name = argv[8]
	path = argv[9].strip('\\') + '\\'
	#db_username = argv[10]
	#db_password = argv[11]
	string = 'target'
	#path = os.getcwd() + '/'

	#################### WINDOWS #################
	if os_name.lower() == 'windows':
	##############################################

		command = 'c:\python27\python.exe ' + path + 'lin03 ' + hostname + ' ' + string
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()
		
		#################### FOR APP ##################
		if app_db.lower() == 'ai' or app_db.lower() == 'ci':
		###############################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

		################ FOR ORA ##################
                elif app_db.lower() == 'db' and db_name.lower() == 'ora':
                ###########################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

			command = 'c:\python27\python.exe ' + path + 'win04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + path  + ' ' + argv[10] + ' ' + argv[11]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR DB2 ##################
                elif app_db.lower() == 'db' and db_name.lower() == 'db6':
                ###########################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

			command = 'c:\python27\python.exe ' + path + 'win05 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + path + ' ' + argv[10] + ' ' + argv[11]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR MAXDB ################
                elif app_db.lower() == 'db' and db_name.lower() == 'ada':
                ###########################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

			command = 'c:\python27\python.exe ' + path + 'win06 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + path + ' ' + argv[10] + ' ' + argv[11]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR SYBASE ###############
                elif app_db.lower() == 'db' and db_name.lower() == 'syb':
                ###########################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

			command = 'c:\python27\python.exe ' + path + 'win07 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + path + ' ' + argv[10] + ' ' + argv[11]
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR MSSQL ################
                elif app_db.lower() == 'db' and db_name.lower() == 'mss':
                ###########################################

			command = 'c:\python27\python.exe ' + path + 'win03 ' + hostname + ' ' + username + ' ' + password + ' ' + path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

		############## OTHER #####################
		else:
		##########################################

			print 'PRE:F:The combination entered here (' + os_name + ' and ' + db_name + ') is wrong'

	################## LINUX ####################
	else:
	#############################################
		path = argv[9].rstrip('\\').rstrip('/')
		command = 'python ' + path + '/lin03 ' + hostname + ' ' + string
		print command
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		print out.strip()

		################# FOR APP #################
		if app_db.lower() == 'ai' or app_db.lower() == 'ci':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + 'app' + ' ' + db_name
			print command
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()
			print db_name.lower()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + app_db + ' ' + db_name
			print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

		################ FOR HANA #################
		elif os_name.lower() == 'suse_linux' and app_db.lower() == 'db' and db_name.lower() == 'hdb':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
			print command
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			#command = 'c:\python27\python.exe ' + path + 'lin15 ' + hostname + ' ' + username + ' ' + password
			#command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			#out, err = command.communicate()
			#print out.strip()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
                        print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()

		################ FOR ORA ##################
		elif app_db.lower() == 'db' and db_name.lower() == 'ora':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin10 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[10] + ' ' + argv[11]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
                        print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR MAXDB ################
		elif app_db.lower() == 'db' and db_name.lower() == 'ada':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
			print command
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			#command = 'c:\python27\python.exe ' + path + 'lin11 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[10] + ' ' + argv[11]
			#command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			#out, err = command.communicate()
			#print out.strip()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
                        print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR DB2 ##################
		elif app_db.lower() == 'db' and db_name.lower() == 'db6':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin12 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[10] + ' ' + argv[11]
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
                        print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		################ FOR SYBASE ###############
		elif app_db.lower() == 'db' and db_name.lower() == 'syb':
		###########################################

			command = 'python ' + path + '/lin04 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin14 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + argv[10] + ' ' + argv[11] + ' ' + path
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out.strip()

			command = 'python ' + path + '/lin09 ' + hostname + ' ' + username + ' ' + password + ' ' + db_sid + ' ' + app_db + ' ' + db_name
                        print command
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out.strip()


		############## OTHER #####################
		else:
		##########################################

			print 'PRE:F:The combination entered here (' + os_name + ' and ' + db_name + ') is wrong'


################# ERROR ##################
except Exception as e:
##########################################
    if str(e) == "[Errno -2] Name or service not known":
        print "PRE:F:GERR_0201:Hostname unknown"
    elif str(e).strip() == "list index out of range":
        print "PRE:F:GERR_0202:Argument/s missing for the script"
    elif str(e) == "Authentication failed.":
        print "PRE:F:GERR_0203:Authentication failed."
    elif str(e) == "[Errno 110] Connection timed out":
        print "PRE:F:GERR_0204:Host Unreachable"
    elif "getaddrinfo failed" in str(e):
        print "PRE:F:GERR_0205: Please check the hostname that you have provide"
    elif "[Errno None] Unable to connect to port 22" in str(e):
        print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
    else:
        print "PRE:F: " + str(e)
