print 'PRE:W:The database type "MaxDB" is not supported'
