#!/usr/bin/sh
from __future__ import division
import paramiko
import re
import glob
import os
from paramiko import *
from sys import *
import subprocess

def space_check(hostname, username, password, sid, db_name):

    command = 'python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \'hostname\''
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    domain_name = out.strip()

    command='python wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \'sqlcmd -E -S ' + domain_name + '\\' + sid + ' -Q "use ' + db_name + ';SELECT name,(size*8)/1024 SizeMB FROM sys.database_files;"\''
#    print command
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()
    out=out.split('\n')
#    print out

    total = []
    for line in out[6:][:-4]:
	total += [line.split()[0]]
        total += [line.split()[1]]
    return total

try:
    if argv[1] == "--u":
        print "usage: python mountpoint_check.py <Target Host> <Target Sudo Username> <Target Sudo Password> <App/DB Sid> <domain_name> < database name>"
    else:
	db_name = argv[9]

        source = space_check(argv[1], argv[2], argv[3], argv[4], db_name)
        target = space_check(argv[5], argv[6], argv[7], argv[8], db_name)

	for i in range (0, len(source), 2):
		if source[i] in target:
		    if int(source[i+1]) > int(target[i+1]):
			print 'PRE:P:In target the mountpoint ' + source[i] + ' does not have enough space'
			exit()
		    else:
			print 'PRE:P:In target the mountpoint ' + source[i] + ' has enough space'
		else:
		    print 'PRE:P:In target the mountpoint ' + source[i] + ' does not exist'
		    exit()
except Exception as e:
	if "No such file or directory" in str(e):
		print "No such file"
	elif "name 'user' is not defined" in str(e):
		print "CHECK_SPACE:F: Please enter App for Application Server or Db for Database Server"
	elif str(e).strip() == "list index out of range":
                print "CHECK_SPACE:F:GERR_0202:Argument/s missing for the script"
	else:
		print "check_space :" + str(e)
