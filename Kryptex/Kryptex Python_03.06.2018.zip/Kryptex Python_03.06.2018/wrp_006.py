from os import *
from sys import *
from subprocess import *
from log4erp import *

try:
	if argv[1] == '--ani':
		print 'usage: h u p app dr ref os no nm'
	else:
		hostname = argv[1]
		username = argv[2]
		password = argv[3]
		appsid = argv[4]
		client_name = argv[5]
		step_name = argv[6]
		location = argv[7]
		drive = argv[8]
		logfile = argv[9]
		os_name = argv[10]

		if os_name.lower() == 'windows':
			command = 'c:\python27\python ' + drive.strip('\\') + '\win12 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + client_name + ' ' + step_name + ' ' + location + ' ' + drive
		elif os_name.lower() == 'redhat':
			command = 'python ' + drive.strip('\\').strip('\\') + '/lin19 ' + hostname + ' ' + username + ' ' + password + ' ' + client_name + ' ' + step_name + ' ' + appsid + ' ' + logfile + ' ' + drive
			print command
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	        out, err = command.communicate()
		print out
        	status = command.returncode
		if status != 0:
			print 'POST:F:The script execution has failed'

except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
        print "POST:F:GERR_3001:Hostname unknown"
    elif str(e).strip() == "list index out of range":
        print "POST:F:GERR_3002:Argument/s missing"
    elif str(e) == "Authentication failed.":
        print "POST:F:GERR_3003:Authentication failed."
    elif str(e) == "[Errno 110] Connection timed out":
        print "POST:F:GERR_3004:Host Unreachable"
    elif "getaddrinfo failed" in str(e):
        print "POST:F:GERR_3005: Please check the hostname that you have provide"
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "POST:F:GERR_3006:Host Unreachable or Unable to connect to port 22"
    else:
        print "POST:F: " + str(e)
