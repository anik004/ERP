from paramiko import *
import paramiko
from sys import *
import log4erp
from log4erp import *
from time import gmtime, strftime


try:
    if argv[1] == "--u":
        print "usage: python sapdelete.py <Application Hostname> <Sudo User Name> <Sudo user password> <Application SID> <Client Name> <Target/Source>"
    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        application_sid = argv[4]
        user =  "syb" + application_sid.lower()
        clientname = argv[5]
	path = argv[6]
	db_user = argv[7]	
	db_password = argv[8]
	logfile = "geminyo.txt"

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

            #DELETE SAP<SID>.usr02 where mandt='CLIENT.NO' and bname=SAP
#        command = 'sudo su - ' + user + ' -c "echo \'delete ' + application_sid.upper() + '.SAPSR3.usr02 where mandt=' + clientname + ' and bname=\'\\\'SAP\\*\\\'\';\' | sqlplus / as sysdba"'

	file=open(path.rstrip() + "/sapdel.sql","w+")
        file.write('use ' + application_sid.upper() + '\n')
	file.write('delete '+ application_sid.upper()+'.SAPSR3.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')
	file.write('update '+ application_sid.upper()+'.SAPSR3.USR02 set UFLAG = 0 where BNAME = \'SAP*\' and  MANDT=\''+ clientname +'\'\n')
	file.write("go");
        file.close()

        port = 22

        remote= '/tmp/sapdel.sql'
        print remote
        local= path + '/sapdel.sql'
        print local

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)


	command = 'sudo su - ' + user + ' -c \' isql -U' + db_user + " -P" + db_password + " -S"+ application_sid.upper() + " -X -i/tmp/sapdel.sql\'"
        print command
#	write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	print stdout.readlines()
	print stdout.channel.recv_exit_status()
        if stdout.channel.recv_exit_status() == 0:
                print "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )"
#		write(logfile, "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )" + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        else:
                print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"
#		write(logfile, "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )")

	channel.close()
        client.close()

except Exception as e:
    print "POST:F: " + str(e)
