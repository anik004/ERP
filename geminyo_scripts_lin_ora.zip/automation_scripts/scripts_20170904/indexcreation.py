#print 'PRE:W:The database type "Sybase" is not supported'
# -*- coding: utf-8 -*- 
from paramiko import *
import paramiko
from sys import *
import re
import subprocess

#from log4erp import *
try:

	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	database_sid=argv[4].strip()
	db_user = argv[5]
	db_password = argv[6]
	path = argv[7]
	ref_id = argv[8]
	
	user = "syb" + database_sid.lower()
	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
	channel = client.invoke_shell()
	file=open("indextable.sql","w+")
	file.write('use ' + database_sid.upper() + '\n')
	file.write('select ' + database_sid.upper() + '.SAPSR3.DD03L.TABNAME, ' + database_sid.upper() +  '.SAPSR3.DD03L.FIELDNAME from ' + database_sid.upper() +  '.SAPSR3.DD03L inner join ' + database_sid.upper() +  '.SAPSR3.DD02L on ' + database_sid.upper() +  '.SAPSR3.DD02L.TABNAME = ' + database_sid.upper() +  '.SAPSR3.DD03L.TABNAME where ' + database_sid.upper() +  '.SAPSR3.DD03L.DOMNAME = \'LOGSYS\' and ' + database_sid.upper() +  '.SAPSR3.DD02L.TABCLASS = \'TRANSP\'\n')
	file.write("go")
	file.close()

	port = 22

	remote= '/tmp/indextable.sql'
        print remote
        local= path + '/indextable.sql'
        print local

	transport = paramiko.Transport((hostname, port))
	transport.connect(username = username, password = password)
	sftp = paramiko.SFTPClient.from_transport(transport)
	sftp.put(local, remote)

	
	command = "sudo su - " + user + " -c \' isql -U" + db_user + " -P" + db_password + " -S"+ database_sid.upper() +" -X -w999 -i/tmp/indextable.sql \'"""
	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	print "hello"
#	status = stdout.channel.recv_exit_status()
	#print status
	out = stdout.readlines()
	table = '' 
	j = ''
	table_field= ''
	for i in out:
		table_field = table_field + str(i)
		if not 'rows' in i :
			if not "TABNAME" in i:
				if not "--" in i:
					if i.strip() != '':
						i = i.split(' ')
						table = table + str(i[1]) + '\n'
						if not '/' in str(i[1]):
							j = j + str(i[1]) + '\n'

	#print table_field
	#print j
	#print table
	file1 = open(ref_id + "_bdls.txt","w+")
	file1.write(table)
	file1.close()
	file2=open("index.sql","w+")
	
        file2.write('use ' + database_sid.upper() + '\n')
	for each in table_field.split('\n'):
	    if each.strip() != '' :
		if not '/' in str(each):
			if not 'rows' in str(each) :
                        	if not "TABNAME" in each:
                                	if not "--" in each:

						field_name = (each.strip()).split(' ')[-1]
						table_name = (each.strip()).split(' ')[0]
						
	
						file2.write('CREATE INDEX '+ table_name + '_' + field_name + ' on ' +  database_sid.upper() + '.SAPSR3.' + table_name + '(' + field_name + ')\ngo \n')
	#file2.write("go")
        file2.close()
	port = 22

        remote= '/tmp/index.sql'
        print remote
        local= path + '/index.sql'
        print local

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)

	
	
	command = "sudo su - " + user + " -c \' isql -U" + db_user + " -P" + db_password + " -S"+ database_sid.upper() +" -X -i/tmp/index.sql \'"
	print command
        stdin, stdout, stderr = client.exec_command(command, get_pty=True)
	out = stdout.readlines()
	print stdout.readlines()

	if not out:
		print "PRE:P:Database login  check for " + user + " is successful on  server " + hostname
	else:
		print "PRE:F:Database login  check for " + user + " is failed on  server " + hostname
#p = []
#out = str(out).replace(" ","")
#p = ' \n'.join(out.split()) 
#out= (out.strip()).split('\n')
#print type(p)
#for each in out:
#	print each.split(' ')
	sftp.close()
	transport.close()
	channel.close()
	client.close()
except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
                print "PRE:F:GERR_0201:Hostname unknown"
        elif str(e).strip() == "list index out of range":
                print "PRE:F:GERR_0202:Argument/s missing for the script"
        elif str(e) == "Authentication failed.":
                print "PRE:F:GERR_0203:Authentication failed for the " + string + " system " + hostname + " for user " + sudo_user
        elif str(e) == "[Errno 110] Connection timed out":
                print "PRE:F:GERR_0204:Host Unreachable"
        elif "getaddrinfo failed" in str(e):
                print "PRE:F:GERR_0205: Please check the hostname that you have provide"
        elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
        else:
                print "PRE:F: " + str(e)

