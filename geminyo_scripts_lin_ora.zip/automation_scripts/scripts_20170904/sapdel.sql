use SBX
delete SBX.SAPSR3.USR02 where MANDT='000' and BNAME='SAP*'
update SBX.SAPSR3.USR02 set UFLAG = 0 where BNAME = 'SAP*' and  MANDT='000'
go