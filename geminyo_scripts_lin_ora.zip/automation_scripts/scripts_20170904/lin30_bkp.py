print 'PRE:P:bitmap index created successfully'

