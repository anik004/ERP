from __future__ import division
from paramiko import *
import paramiko
from sys import *
import re
#from log4erp import *


def mount(hostname, username, password):


    try:
#	database_sid=argv[2]

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()


	command = "echo " + password + " | sudo -S ls /home/ "
	print "The 1st sudo command is : sudo ls /home/"
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	out = ''.join(stdout.readlines())
	out = out.split(':',1)[1].strip()
	print "The command output is : \n" + out
        if status == 0:
	    print "PRE:P:successful"

	command = "echo " + password + " | sudo -S whoami"
	print "The 2nd sudo command is : sudo whoami"
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()

	out = ''.join(stdout.readlines())
	out = out.split(':',1)[1].strip()
	print "The command output is : \n" + out

	command = "echo " + password + " | sudo -S ls /home/ "
	print "The 3rd sudo command is : sudo ls /home/"
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	out = ''.join(stdout.readlines())
	out = out.split(':',1)[1].strip()
	print "The command output is : \n" + out
    except Exception as e:
	if str(e) == "'decimal' codec can't encode character u'\u2018' in position 18: invalid decimal Unicode string":
	    print "PRE:F: The proper data is not available in the system"
	    exit()
	else:
            print "F: " + str(e)


try:
        source_server = mount(argv[1], argv[2], argv[3])


except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "PRE:F:GERR_0501:Hostname unknown"
     elif str(e) == "list index out of range":
                print "PRE:F:GERR_0502:Argument/s missing for the script"
     elif str(e) == "Authentication failed.":
                print "PRE:F:GERR_0503:Authentication failed."
     elif str(e) == "[Errno 110] Connection timed out":
                print "PRE:F:GERR_0504:Host Unreachable"
     elif "getaddrinfo failed" in str(e):
                print "PRE:F:GERR_0505: Please check the hostname that you have provide"
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "PRE:F:GERR_0506:Host Unreachable or Unable to connect to port 22"
     elif "invalid decimal" in str(e):
		print "PRE:F:GERR_0507:Unknown Error:" + str(e)
     else:
                print "PRE:F: " + str(e)

