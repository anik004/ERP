import paramiko
from paramiko import *
from sys import *
import subprocess
from subprocess import *


host = argv[1]
sudo_user = argv[2]
passwd = argv[3]
sid = argv[4]
type_name = argv[5]

try:

	if argv[5].upper() == 'CI' or argv[5].upper() == 'AI':
	 	username = sid.lower() + "adm"

		client = SSHClient()
	        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        	client.connect(host, username=sudo_user, password=passwd)
	     	channel = client.invoke_shell()

        
		command = "sudo su - " + username + " -c \"disp+work  \""
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        status = stdout.readlines()
		print status[0]	
		if " does not exist" in status[0]:
			print "WRP_DETAILS:F: The sid " + sid + " passed by the user in incorrect "
		else:
			for out in status:

				if "compiled on" in out:
					os_name = (str(out).split())
					os_name = str(os_name[2]).upper() + " ON "+ str(os_name[5])
	
				elif "compiled for" in out:
					bits = (str(out).strip()).split(" ")[-2]

				elif "compilation mode" in out:
					uc = (str(out).strip()).split(" ")[-1]

				elif "kernel release" in out:
					kernel_ver = (str(out).strip()).split(" ")[-1]

				elif "patch number" in out:
					kernel_patch = (str(out).strip()).split(" ")[-1]
			print os_name + "|" + uc + "|" + bits + " bit|" + kernel_ver + "|" + kernel_patch
		channel.close()
		client.close()
	else:
		print 'na|na|na|na|na'


except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
     	print "KERNELDETAILS:F:GERR_1301:Hostname unknown:" + sid
     elif "list index out of range" in str(e):
        print "KERNELDETAILS:F:GERR_1302:Argument/s missing for the script:" + sid
     elif str(e) == "Authentication failed.":
        print "KERNELDETAILS:F:GERR_1303:Authentication failed.:" + sid
     elif str(e) == "[Errno 110] Connection timed out":
        print "KERNELDETAILS:F:GERR_1304:Host Unreachable:" + sid
     elif "getaddrinfo failed" in str(e):
        print "KERNELDETAILS:F:GERR_1305: Please check the hostname that you have provide:" + sid
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "KERNELDETAILS:F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + sid
     elif "invalid decimal" in str(e):
        print "KERNELDETAILS:F:GERR_1307:Unknown Error:" + str(e) + ":" + sid
     elif "su: user oradp does not exist" in str(e):
	print "KERNELDETAILS:f:gerr_1308:DB SID for the host "+host+" incorrect:" + sid
     else:
        print "KERNELDETAILS:F: " + str(e) + ":" + sid

