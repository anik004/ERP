import paramiko
import os
from sys import *
from paramiko import *
import subprocess
import log4erp
from log4erp import *

def scp_check (t_host,t_user,t_pass,string,appsid,logfile,log):
	try:
		client1 = SSHClient()
	        client1.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        	client1.connect( t_host,username = t_user, password = t_pass)
	        channel1 = client1.invoke_shell()
	
		command = "sudo touch /tmp/test.txt ; sudo chmod 777 /tmp/test.txt"
		print command
		log4erp.write(logfile,command)
		os.system(command)
#                stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
#		print stdout.readlines()

	        filepath = '/tmp/test.txt'
		
        	localpath = '/tmp/test.txt'

	        transport1 = paramiko.Transport((t_host, port))
        	transport1.connect(username = t_user, password = t_pass)
	        sftp1 = paramiko.SFTPClient.from_transport(transport1)
        	sftp1.put(localpath, filepath)

		command = "sudo ls "+ filepath
		print command
		log4erp.write(logfile,command)
		stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
		log4erp.write(logfile,str(stdout))
		if  stdout.channel.recv_exit_status() == 0:
		        print "SCP:P: Scp service is available from the source server to the target " + string.upper() + " server ( hostname - " + t_host + " ):"+appsid.upper() 
			log4erp.write(log,"SCP:P: Scp service is available from the source server to the target " + string.upper()  + " server ( hostname - " + t_host + " ):"+appsid.upper() )
		else:
			print "SCP:F: Scp service is not available from the source server to the target " + string.upper()  + " server ( hostname - " + t_host + " ):"+appsid.upper() 
			log4erp.write(log,"SCP:F: Scp service is not available from the source server to the target " + string.upper()  + " server ( hostname - " + t_host + " ):"+appsid.upper() )

        	#command = "sudo rm -rf /tmp/test.txt"
	        #os.system(command)
        	#stdin, stdout, stderr = client.exec_command(command,timeout=60,get_pty=True)
	        command = "sudo rm -rf /tmp/test.txt"
		log4erp.write(logfile,command)
        	stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
		log4erp.write(logfile,str(stdout))
	        #command="rm -rf /tmp/test.txt"
        	#subprocess.check_call(command,shell=True)


	        sftp1.close()
        	transport1.close()
	        #channel.close()
        	#client.close()
	        channel1.close()
        	client1.close()

	except Exception as e:
		if str(e) == "[Errno -2] Name or service not known":
                        print "SCP_CHECK:F:GERR_0201:Hostname unknown:"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0201:Hostname unknown:"+appsid.upper() )
                elif str(e).strip() == "list index out of range":
                        print "SCP_CHECK:F:GERR_0202:Argument/s missing for the script:"+appsid.upper() 
                elif str(e) == "Authentication failed.":
                        print "SCP_CHECK:F:GERR_0203:Authentication failed.:"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0203:Authentication failed.:"+appsid.upper() )
                elif str(e) == "[Errno 110] Connection timed out":
                        print "SCP_CHECK:F:GERR_0204:Host Unreachable:"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0204:Host Unreachable:"+appsid.upper() )
                elif "getaddrinfo failed" in str(e):
                        print "SCP_CHECK:F:GERR_0205: Please check the hostname that you have provide:"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0205: Please check the hostname that you have provide:"+appsid.upper() )
                elif "[Errno None] Unable to connect to port 22" in str(e):
                        print "SCP_CHECK:F:GERR_0206:Host Unreachable or Unable to connect to port 22:"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0206:Host Unreachable or Unable to connect to port 22:"+appsid.upper() )
		elif "Permission denied" in str(e):
        		print "SCP_CHECK:F:GERR_0206:Permission denied for the user " + t_user+":"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F:GERR_0206:Permission denied for the user " + t_user+":"+appsid.upper() )
                else:
                        print "SCP_CHECK:F: " + str(e)+":"+appsid.upper() 
			log4erp.write(log,"SCP_CHECK:F: " + str(e)+":"+appsid.upper() )


try:
	if argv[1] == "--u":
		print "usage: python scp.py <Target host> <Target sudo user> <Target sudo user pass> <String> "
	else:
		t_host = argv[1]
		t_user = argv[2]
		t_pass = argv[3]
		string = argv[4]
		appsid = argv[5]
		logfile = argv[6]
		log = argv[7]
		port = 22
		#print t_host + t_user + t_pass
		scp_check( t_host,t_user,t_pass,string,appsid,logfile,log)
						

except Exception as e:

    if str(e) == "[Errno -2] Name or service not known":
        print "SCP:F:GERR_0601:Hostname unknown:"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0601:Hostname unknown:"+appsid.upper() )
    elif str(e) == "list index out of range":
        print "SCP:F:GERR_0602:Argument/s missing for the script:"+appsid.upper() 
    elif "Authentication failed." in str(e):
        print "SCP:F:GERR_0603:Authentication failed.:"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0603:Authentication failed.:"+appsid.upper() )
    elif str(e) == "[Errno 110] Connection timed out":
        print "SCP:F:GERR_0604:Host Unreachable:"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0604:Host Unreachable:"+appsid.upper() )
    elif "getaddrinfo failed" in str(e):
        print "SCP:F:GERR_0605: Please check the hostname that you have provide:"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0605: Please check the hostname that you have provide:"+appsid.upper() )
    elif "Unable to connect to port 22" in str(e):
        print "SCP:F:GERR_0606:Host Unreachable or Unable to connect to port 22:"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0606:Host Unreachable or Unable to connect to port 22:"+appsid.upper() )
    elif "invalid decimal" in str(e):
        print "SCP:F:GERR_0607:Unknown Error:" + str(e)+":"+appsid.upper() 
	log4erp.write(log,"SCP:F:GERR_0607:Unknown Error:" + str(e)+":"+appsid.upper() )
    elif "Permission denied" in str(e):
	print "SCP:Permission denied:"+appsid.upper() 
	log4erp.write(log,"SCP:Permission denied:"+appsid.upper() )
    else:
        print "SCP:F: " + str(e)+":"+appsid.upper() 
	log4erp.write(log,"SCP:F: " + str(e)+":"+appsid.upper() )
