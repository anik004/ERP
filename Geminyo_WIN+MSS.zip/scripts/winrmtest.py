from winrm.protocol import Protocol

p = Protocol(
    endpoint='https://pgcsrb00:5986/wsman',
    transport='kerberos',
    username=r'sap\srbadm',
    password='PGC4n0w!',
    server_cert_validation='ignore')
shell_id = p.open_shell()
command_id = p.run_command(shell_id, 'tp addtobuffer SOLK900174 srb Client=000 pf=\\PGCSRDT0\sapmnt\trans\bin\TP_DOMAIN_SRB.PFL')
std_out, std_err, status_code = p.get_command_output(shell_id, command_id)
print std_out
print std_err
print status_code
p.cleanup_command(shell_id, command_id)
p.close_shell(shell_id)
