from __future__ import unicode_literals

from django.apps import AppConfig


class EpiskyAppConfig(AppConfig):
    name = 'episky_app'
