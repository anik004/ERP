from django.test import TestCase

# Create your tests here.
class test():
    def test_f(self,a,b):
        return a,b

t = test()
a = t.test_f(1, 2)
print a

