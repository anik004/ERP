from sys import *
import glob
from os import *
from subprocess import *
import os
import subprocess
import ntpath
import log4erp
from log4erp import *

try:
 
    if argv[1] == "--u":
        print "python check_folder.py <Folder name>"
    else:
#	if argv[1] == "REDHAT":
	
		fold_name = argv[1].rstrip('/')
		logfile = "check_log.log"
		log = "Episky_log.log"

		command = os.path.exists(fold_name.strip())
		log4erp.write(logfile, str(command))
		out = command
		log4erp.write(logfile,str(out))
	
		if str(out) == "True":
				path = fold_name + "/*.SAR"
				log4erp.write(logfile,path)
				out = glob.glob(path)
				log4erp.write(logfile,str(out))
			#print out
				if out:
					for files in out:
						print ntpath.basename(files)
						out = ntpath.basename(files)
						log4erp.write(logfile,str(out))
	
				else:
					print "CHECK_FOLDER:F:There is no .sar extension file in this folder - " + fold_name
					log4erp.write(log,"CHECK_FOLDER:F:There is no .sar extension file in this folder - " + fold_name)
		else:
			print "CHECK_FOLDER:F: Folder " + fold_name + " does not exist"
			log4erp.write(log,"CHECK_FOLDER:F: Folder " + fold_name + " does not exist")
#	else:
#		print "script not found"

except Exception as e:
	if str(e).strip() == "list index out of range":
               print "CHECK_FOLDER:F:GERR_0202:Argument/s missing for the script"
        elif "Permission denied" in str(e):
               print "CHECK_FOLDER:F:GERR_0206:Permission denied for the user" + t_user
	       log4erp.write(log,"CHECK_FOLDER:F:GERR_0206:Permission denied for the user" + t_user)
        else:
               print "CHECK_FOLDER:F " + str(e)
	       log4erp.write(log,"CHECK_FOLDER:F " + str(e))
