import re
from re import *
import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *


def ker_rstr(hostname, username, password, user, app_sid, kerref_id, logfile, logfile2):


	client1 = SSHClient()
        client1.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client1.connect( hostname,username = username, password = password)
        channel1 = client1.invoke_shell()

	
	kernel_path="sudo su - " + user + " -c \"which disp+work | sed 's/\/disp+work//'\""
        log4erp.write(logfile,kernel_path)
        stdin, stdout, stderr = client1.exec_command(kernel_path, timeout=1000, get_pty=True)
        log4erp.write(logfile,str(stdout))
        kernel_path = stdout.readlines()
        kernel_path=kernel_path[0].strip()	
	log4erp.write(logfile,str(kernel_path))
	
	folder = (kernel_path.split('/')) [-1]	# kernel folder
	log4erp.write(logfile,str(folder))

#	ker = kernel_path.split('/')[:-1]
#	log4erp.write(logfile,str(ker))
	
#	file_path = "/"
	
#	for i in ker:
#		file_path = file_path  + i + "/"
#		print file_path		# backup folder path till UC
#	
	ker_bkp = str(kernel_path) + "_bkp_" + kerref_id # complete path of backup folder
	log4erp.write(logfile,str(ker_bkp))


############################################## kernel path exixtance check ##################################################################
	
	command = "sudo su - " + user + " -c \" cd " + kernel_path + " \""
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
        log4erp.write(logfile,str(stdout.readlines()))
        if  stdout.channel.recv_exit_status() != 0:
		 print "WRPker_rstr:F: Kernel Path - " +  kernel_path + " not found : " + app_sid
                 log4erp.write(logfile2, "ker_rstr:F: Kernel Path - " +  kernel_path + " not found : " + app_sid)
		 exit()

############################################ kernel backup existance check ##############################################################

	command = "sudo su - " + user + " -c \" cd " + ker_bkp + " \""
        log4erp.write(logfile,command)
        stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
        log4erp.write(logfile,str(stdout.readlines()))
        if  stdout.channel.recv_exit_status() != 0:
		print "WRPker_rstr:F: backup folder " + ker_bkp.split("/")[-1] + " does not exist :" + app_sid
		log4erp.write(logfile2, "WRPker_rstr:F: backup folder " + ker_bkp.split("/")[-1] + "does not exist :" + app_sid)
		exit()

######################################## renaming existing kernel #######################################################################

	command = "sudo su - " + user + " -c \" mv " + kernel_path + " " + kernel_path + "_fail \""   
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
        log4erp.write(logfile,str(stdout.readlines()))
        if  stdout.channel.recv_exit_status() != 0:
		print "WRPker_rstr:F: Unable to rename the kernel folder :" + app_sid
		log4erp.write(logfile2, "WRPker_rstr:F: Unable to rename the kernel folder :" + app_sid)
		exit()


##################################### renaming backup kernel as kernel  ####################################################################

	command = "sudo su - " + user + " -c \" rm " + ker_bkp + "\ker_file.txt \" "
	log4erp.write(logfile,command)
	stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
	log4erp.write(logfile,str(stdout.readlines()))
	command = "sudo su - " + user + " -c \" mv " + ker_bkp + " " + kernel_path + " \" "
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client1.exec_command(command,timeout=60,get_pty=True)
        log4erp.write(logfile,str(stdout.readlines()))
        if  stdout.channel.recv_exit_status() != 0:
		print "WRPker_rstr:F: Unable to restore the kernel :" + app_sid
		log4erp.write(logfile2, "WRPker_rstr:F:Unable to restore the kernel :" + app_sid)
		exit()

	else:
		print "WRPker_rstr:P: System Restoration Successfull : " + app_sid
                log4erp.write(logfile2,"ker_rstr:P: System Restoration Successfull : " + app_sid)
		
			
	

	channel1.close()
	client1.close()

try:
	

	hostname = argv[1]
        username = argv[2]
        password = argv[3]
        app_sid = argv[4].lower()
        kerref_id = argv[5]
        logfile = argv[6]
	logfile2 = argv[7]
        user = app_sid+'adm'
	


	ker_rstr(hostname, username, password, user, app_sid, kerref_id, logfile, logfile2)

except Exception as e:

    if str(e) == "[Errno -2] Name or service not known":
        print "WRPker_rstr:F:GERR_0601:Hostname unknown:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0601:Hostname unknown:"+app_sid)
    elif str(e) == "list index out of range":
        print "WRPker_rstr:F:GERR_0602:Argument/s missing for the script:"
    elif "Authentication failed." in str(e):
        print "WRPker_rstr:F:GERR_0603:Authentication failed.:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0603:Authentication failed.:"+app_sid)
    elif str(e) == "[Errno 110] Connection timed out":
        print "WRPker_rstr:F:GERR_0604:Host Unreachable:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0604:Host Unreachable:"+app_sid)
    elif "getaddrinfo failed" in str(e):
        print "WRPker_rstr:F:GERR_0605: Please check the hostname that you have provide:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0605: Please check the hostname that you have provide:"+app_sid)
    elif "Unable to connect to port 22" in str(e):
        print "WRPker_rstr:F:GERR_0606:Host Unreachable or Unable to connect to port 22:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0606:Host Unreachable or Unable to connect to port 22:"+app_sid)
    elif "invalid decimal" in str(e):
        print "WRPker_rstr:F:GERR_0607:Unknown Error:" + str(e)+":"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F:GERR_0607:Unknown Error:" + str(e)+":"+app_sid)
    elif "Permission denied" in str(e):
        print "WRPker_rstr:Permission denied:"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:Permission denied:"+app_sid)
    else:
        print "WRPker_rstr:F: " + str(e)+":"+app_sid
        log4erp.write(logfile2,"WRPker_rstr:F: " + str(e)+":"+app_sid)

