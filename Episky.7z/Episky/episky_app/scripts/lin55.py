from __future__ import division
from threading import Thread
import paramiko
from paramiko import *
from sys import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *
import time
import os
from os import *
def dbstop(hostname,sudo_user,sudo_passwd,db_sid,app_sid,iseq_no,logfile,log):
   try:
        user_db = "ora" + db_sid.lower()

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = sudo_user, password = sudo_passwd)
        channel = client.invoke_shell()
        #write(log,'PRE:I: DB Triggered')

        command = 'sudo su - ' + user_db + ' -c \'echo "shutdown immediate" | sqlplus / as sysdba\''
        log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	out = stdout.readlines()
	log4erp.write(logfile,str(out))
	#print out[0]
	out = out[0].strip()
	
        #print status
	if "does not exist" in out:
	     print 'WRPDB_STOP:F: Database SID - ' + db_sid + " passed by the user is incorrect :" + hostname + "_" + app_sid + "_" + seq_no
	     log4erp.write(log,app_sid + ":F: Database SID - " + db_sid + " passed by the user is incorrect (HOSTNAME - " + hostname + '):' + app_sid)
	     exit()

        elif status == 0: 
            print 'WRPDB_STOP:P: The Database has been stopped on the target server :' + hostname + "_" + app_sid + "_" + seq_no
            log4erp.write(log,app_sid + ':P: The Database has been stopped on the target server (HOSTNAME - ' + hostname + '):' + app_sid)
         
            command = 'sudo su - ' + user_db + ' -c \'lsnrctl stop\''
	    log4erp.write(logfile,command)
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	    out = stdout.readlines()
	    log4erp.write(logfile,str(out))
            status = stdout.channel.recv_exit_status()

            if status == 0 or status == 1:
                print 'WRPDB_STOP:P: The listener has been stopped on the target server :' + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':P: The listener has been stopped on the target server (HOSTNAME - ' + hostname +'):' + app_sid)
		

#		command = 'sudo su - ' + user_db + ' -c \"R3trans -d \" '
#		log4erp.write(logfile,command)
 #           	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
 #           	log4erp.write(logfile,str(stdout))
#		out = stdout.readlines()
            else:
                print 'WRPDB_STOP:F: The Database is not successfully stopped successfully on the target server :' + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F: The Database is not successfully stopped successfully on the target server (HOSTNAME - ' + hostname + '):' + app_sid)
             
	
        channel.close()
        client.close()

   except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "WRPDBSTOP:F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F: Hostname unknown [Error Code - 1301]:' + app_sid)
     elif str(e) == "list index out of range":
                print "WRPDBSTOP:F:GERR_1302:Argument/s missing for the script:" + hostname + "_" + app_sid
     elif str(e) == "Authentication failed.":
                print "WRPDBSTOP:F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F:Authentication failed.[Error Code - 1303]:' + app_sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "WRPDBSTOP:F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F:Host Unreachable.[Error Code - 1304]:' + app_sid)
     elif "getaddrinfo failed" in str(e):
                print "WRPDBSTOP:F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + app_sid)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPDBSTOP:F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + app_sid)
     elif "invalid decimal" in str(e):
                print "WRPDBSTOP:F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,app_sid + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + app_sid)
     else:
                print "WRPDBSTOP:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seq_no
		log4erp.write(log,app_sid + ":F: " + str(e) + ":" + app_sid) 

try:

     hostname = argv[1]
     sudo_user = argv[2]
     sudo_passwd = argv[3]
     db_sid = argv[4]
     app_sid = argv[5]
     seq_no = argv[6]
     logfile = argv[7]
     log = argv[8]


     dbstop(hostname,sudo_user,sudo_passwd,db_sid,app_sid,seq_no,logfile,log)
	

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "WRPDBSTOP:F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F: Hostname unknown [Error Code - 1301]:' + app_sid)
     elif str(e) == "list index out of range":
                print "WRPDBSTOP:F:GERR_1302:Argument/s missing for the script:" + hostname
     elif str(e) == "Authentication failed.":
                print "WRPDBSTOP:F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F:Authentication failed.[Error Code - 1303]:' + app_sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "WRPDBSTOP:F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F:Host Unreachable.[Error Code - 1304]:' + app_sid)
     elif "getaddrinfo failed" in str(e):
                print "WRPDBSTOP:F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F: Please check the hostname that you have provide [Error Code - 1305]:' + app_sid)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPDBSTOP:F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + app_sid)
     elif "invalid decimal" in str(e):
                print "WRPDBSTOP:F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,'PRE:F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + app_sid)
     else: 
                print "WRPDBSTOP:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seq_no
                log4erp.write(log,"DBSTOP:F: " + str(e) + ":" + app_sid)
