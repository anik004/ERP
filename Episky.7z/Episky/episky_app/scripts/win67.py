from __future__ import division
import sys
from sys import *
import subprocess
from subprocess import *
from threading import Thread
import time
import authmodule
from authmodule import *
import pingmodule
from pingmodule import *


def upgrade(t_host, t_user, t_passwd, t_app_sid, t_kernelpath, scriptloc, k_id, ker_refid, folder_path, re_execute, logfile1, logfile2):
    try:
        ping(t_host, t_app_sid, re_execute, logfile1)
        auth(t_host, t_user, t_passwd, t_app_sid, scriptloc, re_execute, logfile1)

        if re_execute == "0":
            command = "c:\\python27\\python " + scriptloc + "\win51 " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_kernelpath + " " + scriptloc + " " + ker_refid + " " + re_execute + " " + logfile1 + " " + logfile2
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
            if status == 'P':
                print "WRPBACKUP_KERNEL:P: Kernel folder backup has been taken successfully: " + t_host + "_" + t_app_sid + "_" + re_execute
                write(logfile2,"BACKUP_KERNEL:P: Kernel folder backup has been taken successfully: "+ t_host + "_" + t_app_sid + "_" + re_execute) 
                re_execute = str(1)
            else:
                print out
                exit()

        if re_execute == "1":
            command = "c:\\python27\\python " + scriptloc + "\win55 " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_kernelpath + " " + scriptloc + " " + folder_path + " "+ k_id + " " + re_execute + " " + logfile1 + " " + logfile2
            print command
            write(logfile1, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
            if status == 'P':
                #print out
		print "WRPCOPY_KERNEL:P: Kernel file  has been copied successfully: " + t_host + "_" + t_app_sid + "_" + re_execute
		write(logfile2,"WRPCOPY_KERNEL:P: Kernel file  has been copied successfully: " + t_host + "_" + t_app_sid + "_" + re_execute)
                re_execute = str(2)
            else:
                print out
                exit()

        if re_execute == "2":
            command = "c:\\python27\\python "+ scriptloc + "\win57 " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_kernelpath + " " + scriptloc + " " + k_id + " " + ker_refid + " " + re_execute + " " + logfile1 + " " + logfile2
            print command
	    write(logfile1,command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
            if status == 'P':
		#print out
                print "WRPKERNELEXTRACTION:P: KERNEL FILES extraction has been completed successfully : " + t_host +"_"+ t_app_sid.upper() + "_" + re_execute
                write(logfile1,"WRPKERNELEXTRACTION:P: KERNEL FILES extraction has been completed successfully : " + t_host +"_"+ t_app_sid.upper() + "_" + re_execute)
            else:
                print out
                exit()


    except Exception as e:
        print "WRPKERNELEXTRACTION:F:" + str(e) + ": " + t_host + "_" + t_app_sid + "_" + re_execute


try:
    if argv[1] == "--u":
        print "usage: python kernel_upgrade.py <Trg H> <Usr> <PW> <APP s> <Inst Dir> <ini> <K id> <Str>"
    else:

                t_host = argv[1]
                t_user = argv[2]
                t_passwd = argv[3]
                t_app_sid = argv[4].lower()
                t_kernelpath = argv[5]
                scriptloc = argv[6].rstrip('\\')
                k_id = argv[7]
                ker_refid = argv[8]
                folder_path = argv[9]
                re_execute = argv[10]
                logfile1 = argv[11]
                logfile2 = argv[12]

                upgrade(t_host, t_user, t_passwd, t_app_sid, t_kernelpath, scriptloc, k_id, ker_refid, folder_path, re_execute, logfile1, logfile2)


except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
               print "WRPKERNELEXTRACTION:F:GERR_0201:Hostname unknown"
        elif str(e).strip() == "list index out of range":
               print "WRPKERNELEXTRACTION:F:GERR_0202:Argument/s missing for the script"
        else:
               print "WRPKERNELEXTRACTION:F: " + str(e)

