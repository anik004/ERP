
from sys import *
import subprocess
import log4erp
from log4erp import *
import os

def rollback(hostname, username, password, appsid, kernel_path, scriptloc, k_id, ker_refid,t_osname, logfile1, logfile2, step_name):
    try:
        path_exist = os.path.isdir(scriptloc)
        if "False" in str(path_exist):
            print 'WRPROLL_BACK:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no  + " " + step_name
            write(logfile1, 'WRPROLL_BACK:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no + " " + step_name)
            exit()

        sol_osname = os.name
        if sol_osname.lower() == "nt":
            if t_osname == "windows":
                path = scriptloc
                #print path
                command = "c:\\python27\\python.exe " + path + "\ker_rstr " + hostname + " " + username + " " + password + " " + appsid + " " + scriptloc + " " + kernel_path + " " + k_id + " " + logfile1 + " " + logfile2
                write(logfile1, "command : " + command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                if ":F:" in out:
                    print "WRP"+ out.strip() + ":" + step_name
                    exit()
                else:
                    print "WRP"+ out.strip() + ":" + step_name

        elif sol_osname.lower() == "posix":
            if t_osname.lower() == "windows":
                path = scriptloc.rstrip('/')
                command = "c:\\python27\\python.exe " + path + "\ker_rstr " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + instance + " " + db_type + " " + ai_ci_db + " " + seq_no + " " + logfile1 + " " + logfile2
                write(logfile1, "command : " + command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                if ":F:" in out:
                    print "WRP"+ out+ ":" + step_name
                    exit()
                else:
                    print "WRP"+ out+ ":" + step_name
	    elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" :
		 path = scriptloc.rstrip('/')
		 logfile1 = scriptloc + "/" + ker_refid + "_log.log"
    		 logfile2 = scriptloc + "/" + "EpiskyClient_log.log"
		 command = "python " + path + "/ker_rstr " + hostname + " " + username + " " + password + " " + appsid + " " + ker_refid + " " + logfile1 + " " + logfile2
		 print command
		 write(logfile1, "command : " + command)
                 command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                 out, err = command.communicate()
                 if ":F:" in out:
                    print "WRP"+ out+ ":" + step_name
                    exit()
                 else:
                    print "WRP"+ out+ ":" + step_name		
	    else:
		print "WRPKERRES:F:script not found:"+appsid 
		write(logfile2,"WRPKERRES:F:script not found:"+appsid)
	else:
		print "WRPKERRES:F:script not found:"+appsid		 
		write(logfile2,"WRPKERRES:F:script not found:"+appsid)

    except Exception as e:
        if str(e) == "list index out of range":
            print "STOPSAPINDEP:F:GERR_1202:Argument/s missing for the script"
        else:
            print "STOPSAPINDEP:F: " + str(e) + ":" + step_name



try:
    file_path = argv[1]
    error_code = argv[2]
    error_code = error_code.split("_")
    host_err = error_code[0]
    appsid_err = error_code[1]
    seq_no = error_code[2]
    step_name = argv[3]

    f = open(file_path, 'r')
    content = f.read()
    line= content.split('|')
    hostname = line[0]
    username = line[1]
    password = line[2]
    appsid = line[3].upper()
    kernel_path = line[5]
    scriptloc = line[6].rstrip('\\')
    k_id = line[8]
    ker_refid = line[9]
    t_osname = line[7]
    logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
    logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"

    rollback(hostname, username, password, appsid, kernel_path, scriptloc, k_id, ker_refid,t_osname, logfile1, logfile2, step_name)


except Exception as e:
    if str(e) == "list index out of range":
        print "STOPSAPINDEP:GERR_1202:Argument/s missing for the script"
    else:
        print "STOPSAPINDEP: " + str(e)
