#!/usr/bin/python
import re
from sys import *
import subprocess
import log4erp
from log4erp import *

try:
    hostname=argv[1]
    username = argv[2]
    password = argv[3]
    appsid = argv[4].upper()
    path = argv[5]			#KERNEL PATH
    location = argv[6].rstrip('\\')		#SCRIPT PATH
    ker_refid = argv[7]
    re_execute = argv[8]
    logfile1 = argv[9]
    logfile2 = argv[10]

################################### FOLDER EXISTENCE CHECK IN REMOTE SERVER ##################################

    command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + path + '"'
    write(logfile1, command)
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1,out)
    if "True" in out:
        folder = (str(path).strip()).split('\\')[-1]
        a = (str(path).strip()).split('\\')[:-1]
        path =""
        for i in a:
            path += i + "\\"

#################################### CHECKING IF KERNEL BKP FOLDER EXIST #####################################

        command = 'c:\\python27\\python.exe '+ location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"dir ' + path[:-1] + ' | findstr /i bkp\" ' #| tail -n 2'
        write(logfile1,command)
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1,out)
        if "BKP" in out:
            #print "exist"

    ################################## COPYING KERNEL FILE FROM ACTUAL FOLDER TO BACKUP KERNEL FOLDER (IF BACKUP FOLDER EXIST) ###################

            command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"xcopy ' + path + folder +  ' ' + path + folder + '_BKP_'+ ker_refid +'\ /Y\"'
            write(logfile1, command)
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
            write(logfile1,out)
            if "copied" in out :
                print "WRPBACKUP_KERNEL:P: Kernel folder backup has been taken successfully: " + hostname + "_" + appsid + "_" + re_execute
                write(logfile2,"BACKUP_KERNEL:P: Kernel folder backup has been taken successfully: "+ hostname + "_" + appsid + "_" + re_execute)
            else:
                print "WRPBACKUP_KERNEL:F: Unable to take backup of kernel folder: " + hostname + "_" + appsid + "_" + re_execute
                write(logfile2,"BACKUP_KERNEL:F: Unable to take backup of kernel folder: "+ hostname + "_" + appsid + "_" + re_execute)
		exit()

        else:
    ################################## CREATING KERNEL BACKUP FOLDER #########################################

            command = 'c:\\python27\\python.exe '+location+'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \" md ' + path + folder + '_BKP_' + ker_refid +'\"'
            write(logfile1, command)
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
            write(logfile1,out)

    ################################## COPYING KERNEL FILE FROM ACTUAL FOLDER TO BACKUP KERNEL FOLDER (IF BACKUP FOLDER DOES NOT EXIST) ###################

            command='c:\\python27\\python.exe '+ location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"xcopy ' + path + folder +  ' ' + path + folder + '_BKP_' + ker_refid + ' /y\"'
            write(logfile1, command)
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
            write(logfile1,out)
            if "copied" in out:
                print "WRPBACKUP_KERNEL:P: Kernel files are copied to backup successfully:" + hostname + "_" + appsid + "_" + re_execute
                write(logfile2, "BACKUP_KERNEL:P: Kernel files are copied to backup successfully:" + hostname + "_" + appsid + "_" + re_execute)
            else:
                print "WRPBACKUP_KERNEL:F: Unable to backup kernel files:" + hostname + "_" + appsid + "_" + re_execute
                write(logfile2, "BACKUP_KERNEL:F: Unable to backup kernel files:" + hostname + "_" + appsid + "_" + re_execute)
		exit()
    else:
        print "WRPBACKUP_KERNEL:F:Kernel Path " + path + " does not exist "  + hostname + "_" + appsid + "_" + re_execute
        write(logfile2, "BACKUP_KERNEL:F: Kernel Path " + path + " does not exist "  + hostname + "_" + appsid + "_" + re_execute)
	exit()
except Exception as e:
        if str(e).strip() == "list index out of range":
            print "WRPBACKUP_KERNEL:F:GERR_0202:Argument/s missing for the script:"  + hostname + "_" + appsid + "_" + re_execute
        else:
            print "WRPBACKUP_KERNEL:F: " + str(e)+":"  + hostname + "_" + appsid + "_" + re_execute
            write(logfile1, "BACKUP_KERNEL:F: " + str(e)+":"  + hostname + "_" + appsid + "_" + re_execute)

