import paramiko
from paramiko import *
import subprocess
from subprocess import *
from sys import *
import log4erp 
from log4erp import *
import re
import os
from os import *
import sys


def sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log, seq_no, app_user):
	
	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

	if sys_type.lower() == 'abap':
                command = "sudo su - " + app_user + " -c '" + kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function GetProcessList\''
		log4erp.write(logfile,command)
        elif sys_type.lower() == 'java':
                command = kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function J2EEGetProcessList'
		log4erp.write(logfile,command)

        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
        out = stdout.readlines()
	log4erp.write(logfile,str(out))


	for i in out:
		if ',' in i:
	                i = (str(i)).split(',')
       	        	if len(i) == 7:
                        	status = i[2].strip()
       		                server = i[1].strip()
               		        if status == 'GREEN':
#      	               		        print server+' is running in the ' + hostname
					res = 'SSS:P:The server ' + hostname + ' is up and running'
					log4erp.write(logfile,res)
	      	                        return res
	                        elif status == 'YELLOW':
       		                        res = 'SSS:F:The server '+ hostname + ' is running with warning'
					log4erp.write(logfile,res)
					return res
                       		elif status == 'GRAY':
                               		res = 'SSS:F:The server ' + hostname + ' is stopped'
					log4erp.write(logfile,res)
					return res
			elif "NIECONN_REFUSED" in i:
				res = 'SSS:F:Instance number is wrong'
				log4erp.write(logfile,res)
		
	channel.close()
	client.close()

def strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log, seq_no):

        user_sap = app_sid.lower() + "adm"
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

	command = "hostname"
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        p_hostname = stdout.readlines()
	p_hostname = p_hostname[0]

	command = 'sudo su - ' + user_sap + ' -c \'cdpro; ls | grep -i ' + p_hostname.strip().lower() + ' | grep -v "\." | grep -v "ASC" | cut -d"_" -f2\''
        log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.readlines()
        log4erp.write(logfile,str(status))
        for i in status:
		if "MAIL" not in i:
	                instance = i.strip()[-2:]
			out = sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log, seq_no, user_sap)
			log4erp.write(logfile,str(out))
			status = (str(out).split('\n')[len(out.split('\n')) - 2]).split(':')[1]

			if status == "P":
	       			print "WRPSAPSTARTAPP:P: The SAP service is already started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
	       			log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service is already started on the target server (HOSTNAME - " + hostname + ")")
				exit()
            
        		else:
				flag = 0
				command = "sudo su - " + user_sap + " -c 'ps -ef | grep -i " + user_sap + " | grep -i /usr/sap | grep -v \"#\" | grep -v \"sapstartsrv\"| grep -v \"grep\" | cut -d\" \" -f4'"
				log4erp.write(logfile,command)
			       	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        			all_names = stdout.readlines()
				log4erp.write(logfile,str(all_names))
				if str(all_names).strip() == '[]':
				   flag = 1
				else:
			           for n in range (0, (len(all_names))):
                			proc = all_names[n].strip()
                			command = "sudo su - " + user_sap + ' -c "kill -9 ' + proc + '"'
#					print command
					log4erp.write(logfile,command)
                			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
					log4erp.write(logfile,str(stdout))
                			if stdout.channel.recv_exit_status() == 0:
						flag = 1
                    				print "WRPSAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server :" + hostname + "_" + app_sid + "_" + seq_no
                    				log4erp.write(log,"WRPSAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server (HOSTNAME - " + hostname + ")")
					else:
						flag = 0
				if flag == 1:
				
	    				if sys_type.lower() == "abap":
                				command = 'sudo su - ' + user_sap + ' -c "startsap r3 '  + p_hostname.strip().lower()+ '"'
	        				log4erp.write(logfile,command)
                				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout))
                				status = stdout.channel.recv_exit_status()
                				if status == 0:
							print "WRPSAPSTARTAPP:P: The SAP service has been started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
							log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
          
						else:
						        print "WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
						        log4erp.write(log,"WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
 #           write (log, log)
		    			elif sys_type.lower() == "java":
						command = 'sudo su - ' + user_sap + ' -c "startsap j2ee '  + hostname+ '"'
						log4erp.write(logfile,command)	        
					        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout))
					        status = stdout.channel.recv_exit_status()
					        if status == 0:
					                 print "WRPSAPSTARTAPP:P: The SAP service has been started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
					                 log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
                    
					        else:
					                  print "WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
					                  log4erp.write(log,"WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
        channel.close()
        client.close()



try:

	hostname = argv[1]
	username = argv[2]
 	password = argv[3]
	app_sid = argv[4]
	sys_type = argv[5]
	kernel_path = argv[6]
 	logfile = argv[7]
  	log = argv[8]
	ai_ci_db = argv[9]
	db_sid = argv[10]
  	path = argv[11].rstrip('/')
	seq_no = argv[12]
	db_type = argv[13]
	profile_path = argv[14]
	t_osname = argv[15]
	if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
		strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log, seq_no)

	elif ai_ci_db.upper() == "DB":
		sol_osname = os.name
		if sol_osname.lower() == "nt":
			if t_osname.lower() == "redhat":
				command = os.path.exists( path + "\lin54.py")
				print command
				log4erp.write(logfile, str(command))
				out = command
				print out
				log4erp.write(logfile,str(out))
				if str(out).strip() == 'True':

					path = path.rstrip("\\")
					#logfille1 = path + "/" + ker_refid + "_log.log"
					command = "c:\\python27\\python.exe " + path + "\lin54.py " + hostname + " " + username + " " + password + " " + app_sid + " " + db_sid + " " + logfile + " " + log + " " + seq_no
					print command
					#write(logfile,command)
					command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
					out, err = command.communicate()
					print out

			elif sol_osname.lower() == "posix":
				command = os.path.exists( path + "/lin54")
				log4erp.write(logfile, str(command))
				out = command
				log4erp.write(logfile,str(out))
				if str(out).strip() == 'True':
					command = "python " + path + "/lin54 " + hostname + " " + username + " " + password + " " + app_sid + " " + db_sid + " " + logfile + " " + log + " " + seq_no
					write(logfile,command)
					command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
					out, err = command.communicate()
					print out

		else:
			print "WRPSAPSTARTAPP:F:" + path + "/lin54 not found :" + hostname + " " + app_sid + " " + seq_no
	
		
		
except Exception as e:
	exc_type, exc_obj, tb = sys.exc_info()
	lineno = tb.tb_lineno
	print lineno
	if str(e) == "[Errno -2] Name or service not known":
		print "WRPSAPSTARTAPP:F:GERR_1301:Hostname unknown :" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F: Hostname unknown [Error Code - 1301]')
	elif str(e) == "list index out of range":
		print "WRPSAPSTARTAPP:F:GERR_1302:Argument/s missing for the script"
	elif str(e) == "Authentication failed.":
		print "WRPSAPSTARTAPP:F:GERR_1303:Authentication failed. :" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F:Authentication failed.[Error Code - 1303]')
	elif str(e) == "[Errno 110] Connection timed out":
		print "WRPSAPSTARTAPP:F:GERR_1304:Host Unreachable :" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F:Host Unreachable.[Error Code - 1304]')
	elif "getaddrinfo failed" in str(e):
		print "WRPSAPSTARTAPP:F:GERR_1305: Please check the hostname that you have provide :" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F: Please check the hostname that you have provide [Error Code - 1305]')
	elif "[Errno None] Unable to connect to port 22 on" in str(e):
		print "WRPSAPSTARTAPP:F:GERR_1306:Host Unreachable or Unable to connect to port 22 :" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]')
	elif "invalid decimal" in str(e):
		print "WRPSAPSTARTAPP:F:GERR_1307:Unknown Error " + str(e) + ":" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log,'WRPSAPSTARTAPP:F: Unknown Error:' + str(e) + '[Error Code - 1307]')
	else:
		print "WRPSAPSTARTAPP:F: " + str(e) + ":" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log, "WRPSAPSTARTAPP:F: " + str(e))


