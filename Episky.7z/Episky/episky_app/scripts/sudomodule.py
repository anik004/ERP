import sys
from sys import *
import paramiko
from paramiko import *



def s_user(hostname,username,password,sid,string):
	if string.upper() == 'AI' or string.upper() == 'CI':
		user = (sid.lower()).strip() +"adm"
	elif string.upper() == "DB":
		user = "ora" +(sid.lower()).strip()
	
	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()
	command = "sudo su - " + user +"| ls " 
#	print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#	print stdout
#	print stdout.channel.recv_exit_status()

	if stdout.channel.recv_exit_status() != 0:
		print "SUDO:F:No sudo permission for the user "+user+" :"+sid 
	else:
		print "SUDO:P:"+user+" has sudo permission:"+sid

	channel.close()
	client.close()
