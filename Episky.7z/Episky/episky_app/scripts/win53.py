#!/usr/bin/sh
from __future__ import division
import re
import glob
import os
from sys import *
import subprocess
import log4erp
from log4erp import *

try:

        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        appsid = argv[4]
        drive = argv[5]     #kernel path
        location = argv[6].rstrip()     #script loc
        folder_path = argv[7]

################################################ SPACE CHECK IN REMOTE SERVER ################################


        command='c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"cd ' + drive + ' \" '
        #print command
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        if 'The system cannot find the path specified.' in out:
                print "WRPCHECK_SPACE:F:Kernel Path does not exist ( " + drive + " ) :" + hostname + "_" + appsid.upper()
                exit()
	
        command='c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"WMIC LOGICALDISK GET Name,Size,FreeSpace | find /i \\"' + drive[:1] + '\\"\"'
        #print command
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        out=out.split('\n')
        #print out
        for line in out:
                if re.search(drive[:1],line):
                        match=line.split()
                        
                        
        freespace=match[0]
        available_space=float(freespace)/(1024*1024)

        #write(logfile1, available_space)

################################################ SPACE CHECK IN SOLMAN SERVER ################################
	
        if str(os.path.exists(folder_path.strip())) == "True":
                out = glob.glob(folder_path + "*")
                if out != []:
                        kernel_size = " dir /S " + folder_path
                        #print kernel_size
                        command = subprocess.Popen(kernel_size, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()

                        out = ((str(out)).strip()).split('\n')
                        out = (str(out[-2]).strip()).split(' ')
                        out = str(out[-2]).replace(',','')


                        total_size = int(out)/( 1024 * 1024 )
                        #print available_space
		                #print total_size

################################### COMPARING THE SPACE ###########################################
		    
                        if float(available_space) < float(total_size):
                                print "WRPCHECK_SPACE:F: There is not enough space present on the Target server for Kernel Upgrage HOSTNAME - : " + hostname + "_" + appsid.upper()
                                exit()
                        else:
                                print "WRPCHECK_SPACE:P: There is enough space present on the target Server for the Kernel Upgrade HOSTNAME - : " + hostname + "_" + appsid.upper()
                else:
                        print "WRPCHECK_SPACE:F:No file present in " + folder_path+": "+ hostname + "_" + appsid.upper()
        else:
                print "WRPCHECK_SPACE:F:Folder Path " + folder_path + " does not exist: "+ hostname + "_" + appsid.upper()

except Exception as e:
        if str(e).strip() == "list index out of range":
                print "WRPCHECK_SPACE:F: GERR_0202:Argument/s missing for the script: "+ hostname + "_" + appsid.upper()
        else:
                print "WRPCHECK_SPACE:F: " + str(e)+" :"+ hostname + "_" + appsid.upper()
