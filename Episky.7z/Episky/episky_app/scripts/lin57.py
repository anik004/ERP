from paramiko import *
import paramiko
import sys
from sys import *
import os
import subprocess
from subprocess import *
from os import *
import log4erp
from log4erp import *
import time

try:
	if argv[1] == "--u":
		print "usage: python extract_kernel.py <target hostname> <target username> <target password> <target app SID> <target db sid> <Filename initial> <App/Db> <kernel_id>"
	else:
		#user=argv[4] + "adm"
		target_host=argv[1]
		target_user = argv[2]
		target_passwd = argv[3]
		t_app_sid = argv[4]
		t_db_sid = argv[5]
		file_init = argv[6]
		string = argv[7]
		logfile = argv[8]
		log = argv[9]
		kr = argv[10]
		re_execute = argv[11]
	
		client = SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect( target_host,username = target_user,password = target_passwd)
                channel = client.invoke_shell()

		if string.lower() == "ai" or string.lower() == "ci":
			user = t_app_sid.lower() + "adm"
			command = "sudo su - " + user +" -c \" ls \" "
			print command
			write(logfile,command)
	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
			print out
			write(logfile,str(out))
        	        status = stdout.channel.recv_exit_status()
                	if status != 0:
                        	print "WRPExtract_files:F: Provided input for the app SID ( " + t_app_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        	log4erp.write(log,"WRPExtract_files:F: Provided input for the app SID ( " + t_app_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)
                        	exit()

		elif string.lower() == "db":
			user = "ora" + t_db_sid.lower()
			command = "ls /oracle/" + t_db_sid.upper() + " grep -v \"MAIL\"  >&1 /dev/null"
			log4erp.write(logfile,command)
	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
                        write(logfile,out)
        	        status = stdout.channel.recv_exit_status()

                	if status != 0:
                        	print "WRPExtract_files:F: Provided input for the database SID ( " + t_db_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        	log4erp.write(log,"WRPExtract_files:F: Provided input for the database SID ( " + t_db_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)
				exit()

	

		kernel_path= "sudo su - " + user  + " -c \" which disp+work | sed 's/\/disp+work//'\" | grep -v \"MAIL\""
		write(logfile,kernel_path)
	        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        	kernel_path=stdout.readlines()
		write(logfile,str(kernel_path))
	        kernel_path=kernel_path[0]
        	kernel_path=kernel_path.strip()
		print kernel_path
		

		kernel_files_indi="sudo su - " + user  + " -c \" ls " + kernel_path.strip() + " \" | grep -i \"" + file_init + "_DBI\" | grep -v \"MAIL\""
		print kernel_files_indi
		write(logfile,kernel_files_indi)
#        	print kernel_files_indi
		stdin, stdout, stderr = client.exec_command(kernel_files_indi, timeout=1000, get_pty=True)
		kernel_files_indi=stdout.readlines()
		write(logfile,str(kernel_files_indi))
		print stdout.channel.recv_exit_status()
		if stdout.channel.recv_exit_status() == 0:
			kernel_files_indi = kernel_files_indi[0]
			kernel_files_indi = kernel_files_indi.strip()
#			print kernel_files_indi

       		kernel_files_di="sudo su - " + user  + " -c \" ls " + kernel_path + " \" | grep -i \"" + file_init + "_DBD\" | grep -v \"MAIL\" "
		print kernel_files_di
	        log4erp.write(logfile,kernel_files_di)
		stdin, stdout, stderr = client.exec_command(kernel_files_di, timeout=1000, get_pty=True)
	        kernel_files_di=stdout.readlines()
		log4erp.write(logfile,str(kernel_files_di))
		if stdout.channel.recv_exit_status() == 0:
			kernel_files_di=kernel_files_di[0]
			kernel_files_di=kernel_files_di.strip()
#			print kernel_files_di

        	#kernel_files_opt="sudo su - " + user  + " -c \" ls " + kernel_path + " \"| grep -i \"" + file_init + "_OPT\" | grep -v \"MAIL\""
	        #log4erp.write(logfile,kernel_files_opt)
		#print kernel_files_opt
		#stdin, stdout, stderr = client.exec_command(kernel_files_opt, timeout=1000, get_pty=True)
	        #kernel_files_opt=stdout.readline()
		#log4erp.write(logfile,str(kernel_files_opt))
		#print stdout.channel.recv_exit_status()
		#if stdout.channel.recv_exit_status() == 0:
		#	kernel_files_opt=kernel_files_opt[0]
		#	kernel_files_opt=kernel_files_opt.strip()
#			print kernel_files_opt		

	        kernel_files = []
        	kernel_files = [kernel_files_indi] + [kernel_files_di]# + [kernel_files_opt]
		kernel_path_bkp = kernel_path+'_bkp_'+ kr
		log4erp.write(logfile,kernel_path_bkp)
		flag = 1


		kew_path_new = "sudo su - " + user + " -c \" cd " + kernel_path +" ; pwd\""
		print kew_path_new
		log4erp.write(logfile,kew_path_new)
		stdin, stdout, stderr = client.exec_command(kew_path_new, timeout=1000, get_pty=True)
		out = stdout.readlines()
		log4erp.write(logfile,str(out))
		print out
		for kernel_file in kernel_files:
			print "kernel file111111111111"
			if kernel_file != []:
				print "HI"
				#command = "sudo /usr/sbin/slibclean; genld -l; sudo su - " + user  + " -c \"" + kernel_path_bkp + "/SAPCAR -xvf " + out[0].strip() + "/" + kernel_file + " -R " + out[0].strip() + "\"" 
				command = "sudo su - " + user  + " -c \"" + kernel_path_bkp + "/SAPCAR -xvf " + out[0].strip() + "/" + kernel_file + " -R " + out[0].strip() + "1\"" 
				print command
				log4erp.write(logfile,command)
				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
				st = stdout.readlines()
#				print st
				write(logfile,str(st))
				print stdout.channel.recv_exit_status()
				if "error" in st[-1]:
					flag = flag +1
				elif stdout.channel.recv_exit_status() == 0:
					flag = 1
				else:
					flag = flag +1

		command = 'sudo rm -rf ' + out[0].strip()
		print command
		log4erp.write(logfile,command)
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		status = stdout.channel.recv_exit_status()
		output = stdout.readlines()
		print output

		if status == 0:
			log4erp.write(logfile,str(output))
			command = 'sudo mv ' + out[0].strip() + '1 ' + out[0].strip()
			print command
			log4erp.write(logfile,command)
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			status = stdout.channel.recv_exit_status()
			output = stdout.readlines()
			print output
			if status == 0:
				log4erp.write(logfile,str(output))
				#else:
				#	flag = flag +1
		if flag == 1:
			print "WRPExtract_files:P: The kernel files has been extracted successfully in the target Server :" + target_host + "_" + t_app_sid + "_" + re_execute
			#log4erp.write(log, t_app_sid + ":P: The kernel files has been extracted successfully in the target Server (HOSTNAME - " + target_host + "):" + t_app_sid )
		else:
			print "WRPExtract_files:F: Failed to extract the kernel files successfully in the target server :" + target_host + "_" + t_app_sid + "_" + re_execute
			#log4erp.write(log, t_app_sid + ":F: The kernel is not upgraded in the target server (HOSTNAME - " + target_host + "):" + t_app_sid)
		channel.close()
		client.close()
except Exception as e:
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
	print(exc_type, fname, exc_tb.tb_lineno)
        if str(e) == "[Errno -2] Name or service not known":
                print "WRPExtract_files:F:GERR_0201:Hostname unknown:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Hostname unknown:" + t_app_sid)
        elif str(e).strip() == "list index out of range":
                print "WRPExtract_files:F:GERR_0202:Argument/s missing for the script:" + target_host
        elif str(e) == "Authentication failed.":
                print "WRPExtract_files:F:GERR_0203:Authentication failed.:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Authentication failed.:" + t_app_sid )
        elif str(e) == "[Errno 110] Connection timed out":
                print "WRPExtract_files:F:GERR_0204:Host Unreachable:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Host Unreachable:" + t_app_sid)
        elif "getaddrinfo failed" in str(e):
                print "WRPExtract_files:F:GERR_0205: Please check the hostname that you have provide:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F: Please check the hostname that you have provide:" + t_app_sid)
        elif "[Errno None] Unable to connect to port 22" in str(e):
                print "WRPExtract_files:F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Host Unreachable or Unable to connect to port 22:" + t_app_sid)
        elif "Permission denied" in str(e):
                print "WRPExtract_files:F:GERR_0206:Permission denied for the user" + t_user + ":" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Permission denied for the user" + t_user + ":" + t_app_sid)
	elif "coercing to Unicode: need string or buffer, list found" in str(e):
		print "WRPExtract_files:F:GERR_0207: Application SID / DB SID incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
        else:
                print "WRPExtract_files:F:" + str(e) + ":" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F: " + str(e) + ":" + t_app_sid)
