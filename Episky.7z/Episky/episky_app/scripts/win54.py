#!/usr/bin/c:\\python27\\python.exe
import os
import getpass
import subprocess
import re
from sys import *
import log4erp
from log4erp import *

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    appsid = argv[4]
    location = argv[5].rstrip()     #script location
    drive = argv[6]        # kernel path

#################################### REMOTE DRIVE EXISTENCE CHECK ###########################

    command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "' + drive[:1] + ':"'
    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
    out, err = command.communicate()

    if "The system cannot find the drive specified" in out:
        print "WRPCOPY_FILE_CHECK:F:Kernel Drive does not exist : " + hostname + "_" + appsid.upper()
        exit()
    else:

#################################### REMOTE FOLDER EXISTENCE CHECK ###########################

        command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + drive[:1] + ':\\erp_trans "'
        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        if "True" in out:

#################################### SHARING FOLDER ON REMOTE SERVER(IF FOLDER ALREADY EXIST) ###########################

            command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname +' "net share erp_trans=' + drive[:1] + ':\\erp_trans /grant:everyone,full"'
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()
        else:

#################################### CREATING AND SHARING FOLDER ON REMOTE SERVER (IF FOLDER DOES NOT EXIST) ###########################

            command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname +' "md ' + drive[:1] + ':\\erp_trans && net share erp_trans=' + drive[:1] + ':\\erp_trans /grant:everyone,full"'
            command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
            out, err = command.communicate()


############################# COPYING FILES FROM LOCAL TO REMOTE SERVER ###########################

        if "The name has already been shared" in out or "was shared successfully" in out:
                command = 'echo.> '+location+'\\ctest.txt '
                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                out, err = command.communicate()
                if command.returncode == 0:
                    command = 'net use \\\\' + hostname + '\\erp_trans ' + password + '/user:' + username + ' & copy ' + location + '\ctest.txt \\\\' + hostname + '\\erp_trans /y'
                    #print command
                    command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    #print out
                    if "The specified network password is not correct" in out or "System error 86 has occurred" in out:
                        print "WRPCOPY_FILE_CHECK:F:File is not copied successfully : " + hostname + "_" + appsid.upper()
                    elif '1' in out:
                        print 'WRPCOPY_FILE_CHECK:P:File is copied successfully :' + hostname + "_" + appsid.upper()
                    else:
                        print "WRPCOPY_FILE_CHECK:F:File is not copied successfully : " + hostname + "_" + appsid.upper()


except Exception as e:
    if str(e).strip() == "list index out of range":
        print "WRPcopyfiles_check:F:GERR_0202:Argument/s missing for the script: " + hostname + "_" + appsid.upper()
    else:
        print "WRPcopyfiles_check:F: " + str(e) + ": " + hostname + "_" + appsid.upper()






