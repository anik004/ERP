import paramiko
import ntpath
from sys import *
from paramiko import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *
import os
import sys

try:
    if argv[1] == "--u":
        print "usage: python copy_files.py <target host> <Filename Initial with path> <target sudo user> <target sudo user password> <target_app_sid> <target_db_sid> <App/Db> <kernel_id>"
    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        app_sid = argv[4]
        folder_path = argv[5]
        file_init = argv[6]
        re_execute = argv[7]
        logfile1 = argv[8]
        logfile2 = argv[9]
        user_app = app_sid.lower() + "adm"
        port = 22

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

        kernel_path="sudo su - " + user_app + " -c \"which disp+work | sed 's/\/disp+work//'\" | grep -v \"MAIL\""
        log4erp.write(logfile1,kernel_path)
        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        kernel_path = stdout.readlines()
        log4erp.write(logfile1,str(kernel_path))
        kernel_path=kernel_path[0]
        kernel_path=kernel_path.strip()

        #print folder_path
        dirlist = os.listdir(folder_path)
        sar1 = file_init + "_DBD"
        sar2 = file_init + "_DBI"
        #print sar1
        #print sar2
        for dirs in dirlist:
            #print dirs
            if sar1 in dirs or sar2 in dirs:
                #print dirs
                filepath = str(kernel_path) + "/" + dirs.strip()
                log4erp.write(logfile1,"filepath "+filepath)
                localpath = folder_path + "/" +  dirs.strip()
                log4erp.write(logfile1,"localpath "+localpath)
                #command = "sudo chmod -R 777 " + localpath
                #print command
                #command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                #out, err = command.communicate()
                transport1 = paramiko.Transport((hostname, port))
                transport1.connect(username = username, password = password)
                sftp1 = paramiko.SFTPClient.from_transport(transport1)
                sftp1.put(localpath, filepath)
        flag = 1
        for dirs in dirlist:
            if sar1 in dirs or sar2 in dirs:
                cmd = "sudo ls " + kernel_path + "/" + dirs + "| grep -v \"MAIL\""
                print cmd
                log4erp.write(logfile1,cmd)
                stdin, stdout, stderr = client.exec_command(cmd, timeout=1000, get_pty=True)
                out = stdout.readlines()
                log4erp.write(logfile1,str(out))
                #print stdout.channel.recv_exit_status()
		        #print stdout.readlines()
                if stdout.channel.recv_exit_status() == 0:

                    print "WRPCOPY_FILES:P: The kernel file " + dirs.strip() + " are copied Successfuly  to the target SAP Server :" + hostname + "_" + app_sid + "_" + re_execute
                    log4erp.write(logfile2, app_sid + "WRPCOPY_FILES:P: The kernel file " + dirs.strip() + " are copied Successfuly  to the target SAP Server HOSTNAME - " + hostname + ":" + app_sid)
                else:
                    print "WRPCOPY_FILES:F: Kernel Files have not been copied successfuly to the target server :" + hostname + "_" + app_sid + "_" + re_execute
                    log4erp.write(logfile2, app_sid + "copy_file:F: Kernel Files have not been copied successfuly to the target server" + dirs)
                    exit()

        for dirs in dirlist:
            if sar1 in dirs or sar2 in dirs:
                command="sudo chmod 777 " + kernel_path + "/" + dirs.strip() + ";sudo chown " + user_app + ":sapsys " + kernel_path + "/" + dirs.strip()
                log4erp.write(logfile1,command)
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                log4erp.write(logfile1,str(stdout.readlines()))
                if stdout.channel.recv_exit_status() == 0:
                    flag = 1
                else:
                    flag = flag+1
        if flag ==1:
            print "WRPCOPY_FILES:P:The permission for the file has been changed in the target server :"+ hostname + "_" + app_sid + "_" + re_execute
            #log4erp.write(logfile2, app_sid + ":P:The permission for the file has been changed in the target server : " + hostname + ":" + app_sid)
        else:
            print "WRPCOPY_FILES:F:The permission for the file has not been changed in the targe server HOSTNAME :" + hostname + "_" + app_sid + "_" + re_execute
            log4erp.write(logfile2, app_sid + ":F:The permission for the file has not been changed in the target server HOSTNAME : " + hostname + ":" + app_sid)

        channel.close()
        client.close()

except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print lineno
    if str(e) == "[Errno -2] Name or service not known":
        print "WRPCOPY_FILES:F:GERR_0201:Hostname unknown:" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F::Hostname unknown:" + app_sid)
    elif str(e).strip() == "list index out of range":
        print "WRPCOPY_FILES:F:GERR_0202:Argument/s missing for the script:" + hostname
    elif str(e) == "Authentication failed.":
        print "WRPCOPY_FILES:F:GERR_0203:Authentication failed.:" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F:Authentication failed.:" + app_sid)
    elif str(e) == "[Errno 110] Connection timed out":
        print "WRPCOPY_FILES:F:GERR_0204:Host Unreachable:" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F:Host Unreachable:" + app_sid)
    elif "getaddrinfo failed" in str(e):
        print "WRPCOPY_FILES:F:GERR_0205: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F: Please check the hostname that you have provide:" + app_sid)
    elif "[Errno None] Unable to connect to port 22" in str(e):
        print "WRPCOPY_FILES:F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F:Host Unreachable or Unable to connect to port 22:" + app_sid)
    elif "Permission denied" in str(e):
        print "WRPCOPY_FILES:F:GERR_0206:Permission denied for the user :" + hostname + "_" + app_sid + "_" + re_execute
        log4erp.write(logfile2, app_sid + ":F:Permission denied for the user " + username + ":" + app_sid)
    else:
        print "WRPCOPY_FILES:F: " + str(e) + ":" + hostname + "_" + app_sid
	#		log4erp.write(log, t_app_sid + ":F: " + str(e) + ":" + t_app_sid)
