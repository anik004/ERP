import paramiko
from paramiko import *
import subprocess
from subprocess import *
from sys import *
import log4erp 
from log4erp import *
import re


def sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log):
	
	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

	if sys_type == 'abap':
                command = kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function GetProcessList'
		log4erp.write(logfile,command)
        elif sys_type == 'java':
                command = kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function J2EEGetProcessList'
		log4erp.write(logfile,command)

        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
        out = stdout.readlines()
	log4erp.write(logfile,str(out))


	for i in out:
		if ',' in i:
	                i = (str(i)).split(',')
       	        	if len(i) == 7:
                        	status = i[2].strip()
       		                server = i[1].strip()
               		        if status == 'GREEN':
#      	               		        print server+' is running in the ' + hostname
					res = 'SSS:P:The server ' + hostname + ' is up and running'
					log4erp.write(logfile,res)
	      	                        return res
	                        elif status == 'YELLOW':
       		                        res = 'SSS:F:The server '+ hostname + ' is running with warning'
					log4erp.write(logfile,res)
					return res
                       		elif status == 'GRAY':
                               		res = 'SSS:F:The server ' + hostname + ' is stopped'
					log4erp.write(logfile,res)
					return res
			elif "NIECONN_REFUSED" in i:
				res = 'SSS:F:Instance number is wrong'
				log4erp.write(logfile,res)
		
	channel.close()
	client.close()

def strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log):

        user_sap = app_sid.lower() + "adm"
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

	command = "sudo su - "+user_sap+" -c \"cdpro  ; ls | grep \""+ hostname + "\" \" | grep -v \"ASC\" "
        log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        log4erp.write(logfile,str(stdout))
        out = stdout.readlines()
        for i in out:
		if not '.' in i:
			j =(str(i).split('_'))[1]
                        instance = j[-2:]
			out = sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log)
			log4erp.write(logfile,str(out))
			status = (str(out).split('\n')[len(out.split('\n')) - 2]).split(':')[1]

			if status == "P":
	       			print "SAPSTARTAPP:P: The SAP service is already started on the target server (HOSTNAME - " + hostname + ")"
	       			log4erp.write(log,"SAPSTARTAPP:P: The SAP service is already started on the target server (HOSTNAME - " + hostname + ")")
            
        		else:
				flag = 0
				command = "sudo su - " + user_sap + " -c 'ps -ef | grep -i " + user_sap + " | grep -i /usr/sap | grep -v # | grep -v \"sapstartsrv\"| grep -v \"grep\" | cut -d\" \" -f4'"
				log4erp.write(logfile,command)
			       	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        			all_names = stdout.readlines()
				log4erp.write(logfile,str(all_names))
				if str(all_names).strip() == '[]':
				   flag = 1
				else:
			           for n in range (0, (len(all_names))):
                			proc = all_names[n].strip()
                			command = "sudo su - " + user_sap + ' -c "kill -9 ' + proc + '"'
					print command
					log4erp.write(logfile,command)
                			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
					log4erp.write(logfile,str(stdout))
                			if stdout.channel.recv_exit_status() == 0:
						flag = 1
                    				print "SAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server (HOSTNAME - " + hostname + ")"
                    				log4erp.write(log,"SAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server (HOSTNAME - " + hostname + ")")
					else:
						flag = 0
				if flag == 1:
				
	    				if sys_type == "abap":
                				command = 'sudo su - ' + user_sap + ' -c "startsap r3 '  + hostname+ '"'
	        				log4erp.write(logfile,command)
                				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout))
                				status = stdout.channel.recv_exit_status()
                				if status == 0:
							print "SAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")"
							log4erp.write(log,"SAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
          
						else:
						        print "SAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")"
						        log4erp.write(log,"SAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
 #           write (log, log)
		    			elif sys_type == "java":
						command = 'sudo su - ' + user_sap + ' -c "startsap j2ee '  + hostname+ '"'
						log4erp.write(logfile,command)	        
					        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout))
					        status = stdout.channel.recv_exit_status()
					        if status == 0:
					                 print "SAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")"
					                 log4erp.write(log,"SAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
                    
					        else:
					                  print "SAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")"
					                  log4erp.write(log,"SAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
        channel.close()
        client.close()



try:

	hostname = argv[1]
	username = argv[2]
 	password = argv[3]
	app_sid = argv[4]
	sys_type = argv[5]
	kernel_path = argv[6]
 	logfile = argv[7]
  	log = argv[8]
	ai_ci_db = argv[9]
	db_sid = argv[10]
  	path = argv[11].rstrip('/')
	if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
		strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log)

	elif ai_ci_db.upper() == "DB":
		
		command = os.path.exists( path + "/lin54.py")
                log4erp.write(logfile, str(command))
                out = command
                log4erp.write(logfile,str(out))
		if str(out).strip() == 'True':
			
			command = "python " + path + "/lin54.py " + hostname + " " + username + " " + password + " " + app_sid + " " + db_sid + " " + logfile + " " + log
			write(logfile,command)
                	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	out, err = command.communicate()
            		print out

		else:
			print "SAPSTARTAPP:F:" + path + "/lin54 not found :" + app_sid
	
		
		
except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "SAPSTARTAPP:F:GERR_1301:Hostname unknown"
                log4erp.write(log,'SAPSTARTAPP:F: Hostname unknown [Error Code - 1301]')
     elif str(e) == "list index out of range":
                print "SAPSTARTAPP:F:GERR_1302:Argument/s missing for the script"
     elif str(e) == "Authentication failed.":
                print "SAPSTARTAPP:F:GERR_1303:Authentication failed."
                log4erp.write(log,'SAPSTARTAPP:F:Authentication failed.[Error Code - 1303]')
     elif str(e) == "[Errno 110] Connection timed out":
                print "SAPSTARTAPP:F:GERR_1304:Host Unreachable"
                log4erp.write(log,'SAPSTARTAPP:F:Host Unreachable.[Error Code - 1304]')
     elif "getaddrinfo failed" in str(e):
                print "SAPSTARTAPP:F:GERR_1305: Please check the hostname that you have provide"
                log4erp.write(log,'SAPSTARTAPP:F: Please check the hostname that you have provide [Error Code - 1305]')
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "SAPSTARTAPP:F:GERR_1306:Host Unreachable or Unable to connect to port 22"
                log4erp.write(log,'SAPSTARTAPP:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]')
     elif "invalid decimal" in str(e):
                print "SAPSTARTAPP:F:GERR_1307:Unknown Error:" + str(e)
                log4erp.write(log,'SAPSTARTAPP:F: Unknown Error:' + str(e) + '[Error Code - 1307]')
     else:
                print "SAPSTARTAPP:F: " + str(e)
		log4erp.write(log, "SAPSTARTAPP:F: " + str(e))


