from sys import *
from os import *
from subprocess import *
import os
import subprocess

try:
    if argv[1] == "--u":
        print "python rename_files.py <old file name with full path> <new file name> <script path>"
    else:
                old_file = argv[1]
                new_file = argv[2]
                path = argv[3]      # script path
                out = os.path.isfile(old_file)
                print out
                if str(out) == "True":
                    dirlist = os.path.isdir(path + '\\files')
                    print dirlist
                    if str(dirlist) == "False":
######################################### CREATING TEMPORARY FOLDER FOR THE FILES TO BE COPIED TO NEW LOC #####################
                        print "jj"
                        command = path[:1]+": & md "+path+"\\files"
                        print command
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        out, err = command.communicate()

####################################### COPYING KERNEL FILES TO NEW LOCATION AND RENAMING IT #############################
                    command ="copy " + old_file + " " + path+ '\\files  & rename ' + path+ '\\files\\'+ (old_file.split('\\'))[-1] + " " + new_file #+ '_' + (old_file.split('\\'))[-1]
                    print command
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    out, err = command.communicate()
                    print out
                    print "WRPRENAME_FILES:P:File " + old_file + " has been renamed to " + new_file  #+ '_' + (old_file.split('\\'))[-1]
                else:
                    print "WRPRENAME_FILES:F:File " + old_file + " does not exist"

except Exception as e:
        if "list index out of range" in str(e):
               print "WRPRENAME_FILES:F:GERR_0202:Argument/s missing for the script"
        elif "Permission denied" in str(e):
               print "WRPRENAME_FILES:F:GERR_0206:Permission denied for the user"
        elif "No such file or directory" in str(e):
               print "WRPRENAME_FILES:F:GERR_0204:No such file or directory:"
        else:
               print "WRPRENAME_FILES:F " + str(e)

