import log4erp
from log4erp import *
import os

def ping(t_host,sid,seq_no,logfile):
    osname = os.name
    if osname == "nt":
        command = "ping -n 1 " + str(t_host)  # + " > /dev/null 2>&1"
        write(logfile, command)
        response = os.system(command)

    elif osname == "posix":
        command = "ping -c1 -i3 " + str(t_host) + " > /dev/null 2>&1"
        write(logfile, command)
        response = os.system(command)

    if response == 0:
        #print "PING:P: The connectivity check for Target Server is Successful : " + t_host + "_" + sid + "_" + seq_no
        write(logfile,"WRPPING:P: The connectivity check for Target Server is Successful : " + t_host + "_" + sid + "_" + seq_no)
    else:
        print "WRPPING:F: Please check the IP address. Unable to reach the Host : " + t_host + "_" + sid + "_" + seq_no
        write(logfile,"WRPPING:F: Please check the IP address. Unable to reach the Host : " + t_host + "_" + sid + "_" + seq_no)
        exit()