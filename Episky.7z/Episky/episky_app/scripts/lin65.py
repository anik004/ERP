import paramiko
from paramiko import *
from sys import *
#from log4erp import *

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    profile_path = argv[4]
    dbsid = argv[5]
    seq_no = argv[6]
    db_type = argv[7]   #standalone/multi tenanat
    logfile = argv[8]
    log = argv[9]


    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect( hostname,username = username, password = password)
    channel = client.invoke_shell()

    command = "cd " + profile_path + ";ls"
    #print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()
    #print out

    inst = ""
    for file in out:
        file = file.split()
        for instance in file:
            if dbsid.upper() in instance:
                inst = instance + " " + inst

    instance_no = inst.split()
    #print instance_no

    if len(inst) == 0:
        print "WRPHANASTART:F:could not find the instance no"
    else:
        for ins in instance_no:
            ins = ins.split("_")
            ins = ins[1][-2:]

            command = "/usr/sap/hostctrl/exe/sapcontrol -nr " + ins + " -function GetProcessList "
     #       print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
            #print out

            for i in out:
                i = (str(i)).split(',')
                if len(i) == 7:
                    status = i[2].strip()
      #              print status
                    if 'GREEN' in status:
                        out = 'SSS:P:The server ' + hostname + ' is up and running'
                    elif 'YELLOW' in status:
                        out = 'SSS:F:The server ' + hostname + ' is running with warning'
                        break
                    elif 'GRAY' in status:
                        out = 'SSS:F:The server ' + hostname + ' is stopped '
                        break

            if ":F:" in out:
                command = "/usr/sap/" + dbsid.upper() + "/HDB" + ins + "/HDB start"
       #         print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                out = stdout.readlines()
                #print out
                if "OK" in out[-5] and "OK" in out[-1]:
                    command = "/usr/sap/hostctrl/exe/sapcontrol -nr " + ins + " -function GetProcessList "
        #            print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    out = stdout.readlines()

                    for i in out:
                        i = (str(i)).split(',')
                        if len(i) == 7:
                            status = i[2].strip()
                            #print status
                            if 'GRAY' in status or 'YELLOW' in status:
                                out = 'SSS:F:The server ' + hostname + ' is down'
                                break
                            elif 'GREEN' in status:
                                out = 'SSS:P:The server ' + hostname + ' is up and running '

                    if ":F:" in out:
                        print "WRPHANASTART:F: Failed to start the Database on the target server (" + hostname + ") :" + hostname + "_" + dbsid + "_" + seq_no
                    else:
                        print "WRPHANASTART:P: The Database has been started successfully on the target server (" + hostname + ") :" + hostname + "_" + dbsid + "_" + seq_no

            else:
                print "WRPHANASTART:P: The Database is already started on the target server :" + hostname + "_" + dbsid + "_" + seq_no



except Exception as e:
    print "WRPHANASTART:F: " + str(e)
