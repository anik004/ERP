from django.shortcuts import render
import MySQLdb
import datetime
import subprocess
import threading
from django.http import HttpResponse
from django.core.mail import send_mail


# Create your views here.
class episky:
    def today_time(self):
        global today_times
        now_time = datetime.datetime.now()
        recent_time = now_time.strftime("%H%M%S")
        today_times = now_time.strftime("%d%m%y")
        today_times = today_times + '_' + recent_time
        return today_times

    def crud(self, user, table_name='AZBY', col1='AZBY', insert='AZBY', delete='AZBY'):
        connection = MySQLdb.connect(host="127.0.0.1", user="root", passwd="amigo123", db="episky")
        cursor = connection.cursor()
        epi = episky
        today_time1 = epi.today_time()
        if table_name != 'AZBY' and col1 != 'AZBY':
            cursor.execute(
                """create table %s_%s(%s varchar(100));""" % (table_name, str(today_time1) + '_' + str(user), col1))
        if insert != 'AZBY':
            cursor.execute("""insert into %s_%s values('%s');""" % (table_name, today_time1, insert))
            connection.commit()
        if delete != 'AZBY':
            cursor.execute("""drop table %s;""" % (table_name))
        cursor.close()
        connection.close()

    def get_input_poc(self, request):
        inputs = str(request.POST('appsid')) + '|' + str(request.GET.get('dbsid')) + '|' + str(
            request.GET.get('dbuser')) + '|' + str(request.GET.get('dbpasswd')) + '|' + str(
            request.GET.get('dbtype')) + '|' + str(request.GET.get('os')) + '|' + str(
            request.GET.get('prof_path')) + '|' + str(request.GET.get('scr_loc')) + '|' + str(
            request.GET.get('type')) + '|' + str(request.GET.get('saptype')) + '|' + str(
            request.GET.get('hostname2')) + '|' + str(request.GET.get('ker_path2')) + '|' + str(
            request.GET.get('username2')) + '|' + str(request.GET.get('passwd2')) + '|' + str(
            request.GET.get('new_ker_path2')) + '|' + str(request.GET.get('client')) + '|' + str(
            request.GET.get('sapusername')) + '|' + str(request.GET.get('sappasswd'))
        row_number = str(request.GET.get('row_number'))
        for each in range(3, int(row_number)):
            hostname = str(request.GET.get('hostname' + str(each)))
            username = str(request.GET.get('username' + str(each)))
            passwd = str(request.GET.get('passwd' + str(each)))
            new_ker_path = str(request.GET.get('new_ker_path' + str(each)))
            ker_path = str(request.GET.get('ker_path' + str(each)))
            # inputs = inputs + '|' + hostname + '|' + username + '|' + passwd + '|' + new_ker_path + '|' + ker_path
        return inputs

    def get_input(self, request):
        inputs = str(request.GET.get('appsid')) + '|' + str(request.GET.get('dbsid')) + '|' + str(
            request.GET.get('dbuser')) + '|' + str(request.GET.get('dbpasswd')) + '|' + str(
            request.GET.get('dbtype')) + '|' + str(request.GET.get('os')) + '|' + str(
            request.GET.get('prof_path')) + '|' + str(request.GET.get('scr_loc')) + '|' + str(
            request.GET.get('type')) + '|' + str(request.GET.get('saptype')) + '|' + str(
            request.GET.get('hostname')) + '|' + str(request.GET.get('ker_path')) + '|' + str(
            request.GET.get('username')) + '|' + str(request.GET.get('passwd')) + '|' + str(
            request.GET.get('new_ker_path')) + '|' + str(request.GET.get('client')) + '|' + str(
            request.GET.get('sapusername')) + '|' + str(request.GET.get('sappasswd'))
        return inputs

    def mail(request, body):
        emailto = ['anik.chanda@capgemini.com']
        res = send_mail("Ticket Created", "The ticket has been created", 'erptransformation@capgemini.com', emailto,
                        html_message="<html><Body>Hi,<p>" + body + " </p> <p>Best regards</p><p> ERP Team</p></body></html>")
        if res == 1:
            return HttpResponse('mail has been sent')
        else:
            return HttpResponse('mail has not been sent')


###############################################################################################
###############################################################################################
###############################################################################################
def login(request):
    error_message = ''
    url = request.build_absolute_uri().split(':')[1][2:]
    return render(request, 'login.html', {'error_message': error_message, 'url': url})


def setup(request):
    url = request.build_absolute_uri().split(':')[1][2:]
    return render(request, 'setup.html', {'dbuser': 'anik', 'url': url})


def setup_poc(request):
    url = request.build_absolute_uri().split(':')[1][2:]
    return render(request, 'setup_poc.html', {'dbuser': 'anik', 'url': url})


def check_poc(request):
    epi = episky()
    output = str(epi.get_input(request))
    appsid = output.split('|')[0]
    dbsid = output.split('|')[1]
    dbuser = output.split('|')[2]
    dbpasswd = output.split('|')[3]
    dbtype = output.split('|')[4]
    platform = output.split('|')[5]
    prof_path = output.split('|')[6]
    scr_loc = output.split('|')[7]
    type = output.split('|')[8]
    saptype = output.split('|')[9]
    hostname = output.split('|')[10]
    ker_path = output.split('|')[11]
    username = output.split('|')[12]
    passwd = output.split('|')[13]
    new_ker_path = output.split('|')[14]
    client = output.split('|')[15]
    sapusername = output.split('|')[16]
    sappasswd = output.split('|')[17]
    kid = appsid + '_' + dbsid + '_' + type
    k_id = appsid + '_' + dbsid + '_' + type
    url = request.build_absolute_uri().split(':')[1][2:]
    length = len(output.split('|'))

    def al11(hostname, username, passwd, appsid, dbsid, new_ker_path, scr_loc, platform, kid, k_id, type, prof_path,
             depp, dbtype, saptype, tenant_type, seqno):
        file = open(scr_loc + '\\input.txt', 'a')
        file.write(
            hostname + '|' + username + '|' + passwd + '|' + appsid + '|' + dbsid + '|' + ker_path + '|' + scr_loc + '|' + platform + '|' + kid + '|' + k_id + '|' + saptype + '|' + prof_path + '|' + depp + '|' + dbtype + '|' + type + '|' + tenant_type + '|' + str(
                seqno))
        file.close()

    if length > 18:
        additional = length - 18
        chunks = additional / 5
        index = 19
        for each in range(1, chunks):
            username = output.split('|')[chunks + index]
            hostname = output.split('|')[chunks + index]
            passwd = output.split('|')[chunks + index]
            new_ker_path = output.split('|')[chunks + index]
            ker_path = output.split('|')[chunks + index]
            al11(hostname, username, passwd, appsid, dbsid, new_ker_path, scr_loc, platform, kid, k_id, type, prof_path,
                 'indep', dbtype, saptype, 'none', 1)
            index = index + 5

    def execute(hostname, username, passwd, appsid, dbsid, ker_path, scr_loc, platform, kid, type):
        command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_ker_chk.py ' + hostname + ' ' + username + ' ' + passwd + ' ' + appsid + ' ' + dbsid + ' ' + ker_path + ' ' + scr_loc + ' ' + platform + ' ' + kid + ' ' + type
        output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        out = out.split('\n')
        return out

    request.session['check'] = output

    out = execute(hostname, username, passwd, appsid, dbsid, ker_path, scr_loc, platform, kid, type)
    return render(request, 'check.html',
                  {'appsid': str(length), 'dbsid': str(dbsid), 'dbtype': str(dbtype), 'dbpasswd': str(dbpasswd),
                   'dbuser': str(dbuser), 'type': str(platform), 'url': url, 'output': out})


def check(request):
    epi = episky()
    output = str(epi.get_input(request))
    appsid = output.split('|')[0]
    dbsid = output.split('|')[1]
    dbuser = output.split('|')[2]
    dbpasswd = output.split('|')[3]
    dbtype = output.split('|')[4]
    platform = output.split('|')[5]
    prof_path = output.split('|')[6]
    scr_loc = output.split('|')[7]
    type = output.split('|')[8]
    saptype = output.split('|')[9]
    hostname = output.split('|')[10]
    ker_path = output.split('|')[11]
    username = output.split('|')[12]
    passwd = output.split('|')[13]
    new_ker_path = output.split('|')[14]
    client = output.split('|')[15]
    sapusername = output.split('|')[16]
    sappasswd = output.split('|')[17]
    kid = appsid + '_' + dbsid + '_' + type
    url = request.build_absolute_uri().split(':')[1][2:]

    def execute(hostname, username, passwd, appsid, dbsid, ker_path, scr_loc, platform, kid, type):
        command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_ker_chk.py ' + hostname + ' ' + username + ' ' + passwd + ' ' + appsid + ' ' + dbsid + ' ' + ker_path + ' ' + scr_loc + ' ' + platform + ' ' + kid + ' ' + type
        output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        out = out.split('\n')
        return out

    request.session['check'] = output
    out = execute(hostname, username, passwd, appsid, dbsid, ker_path, scr_loc, platform, kid, type)
    return render(request, 'check.html',
                  {'appsid': str(appsid), 'dbsid': str(dbsid), 'dbtype': str(dbtype), 'dbpasswd': str(dbpasswd),
                   'dbuser': str(dbuser), 'type': str(platform), 'url': url,
                   'output': 'aa:P:' + str(out)})  # + ',a:P:' + str(out)})


def monitor_poc(request):
    output = str(request.session.get('check'))
    appsid = str(output.split('|')[0])
    dbsid = output.split('|')[1]
    dbuser = output.split('|')[2]
    dbpasswd = output.split('|')[3]
    dbtype = output.split('|')[4]
    platform = output.split('|')[5]
    prof_path = output.split('|')[6]
    scr_loc = output.split('|')[7]
    type = output.split('|')[8]
    saptype = output.split('|')[9]
    hostname = output.split('|')[10]
    ker_path = output.split('|')[11]
    username = output.split('|')[12]
    passwd = output.split('|')[13]
    new_ker_path = output.split('|')[14]
    client = output.split('|')[15]
    sapusername = output.split('|')[16]
    sappasswd = output.split('|')[17]
    kid = appsid + '_' + dbsid + '_' + type
    k_id = appsid + '_' + dbsid + '_' + type

    def get_file(new_ker_path, scr_loc):
        command = "python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_checkfolder.py " + new_ker_path + " " + scr_loc
        output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        ker_file = out.split('\r\n')
        for fl in ker_file:
            fl = "\\" + str(fl)
            if "DB" in str(fl):
                command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_rename.py ' + new_ker_path + '\\' + fl + ' ' + kid + '_DBD.SAR' + ' ' + scr_loc
                output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
                out, err = output.communicate()
                # return "a:P:" + fl
            else:
                command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_rename.py ' + new_ker_path + '\\' + fl + ' ' + kid + '_DBI.SAR' + ' ' + scr_loc
                output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
                out, err = output.communicate()
        return "a:P:renaming successfull"

    def execute(al11, new_ker_path, scr_loc, err_code, stepname='kernel_upgrade'):
        command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_final.py ' + al11 + ' ' + new_ker_path + ' ' + scr_loc + ' ' + err_code + ' ' + stepname
        print command
        output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        out = out.split('\n')
        return "a:P:" + command
        # return out

    jj = get_file(new_ker_path, scr_loc)
    out = execute(scr_loc + '\\\input.txt', new_ker_path, scr_loc, hostname + '_' + appsid + '_0')
    return render(request, 'monitor.html',
                  {'appsid': str(appsid), 'dbsid': str(dbsid), 'dbtype': str(dbtype), 'dbpasswd': str(dbpasswd),
                   'dbuser': str(dbuser), 'type': str(platform), 'output': out})


def monitor(request):
    output = str(request.session.get('check'))
    appsid = str(output.split('|')[0])
    dbsid = output.split('|')[1]
    dbuser = output.split('|')[2]
    dbpasswd = output.split('|')[3]
    dbtype = output.split('|')[4]
    platform = output.split('|')[5]
    prof_path = output.split('|')[6]
    scr_loc = output.split('|')[7]
    type = output.split('|')[8]
    saptype = output.split('|')[9]
    hostname = output.split('|')[10]
    ker_path = output.split('|')[11]
    username = output.split('|')[12]
    passwd = output.split('|')[13]
    new_ker_path = output.split('|')[14]
    client = output.split('|')[15]
    sapusername = output.split('|')[16]
    sappasswd = output.split('|')[17]
    kid = appsid + '_' + dbsid + '_' + type
    k_id = appsid + '_' + dbsid + '_' + type

    def al11(hostname, username, passwd, appsid, dbsid, new_ker_path, scr_loc, platform, kid, k_id, type, prof_path,
             depp, dbtype, saptype, tenant_type, seqno):
        file = open(scr_loc + '\\input.txt', 'w+')
        file.write(
            hostname + '|' + username + '|' + passwd + '|' + appsid + '|' + dbsid + '|' + ker_path + '|' + scr_loc + '|' + platform + '|' + kid + '|' + k_id + '|' + saptype + '|' + prof_path + '|' + depp + '|' + dbtype + '|' + type + '|' + tenant_type + '|' + str(
                seqno))
        file.close()

    def get_file(new_ker_path, scr_loc):
        command1 = "python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_checkfolder.py " + new_ker_path + " " + scr_loc
        output = subprocess.Popen(command1, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        ker_file = out.split('\r\n')
        for fl in ker_file:
            fl = "\\" + str(fl)
            if "DB" in str(fl):
                command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_rename.py ' + new_ker_path + '\\' + fl + ' ' + kid + '_DBD.SAR' + ' ' + scr_loc
                output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
                out, err = output.communicate()
                # return "a:P:" + command
            else:
                command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_rename.py ' + new_ker_path + '\\' + fl + ' ' + kid + '_DBI.SAR' + ' ' + scr_loc
                output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
                out, err = output.communicate()

                # return "a:P:" + command
        return "a:P:renaming successfull"
        # return 'a:P:' + str(ker_file)

    def execute(al11, new_ker_path, scr_loc, err_code, stepname='kernel_upgrade'):
        command = 'python D:\\\Anik\\\ERP\\\Scripts\\\Python\\\Django\\\Episky\\\episky_app\\\scripts\\\wrp_final.py ' + al11 + ' ' + new_ker_path + ' ' + scr_loc + ' ' + err_code + ' ' + stepname
        output = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE)
        out, err = output.communicate()
        out = out.split('\n')
        return str(out)

    al11(hostname, username, passwd, appsid, dbsid, new_ker_path, scr_loc, platform, kid, k_id, type, prof_path,
         'indep', dbtype, saptype, 'none', 1)
    jj = get_file(new_ker_path, scr_loc)
    out = execute(scr_loc + '\\\input.txt', new_ker_path, scr_loc, hostname + '_' + appsid + '_0')
    return render(request, 'monitor.html',
                  {'appsid': str(appsid), 'dbsid': str(dbsid), 'dbtype': str(dbtype), 'dbpasswd': str(dbpasswd),
                   'dbuser': str(dbuser), 'type': str(platform), 'output': 'a:P:' + out})


def test(request):
    def test1(request):
        message = ['a:1', 'b:2', 'c:3']
        return render(request, 'test.html', {'message': message})

    def test2(request):
        message = "anik"
        return render(request, 'test.html', {'message': message})

    def test3(request):
        message = 'last'
        return render(request, 'test.html', {'message': message})

    epi = episky()
    epi.mail('test')
    message = 'test'
    return render(request, 'test.html', {'message': message})
