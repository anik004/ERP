"""episky_pro URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.conf.urls import *
from django.contrib import admin
import episky_app
from episky_app.views import *

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^login/', episky_app.views.login, name = 'login'),
    url(r'^setup', episky_app.views.setup, name = 'setup'),
    url(r'^poc', episky_app.views.setup_poc, name = 'setup_poc'),
    url(r'^monitor', episky_app.views.monitor, name = 'monitor'),
    url(r'^check', episky_app.views.check, name = 'test'),
    url(r'^test', episky_app.views.test, name = 'test'),
    url(r'^pcheck', episky_app.views.check_poc, name = 'test'),
]
