#!/bin/bash

##################################################################################################################################################
## Purpose : This script will collect the OS load,Memory,I/O activity,filesystem usage,SAP process table, Database connectivityand activity.
## Author : Jesna Jose
## Version : 1.0
##################################################################################################################################################

####################################### Script Variables ############################################################

DATE=`date '+%Y_%m_%d_%H_%M_%S'`
PWD=`pwd`
LOCATION=${PWD}"/Server_diagnostic_"${DATE}

echo -n  "Enter the DBSID : "
read DBSID

OSNAME1=`uname`

OSNAME=`echo $OSNAME1 | tr '[:lower:]' '[:upper:]'`
DSID=`echo $DBSID | tr '[:upper:]' '[:lower:]'`
DBSID=`echo $DBSID | tr '[:lower:]' '[:upper:]'`


mkdir ${LOCATION} ; chmod -R 777  ${LOCATION}

echo ""
echo "****************************************************************************************"
echo "Running server Diagnostic script...."


################################### TOP COMMAND ###################################################################


echo " " >> ${LOCATION}"/TOP_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log" 
echo "#################################################################################" >> ${LOCATION}"/TOP_output.log" 
echo "			TOP command		" >> ${LOCATION}"/TOP_output.log"
echo "#################################################################################" >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo " " >> ${LOCATION}"/TOP_output.log"
echo "****************************************************************************************"
echo ""
echo "Executing Top command...."
top -b -n 1 >> ${LOCATION}"/TOP_output.log"
echo "Writing the top command output into the file "${LOCATION}"/TOP_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >>  ${LOCATION}"/TOP_output.log"


##################################### VMSTAT COMMAND #################################################################



echo " " >> ${LOCATION}"/VMstat_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/VMstat_output.log"
echo "			VMSTAT COMMAND		" >> ${LOCATION}"/VMstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo " " >> ${LOCATION}"/VMstat_output.log"
echo ""
echo "Executing Vmstat command...."
vmstat >> ${LOCATION}"/VMstat_output.log"
echo "Writing the Vmstat command output into the file "${LOCATION}"/VMstat_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/VMstat_output.log"



##################################### IOSTAT ############################################################################


echo " " >> ${LOCATION}"/IOstat_output.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"

echo "#################################################################################" >> ${LOCATION}"/IOstat_output.log"
echo "			IOSTAT COMMAND		" >> ${LOCATION}"/IOstat_output.log"
echo "#################################################################################" >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo " " >> ${LOCATION}"/IOstat_output.log"
echo ""
echo "Executing iostat command...."
iostat >> ${LOCATION}"/IOstat_output.log"
echo "Writing the iostat command output into the file "${LOCATION}"/IOstat_output.log"
echo ""
echo "****************************************************************************************"
echo "*********************************************************************************" >> ${LOCATION}"/IOstat_output.log"


##################################### space check ########################################################################


echo " " >> ${LOCATION}"/File_system_usage.log"
date "+DATE: %Y-%m-%d%nTIME: %H:%M:%S" >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"

echo "#################################################################################" >>  ${LOCATION}"/File_system_usage.log"
echo "                  FILE SYSTEM USAGE            " >>  ${LOCATION}"/File_system_usage.log"
echo "#################################################################################" >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
echo " " >>  ${LOCATION}"/File_system_usage.log"
if [ "${OSNAME}" == AIX ]; then
echo ""
echo "Executing df -gt command...."
df -gt >> ${LOCATION}"/File_system_usage.log"
echo "Writing the df -gt command output into the file "${LOCATION}"/File_system_usage.log"
echo ""
echo "****************************************************************************************"
else
echo ""
echo "Executing df -h command...."
df -h >>  ${LOCATION}"/File_system_usage.log"
echo "Writing the df -h  command output into the file "${LOCATION}"/File_system_usage.log"
echo ""
echo "****************************************************************************************"
fi
echo "****************************************************************************************" >>  ${LOCATION}"/File_system_usage.log"

#####################################  DATABASE ACTIVITIES  #############################################

#mkdir ${PWD}"/backup_files_"${DATE};chmod 777 ${PWD}"/backup_files_"${DATE}
echo ""
echo "Logging in as  ora"${DSID}
echo "Executing SQLs for the collecton of database activities...." 
sudo su - ora"${DSID}" -c 'echo exit | sqlplus / as sysdba @/oracle/'${DBSID}'/SQL_script.sql'
DBLOC=`sudo su - ora"${DSID}" -c "pwd"`
#echo ${DBLOC}
echo "Writing the SQLs output in the file "
echo ""
echo "****************************************************************************************"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/active_sessions.log ; mv '${DBLOC}'/active_sessions.log '${LOCATION}'/active_sessions.log"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/top5_cpu_statements.log ; mv '${DBLOC}'/top5_cpu_statements.log '${LOCATION}'/top5_cpu_statements.log"
sudo su - ora"${DSID}" -c "chmod 777 '${DBLOC}'/top5_locked_objects.log ; mv '${DBLOC}'/top5_locked_objects.log '${LOCATION}'/top5_locked_objects.log"

##################################### BACKUP OF ALERT.LOG #################################################


echo ""
echo "Executing backup of alert log...."

FILELIST1=`sudo su - ora"${DSID}" -c "ls /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log | grep alert_'${DBSID}'.log"`
echo "Fetching the alert log from /oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace location"

if [ -z ${FILELIST1} ]; then

echo "Unable to find the file /oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace/alert_"${DBSID}".log"

else

echo "Copying the alert log to "${LOCATION}" location " 
#sudo su - ora"${DSID}" -c "cp -rf /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log '${PWD}'/backup_files_'${DATE}'/alert_'${DBSID}'.log ; chmod 777 '${PWD}'/backup_files_'${DATE}'/alert_'${DBSID}'.log"
sudo su - ora"${DSID}" -c "cat /oracle/'${DBSID}'/saptrace/diag/rdbms/'${DSID}'/'${DBSID}'/trace/alert_'${DBSID}'.log | tail -1000 >> '${LOCATION}'/alert_'${DBSID}'.log"

FILELIST2=`ls "${LOCATION}"/alert_"${DBSID}".log | grep alert_"${DBSID}".log`

if [ -z ${FILELIST2} ]; then

echo "Unable to copy the file oracle/"${DBSID}"/saptrace/diag/rdbms/"${DSID}"/"${DBSID}"/trace/alert_"${DBSID}".log to "${LOCATION}"/alert_"${DBSID}".log"

else

echo "Backup of the file alert.log is completed"

fi

fi
echo ""
echo "****************************************************************************************"


########################################################################################################################

