################################################################
#  Script Name: win66.py
#  Author: Satyaki Chatterjee
#  Description: This is the Wrapper for systemchecks( Calls win59,win50,win53,win54 scripts)
################################################################

from __future__ import division
from sys import *
import subprocess
from threading import Thread
import time
import log4erp
from log4erp import *

def check(t_host, t_user, t_passwd, t_appsid, t_kernelpath, t_scriptloc, folder_path, logfile):
    try:
        path = t_scriptloc.rstrip('\\')
        command = "c:\\python27\\python.exe " + path + "\win59 " + t_host + " " + t_appsid
        write(logfile, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
	write(logfile,out)
        status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]

        if status == 'P':
            command = "c:\\python27\\python.exe " + path + "\win50 " + t_host + " " + t_user + " " + t_passwd + " " + t_appsid + " " + t_scriptloc
            write(logfile, command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print out
	    write(logfile,out)
            status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]

            if status == 'P':
                command = "c:\\python27\\python.exe " + path + "\win53 " + t_host + " " + t_user + " " + t_passwd + " " + t_appsid + " " + t_kernelpath+ " " + t_scriptloc+ " "+ folder_path
                write(logfile, command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out
		write(logfile,out)
                status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]

                if status == 'P':
                    command = "c:\\python27\\python.exe " + path + "\win54 " + t_host + " " + t_user + " " + t_passwd + " " + t_appsid + " " + t_scriptloc + " " + t_kernelpath
                    write(logfile, command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    print out
		    write(logfile,out)
                    status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
                    if status == 'P':
                        print "WRPCHECK_KERNEL:P:Check module for target server has been completed Successfully : " + t_host + "_" + t_appsid

    except Exception as e:
        print "WRPCHECK_KERNEL:F: " + str(e) + ": " + t_host + "_" + t_appsid


try:
    if argv[1] == "--u":
        print "usage: python check_ker.py <Target ci Host> <Target ci username> <target ci sudo user passwd> <target ci sid> <string1> <Target ci drive> <Target db Host> <Target db username> <target db sudo user passwd> <target db sid> <string2> <Target db drive> <Target AI Host> <Target AI username> <target AI sudo user passwd> <target AI sid> <string3> <Target AI drive>"
    else:
        t_host = argv[1]
        t_user = argv[2]
        t_password = argv[3]
        t_app_sid = argv[4]
        t_kernelpath = argv[5]
        t_scriptloc = argv[6]
        folder_path = argv[7]
        logfile = argv[8]


        check(t_host, t_user, t_password, t_app_sid, t_kernelpath, t_scriptloc, folder_path, logfile)


except Exception as e:
    print "WRPCHECK_KERNEL:F:" + str(e) + ":" + t_host + "_" + t_app_sid
