################################################################
#  Script Name: sapindep.py
#  Author: Satyaki Chatterjee 
#  Description: This script stops the SAP system and the DB
################################################################



#!/usr/bin/python
from sys import *
import subprocess
import log4erp
from log4erp import *
import authmodule
from authmodule import *
import pingmodule
from pingmodule import *


def sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1,logfile2):
    try:
        ping(hostname,appsid,seq_no,logfile1)
        #auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1)
        
#################################################### FOLDER EXISTENCE CHECK ON REMOTE SERVER #####################################


        command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + kernel_path + '"'
        print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)

        if "True" in str(out):

        #################   CHECKING PROFILE PATH EXISTENCE ON REMOTE SERVER ###################################

            command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + profile_path + '"'
         #   print command
            write(logfile1,command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            #print out
            write(logfile1,out)

            if "True" in out:
           #     profile_path = profile_path
                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' " dir ' + profile_path + ' | findstr -V START" '
                print command
                write(logfile1,command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out
                write(logfile1, out)
                a = out.split("\n")
                b = "."
                jj = "\\" + hostname
                #print jj
                arr = ""
                a = a[5:]
                for dirs in a:
                    if appsid in dirs:
                        if b in dirs or "sapmnt" in dirs or "Copy" in dirs or "profile" in dirs:
                            c = ""
                        else:
                            c = dirs.split()
                            c = c[-1]
                            arr = arr +" " + c

                arr = arr.split(" ")
                
                arr = filter(None,arr)
                print arr
                print "llll"
                inst = " "
                for p in arr:
                   # print p
                    instance = p.split("_")[1]
                    inst = instance[-2:] + " " +  inst
                
                #print inst

                inst = inst.split(" ")
                inst = filter(None,inst)
    
                print inst
                #exit()

##################################################### SAP STATUS CHECK = RUNNING/STOPPED/INTERMEDIATE ###########################
                for ins in inst:           
                    if sys_type.lower() == 'abap':
                        command = 'c:\\python27\\python.exe '+ scriptloc +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + ins + ' -function GetProcessList' + '\"'
              #          print command
                        write(logfile1,command)
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        write(logfile1,out)
                       # print "-------------------"
                        #print out
                    
                    elif sys_type.lower() == 'java':
                        command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + ins + ' -function J2EEGetProcessList' + '\"'
                        write(logfile1,command)

                

                    if "NIECONN_REFUSED" in out:
                        print "WRPSAPSTOP:F:The instance number " +  instance + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no
                        write(logfile1, "SAPSTOP:F:The instance number " +  instance + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no)
                        exit()
                    else:

                        out = out.split("\n")

                        for i in out:
                            i = (str(i)).split(',')
                            if len(i) == 7:
                                status = i[2].strip()
                                #print status
                                if 'GREEN' in status:
                                    out = 'SSS:F:The server ' + hostname + ' is up and running :' + appsid
                                    break
                                elif 'YELLOW' in status:
                                    out = 'SSS:F:The server '+ hostname + ' is running with warning : ' + appsid
                                    break

                        if ":F:" in out:

        ##################################################### STOPPING SAP ON REMOTE SERVER ##############################################################

                            if sys_type.lower() == "abap":
                                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & stopsap.exe name=' + appsid + ' nr=' + ins + ' SAPDIAHOST=' + hostname + '"'
                                write(logfile1,command)
                            elif sys_type.lower() == "java":
                                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & stopsap.exe j2ee name=' + appsid + ' nr=' + ins + ' SAPDIAHOST=' + hostname + '"'
                                write(logfile1,command)

                            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                            out, err = command.communicate()
                            write(logfile1, out)

                            if "STOPSAP executed succesfully" in out:
                                print 'WRPSAPSTOP:P:The sap system for instance ' + ins + ' has been stopped successfully : ' + hostname + "_" + appsid + "_" + seq_no
                                write (logfile2, 'SAPSTOP:P:The sap system for instance ' + ins + ' has been stopped successfully')
                            else:
                                print 'WRPSAPSTOP:F:Failed to stop the SAP Server : ' + hostname + "_" + appsid + "_" + seq_no
                                write (logfile2, 'SAPSTOP:F:The sap system has not been stopped')
                                exit()
                        else:
                            print 'WRPSAPSTOP:P:The sap system for instance ' + ins + ' is already stopped : ' + hostname + "_" + appsid + "_" + seq_no
                            write (logfile2, 'SAPSTOP:P:The sap system for instance ' + ins + ' is already stopped : ' + hostname + "_" + appsid + "_" + seq_no)

            else:
                print "WRPSAPSTOP:F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no
                write(logfile2, "SAPSTOP:F: The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no)
                exit()       
        else:
            print "WRPSAPSTOP:F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no
            write(logfile2, "SAPSTOP:F: The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no)
            exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPSAPSTOP:F:GERR_1202_Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPSAPSTOP:F:" + str(e)+ ": " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1,"SAPSTOP:F:" + str(e))
            write(logfile2, "SAPSTOP:F:" + str(e))


################################################### STOPPING DB ON REMOTE SERVER ##########################################################

def dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1,logfile2):
    try:
        ping(hostname, appsid, seq_no, logfile1)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1)

        command = "c:\\python27\\python.exe " + scriptloc + "\win65 " + hostname + " " + username + " " + password + " " + appsid + " " + scriptloc + " " + seq_no + " " + logfile1 + " " + logfile2
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)
        print out

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPDBSTOP_WIN:F:GERR_1202_Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPDBSTOP_WIN:F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1, "DBSTOP_WIN:F:" + str(e))
            write(logfile2, "DBSTOP_WIN:F:" + str(e))

def dbstop_HANA(hostname,username,password,appsid,dbsid,profile_path,seq_no,tenant_type,logfile1,logfile2):
    try:
        command = "c:\\python27\\python.exe " + scriptloc + "\hanastop " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + profile_path + " " + seq_no + " " + tenant_type + " " + logfile1 + " " + logfile2
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)
        print out

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPDBSTOP_HANA:F:GERR_1202_Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPDBSTOP_HANA:F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1, "DBSTOP_HANA:F:" + str(e))
            write(logfile2, "DBSTOP_HANA:F:" + str(e))

def dbstop_oracle(hostname,username,password,appsid,scriptloc,seq_no,logfile1,logfile2):
    try:
        ping(hostname, appsid, seq_no, logfile1)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1)

        command = "c:\\python27\\python.exe " + scriptloc + "\win65 " + hostname + " " + username + " " + password + " " + appsid + " " + scriptloc + " " + seq_no + " " + logfile1 + " " + logfile2
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)
        print out

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPDBSTOP_WIN:F:GERR_1202_Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPDBSTOP_WIN:F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1, "DBSTOP_WIN:F:" + str(e))
            write(logfile2, "DBSTOP_WIN:F:" + str(e))



try:
            hostname = argv[1]
            username = argv[2]
            password = argv[3]
            appsid = argv[4].upper()
            dbsid = argv[5].upper()
            kernel_path = argv[6]
            scriptloc = argv[7]
            ker_refid = argv[8]
            sys_type = argv[9]  # ABAP/JAVA
            profile_path = argv[10]
            db_type = argv[11]
            ai_ci_db = argv[12]
            seq_no = argv[13]
            tenant_type = argv[14]
            logfile1 = argv[15]
            logfile2 = argv[16]

            if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
                sapindep(hostname,username,password,appsid,sys_type,profile_path,kernel_path,scriptloc,seq_no,logfile1, logfile2)
            elif ai_ci_db.upper() == "DB":
                if db_type == "MSS":
                    dbstop_MSS(hostname,username,password,appsid,scriptloc,seq_no,logfile1, logfile2)
                elif db_type.upper() == "HDB":
                    dbstop_HANA(hostname,username,password,appsid,dbsid,profile_path,seq_no,tenant_type,logfile1,logfile2)
		elif db_type == "ORA":
		    dbstop_ora(hostname,username,password,appsid,scriptloc,seq_no,logfile1, logfile2)


except Exception as e:
    if str(e) == "list index out of range":
        print "WRPSAPSTOP:F:GERR_1202_Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
    else:
        print "WRPSAPSTOP:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no
        write(logfile1, "SAPSTOP:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no)


