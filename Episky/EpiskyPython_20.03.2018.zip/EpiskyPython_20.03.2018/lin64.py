#########################################################################
#  Script Name: lin64.py
#  Author: Surabh Priya
#  Description: This performs the user existence check on the target server
##########################################################################



import paramiko
from paramiko import *
from sys import *
import log4erp
from log4erp import *

def user_check(host,username,passwd,app_sid,db_sid,string,logfile,log,db_type):
	try:
		if string.lower() == 'ai' or string.lower() == 'ci':
	                user1 = app_sid.lower() + "adm"
		else:
			if db_type.lower() == "ora":
		                user1 = "ora" + db_sid.lower()
			elif db_type.lower() == "hdb":
				print "OS_USER_EXISTENCE:P: The user existance check for the target " + string + " server " + host + " is Passed:"+app_sid
				exit()
				user1 = "hdb" + app_sid.lower() 
			elif db_type.lower() == "db6":
				user1 = "db2" +  app_sid.lower()

            	hostname = host
            	username = username
            	password = passwd
		string = string.upper()

            	client = SSHClient()
            	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            	client.connect( hostname,username = username,password = password)
            	channel = client.invoke_shell()

############################################# USER EXISTENCE CHECK FOR APP SID #########################################
		
		command="echo \'grep -iw ^" + user1 + " /etc/passwd\' | sudo bash"
		log4erp.write(logfile,command)
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		log4erp.write(logfile,str(stdout))
                if stdout.channel.recv_exit_status() == 0:
                	print "OS_USER_EXISTENCE:P: The user existance check for " + user1 + " in the target " + string + " server " + hostname + " is Passed:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:P: The user existance check for " + user1 + " in the target " + string + " server " + hostname + " is Passed:"+app_sid)
            	else:
                	print "OS_USER_EXISTENCE:F: The user existance check for " + user1 + " in the target " + string + " server " + hostname + " is failed:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F: The user existance check for " + user1 + " in the target " + string + " server " + hostname + " is failed:"+app_sid)
############################################  USER EXISTENCE CHECK FOR DB SID  #########################################
		#command="sudo grep -iw ^" + user2 + " /etc/passwd"
#		print command
		#stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		#if stdout.channel.recv_exit_status() == 0:
                #        print "OS_USER_EXISTENCE:P: The user existance check for " + user2 + " in the target " + string + " server " + hostname + " is Passed"
                #else:
                #        print "OS_USER_EXISTENCE:F: The user existance check for " + user2 + " in the target " + string + " server " + hostname + " is failed"

            	channel.close()
            	client.close()

	except Exception as e:
		if str(e) == "[Errno -2] Name or service not known":
                	print "OS_USER_EXISTENCE:F:GERR_0201_Hostname unknown:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0201:Hostname unknown:"+app_sid)
	        elif str(e).strip() == "list index out of range":
        	        print "OS_USER_EXISTENCE:F:GERR_0202_Argument/s missing for the script:"+app_sid
	        elif str(e) == "Authentication failed.":
        	        print "OS_USER_EXISTENCE:F:GERR_0203_Authentication failed.:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0203:Authentication failed.:"+app_sid)
	        elif str(e) == "[Errno 110] Connection timed out":
        	        print "OS_USER_EXISTENCE:F:GERR_0204_Host Unreachable:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0204:Host Unreachable:"+app_sid)
	        elif "getaddrinfo failed" in str(e):
        	        print "OS_USER_EXISTENCE:F:GERR_0205_ Please check the hostname that you have provide:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0205: Please check the hostname that you have provide:"+app_sid)
	        elif "[Errno None] Unable to connect to port 22 on" in str(e):
        	        print "OS_USER_EXISTENCE:F:GERR_0206_Host Unreachable or Unable to connect to port 22:"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0206:Host Unreachable or Unable to connect to port 22:"+app_sid)
	        else:
        	        print "OS_USER_EXISTENCE:F: " + str(e)+":"+app_sid
			log4erp.write(log,"OS_USER_EXISTENCE:F: " + str(e)+":"+app_sid)

##########################################################   SCRIPT START   ##################################################################
try:
        if argv[1] == "--u":
		print "usage: python os_user_existence.py <target Host> <Target sudo User> <Target sudo Password> <Target application/Database SID> <String>" 
	else:
		host = argv[1]
		username = argv[2]
		passwd = argv[3]
		app_sid = argv[4]
		string = argv[5]
		logfile = argv[6]
		log = argv[7]
		db_sid = argv[8]
		db_type = argv[9]
		user_check( host,username,passwd,app_sid,db_sid,string,logfile,log,db_type)

					

except Exception as e:
	if str(e) == "[Errno -2] Name or service not known":
	        print "OS_USER_EXISTENCE:F:GERR_0201_Hostname unknown:"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0201:Hostname unknown:"+app_sid)
        elif str(e).strip() == "list index out of range":
                print "OS_USER_EXISTENCE:F:GERR_0202_Argument/s missing for the script:"+app_sid
        elif str(e) == "Authentication failed.":
                print "OS_USER_EXISTENCE:F:GERR_0203_Authentication failed.:"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0203:Authentication failed.:"+app_sid)
        elif str(e) == "[Errno 110] Connection timed out":
                print "OS_USER_EXISTENCE:F:GERR_0204_Host Unreachable:"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0204:Host Unreachable:"+app_sid)
        elif "getaddrinfo failed" in str(e):
                print "OS_USER_EXISTENCE:F:GERR_0205_ Please check the hostname that you have provide:"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0205: Please check the hostname that you have provide:"+app_sid)
        elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "OS_USER_EXISTENCE:F:GERR_0206_Host Unreachable or Unable to connect to port 22:"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F:GERR_0206:Host Unreachable or Unable to connect to port 22:"+app_sid)
        else:
                print "OS_USER_EXISTENCE:F: " + str(e)+":"+app_sid
		log4erp.write(log,"OS_USER_EXISTENCE:F: " + str(e)+":"+app_sid)
