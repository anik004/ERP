################################################################
#  Script Name: dbstart_sybase.py
#  Author: Jesna Jose
#  Description: This script brings the DB2 database up and running
################################################################
import paramiko
from paramiko import *
from sys import *
from log4erp import *
import time

# target IP - argv[1]
# Login User Name - argv[2]
# Login User Password - argv[3]
# Database SID - argv[4]

try:
#    if argv[1] == "--u":
#        print "python startdb.py <Target Host> <Target Login User Name> <Target Login User Password> <Target Database SID>"
#    if len(argv) < 5:
#        print "SSS:F:  Argument/s missing for the script [Error Code - 1202]"

#    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        db_sid = argv[4]
	logfile1 = argv[5]
	app_sid = argv[6]
	logfile2 = argv[7]
	seqno = argv[8]
	string = argv[9]

        user = db_sid.lower() + "adm"

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

	command = "ls /sybase/" + db_sid.upper() + " >&1 /dev/null"
	write(logfile1,command)
#       print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))

        if status != 0:
            print "SSS:F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
            log = 'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid
            write (logfile2,log)
            exit()

        command = 'sudo su - ' + user + ' -c "startdb"'
	write(logfile1,command)
#	print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#	print stdout
	status = stdout.channel.recv_exit_status()
	stdout = stdout.readlines()
	write(logfile1,time.strftime("%Y-%m-%d %H-%M-%S") + " " + str(stdout))
#	print status

        if status == 0 :
            print "SSS:P: The Database has been started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
	    log = "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The Database has been started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
	    write(logfile2, log)
	    
#            command = 'sudo su - ' + user + ' -c "db2 activate db ' + db_sid.lower() + '"'
 #           stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#	    status = stdout.channel.recv_exit_status()
 #           if status == 0:
  #              print "DBSTART_DB2:P: The Database has been activated on the target server (HOSTNAME - " + hostname + ")"
#	        log = "DBSTART_DB2:P: The Database has been activated on the target server (HOSTNAME - " + hostname + ")"
#	        write(logfile, log)
#	    else:
#		print "DBSTART_DB2:F: The Database has not been successfully activated on the target server (HOSTNAME - " + hostname + ")"
 #               log = "DBSTART_DB2:F: The Database has not been successfully activated on the target server (HOSTNAME - " + hostname + ")"
#                write(logfile, log)
        else:
            print "SSS:F: The Database has not been successfully started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
            log = "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: The Database has not been successfully started on the target server - ( " + hostname + " ) :" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
            write(logfile2, log)
	channel.close()
	client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "SSS::F:GERR_1301_Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "list index out of range":
                print "SSS:F:GERR_1302_Argument/s missing for the script"
#                write(logfile,'SSS:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "SSS:F:GERR_1303_Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif str(e) == "[Errno 110] Connection timed out":
                print "SSS:F:GERR_1304_Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "getaddrinfo failed" in str(e):
                print "SSS:F:GERR_1305_ Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "SSS:F:GERR_1306_Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     elif "invalid decimal" in str(e):
                print "SSS:F:GERR_1307_Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
                write(logfile2,'SSS:' + time.strftime("%Y-%m-%d %H-%M-%S") + ':F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno + ':' + string + ':' + hostname + ':' + app_sid)
     else:
                print "SSS:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid
		write(logfile2,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno + ":" + string + ":" + hostname + ":" + app_sid)

