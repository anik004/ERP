from __future__ import division
from sys import *
import subprocess
import log4erp
from log4erp import *

def ker_check(hostname,username,password,appsid,dbsid,kernel_path,scriptloc,t_osname,k_id,string,folder_name,logfile,db_type):
	try:
		path_exist = os.path.isdir(scriptloc)
		if "False" in str(path_exist):
			print 'WRPCHECK_MOD:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper()
			exit()

		sol_osname = os.name
		if sol_osname.lower() == "nt":
			if t_osname.lower() == "windows" :
				path = scriptloc.rstrip('\\')
				command = "c:\\python27\\python.exe " + path + "\win66 " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + folder_name + " " + logfile
				write(logfile,command)
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				out = out.split('\n')
				output = ''
				for i in out:
					output = output + i.strip() + '\n'
				print "WRP:" + str(output)

	
		elif sol_osname.lower() == "posix":
			if t_osname.lower() == "windows":
				path = scriptloc.rstrip('/')
				command = "python " + path + "/lwin66 " + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + folder_name + " " + logfile
				write(logfile,command)
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				print "WRP:" + str(out)
			elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux":
				path = scriptloc.rstrip('/')
				logfile = scriptloc + "/Check_log.log"
				command = "python " + path + "/lin_chk_wrp " +  hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + k_id + " " + logfile + " " + string + " " + path + " " + db_type + " " + t_osname
				print command
				write(logfile,command)
                                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
			else:

	                        print "WRPCHECK_MOD:F: script not found for OS(" + t_osname.upper() +"):" + hostname + "_" + appsid

		else:
			print "WRPCHECK_MOD:F: script not found for OS(" +sol_osname.upper()+"): " + hostname + "_" + appsid

	except Exception as e:
		if str(e).strip() == "list index out of range":
			print "WRPCHECK_MOD:F:GERR_0202_Argument/s missing for the script :" + hostname + "_" + appsid
		else:
			print "WRPCHECK_MOD:F: " + str(e) + ":" + hostname + "_" + appsid



try:

	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4].upper()
	dbsid = argv[5]
	kernel_path = argv[6]
	scriptloc = argv[7].rstrip('\\')
	t_osname = argv[8].lower()
	k_id = argv[9]
	string = argv[10]
	db_type = argv[11]
	
	folder_name = scriptloc + "\\files"
	logfile = scriptloc + "\Check_log.log"

	ker_check(hostname,username,password,appsid,dbsid,kernel_path,scriptloc,t_osname,k_id,string,folder_name,logfile,db_type)

	
	
except Exception as e:
	 if str(e).strip() == "list index out of range":
                print "WRPCHECK_MOD:F:GERR_0202_Argument/s missing for the script :" + hostname + "_" + appsid
	 else:
		print "WRPCHECK_MOD:F: " + str(e)
