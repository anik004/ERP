import log4erp
from log4erp import *
from sys import *
import subprocess

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	location = argv[5]		#script location
	seq_no = argv[6]
	logfile1 = argv[7]
	logfile2 = argv[8]


###################################### FETCHING SERVICES STARTING WITH SQL #####################################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "echo  shut immediate | sqlplus / as sysdba"'
	write(logfile1, command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	out = (out.strip()).split()

	for each in out:
		if "SQL" in each:
			write(logfile2,"DBSTOP_MSSQL:P: DB has been stopped successfully : " + hostname + "_" + appsid + "_" + seq_no )

except Exception as e:
	if str(e) == "list index out of range":
		print "WRPDBSTOP_MSSQL:F:GERR_1302:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
	else:
		print "WRPDBSTOP_MSSQL:F: " + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no
		write(logfile1, str(e))
