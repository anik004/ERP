from __future__ import division
#from paramiko import *
from sys import *
import os
from os import *
import subprocess
from subprocess import *

def ch(folder_name,script_loc):
	try:
		sol_osname = name
		if sol_osname.lower() == "nt":
			path = script_loc.rstrip('\\')
			command = "c:\\python27\\python.exe " + path + "\win62 " + folder_name
			#print command
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			out, err = command.communicate()
			out = out.split('\n')
			output = ''
			for i in out:
				if i.strip():
					output = output + i.strip() + '\n'
			print  output.strip()


		elif sol_osname.lower() == "posix":
			path = script_loc.rstrip('/')
			path = path + "/lin51"
			#print path
			command = os.path.exists(path)
			#print command
			if str(command).strip() == "True":

				command = "python " + path + " " + folder_name
			#	print command
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				print out
			else:
				print "WRPCHECK_FOLDER: F: path "+ path + "/lin51 does not exist "	

		else:
			print "WRPCHECK_FOLDER: F: script not found"

	except Exception as e:
		if str(e) == "[Errno -2] Name or service not known":
			print "WRPCHECK_FOLDER:F:GERR_0201_Hostname unknown"
		elif str(e).strip() == "list index out of range":
			print "WRPCHECK_FOLDER:F:GERR_0202_Argument/s missing for the script"
		elif str(e) == "Authentication failed.":
			print "WRPCHECK_FOLDER:F:GERR_0203_Authentication failed."
		elif str(e) == "[Errno 110] Connection timed out":
			print "WRPCHECK_FOLDER:F:GERR_0204_Host Unreachable"
		elif "getaddrinfo failed" in str(e):
			print "WRPCHECK_FOLDER:F:GERR_0205_ Please check the hostname that you have provide"
		elif "[Errno None] Unable to connect to port 22" in str(e):
			print "WRPCHECK_FOLDER:F:GERR_0206_Host Unreachable or Unable to connect to port 22"
		else:
			print "WRPCHECK_FOLDER:F: " + str(e)


try:
    folder_name = argv[1]
    script_loc = argv[2]

    check = ch(folder_name, script_loc)
  #  print check
except Exception as e:
    print "WRPCHECK_FOLDER:F: " + str(e)



