import paramiko
from paramiko import *
from sys import *
from log4erp import *
import time

try:
#    if argv[1] == "--u":
#        print "Usage: python sapstart.py <Target database host> <Target database root> <Target database root passwd> <Target Database SID> <Refresh ID>"
    if len(argv) < 5:
        print "DBSTOP_DB2:F:  Argument/s missing for the script [Error Code - 1202]"

    else:
        hostname = argv[1]
        username_db = argv[2]
        password_db = argv[3]
        db_sid = argv[5]
        logfile1 = argv[6]
	app_sid = argv[4]
	logfile2 = argv[7]
	seqno = argv[8]

        user_db = "db2" + db_sid.lower()

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        #client.connect(hostname_db,username = username, password = password)
        #channel = client.invoke_shell()


	client.connect(hostname,username = username_db, password = password_db)
        channel = client.invoke_shell()

        command = "echo \"su - " + user_db + " -c \"\\\"\"db2stop\"\\\" | sudo bash"
	print command
	write(logfile1,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	write(logfile1,str(stdout.readlines()))
        status = stdout.channel.recv_exit_status()

        if status == 0 or status == 1:
            print 'DBSTOP_DB2:P: The Database has been stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
            log = time.strftime("%c") + ' DBSTOP_DB2:P: The Database has been stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
            write (logfile2, log)
            #command = 'su - ' + user_db + ' -c \'lsnrctl stop\''
            #stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            #status = stdout.channel.recv_exit_status()

            #if status == 0 or status == 1:
                #print 'SAPSTOP:P: The listener has been stopped on the target server (HOSTNAME - ' + hostname +')'
                #log = 'DB:P: The listener has been stopped on the target server (HOSTNAME - ' + hostname +')'
                #write(logfile, log)
        else:
            command = "echo \" su - " + user_db + " -c \"\\\"\"db2stop force\"\\\" | sudo bash"
	    write(logfile1,command)
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	    write(logfile1,str(stdout.readlines()))
            status = stdout.channel.recv_exit_status()
	    
	    if status == 0:
	        print 'DBSTOP_DB2:P: The Database has been stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
	        log = time.strftime("%c") + ' DBSTOP_DB2:P: The Database has been stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
                write (logfile2, log)

	    else:
                print 'DBSTOP_DB2:F: The Database is not successfully stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
                log = time.strftime("%c") + ' DBSTOP_DB2:F: The Database is not successfully stopped on the target server :' + hostname + '_' + app_sid + '_' + seqno
                write (logfile2, log)
        channel.close()
        client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "DBSTOP_DB2:F:GERR_1301_Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F: Hostname unknown [Error Code - 1301]:' + hostname + "_" + app_sid + "_" + seqno)
     elif str(e) == "list index out of range":
                print "DBSTOP_DB2:F:GERR_1302_Argument/s missing for the script:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile,'DBSTOP_DB2:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "DBSTOP_DB2:F:GERR_1303_Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F:Authentication failed.[Error Code - 1303]:' + hostname + "_" + app_sid + "_" + seqno)
     elif str(e) == "[Errno 110] Connection timed out":
                print "DBSTOP_DB2:F:GERR_1304_Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F:Host Unreachable.[Error Code - 1304]:' + hostname + "_" + app_sid + "_" + seqno)
     elif "getaddrinfo failed" in str(e):
                print "DBSTOP_DB2:F:GERR_1305_ Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + "_" + app_sid + "_" + seqno)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "DBSTOP_DB2:F:GERR_1306_Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + "_" + app_sid + "_" + seqno)
     elif "invalid decimal" in str(e):
                print "DBSTOP_DB2:F:GERR_1307_Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTOP_DB2:F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + "_" + app_sid + "_" + seqno)
     else:
                print "DBSTOP_DB2:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
		write(logfile2,time.strftime("%c") + " DBSTOP_DB2:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno)
