#!/usr/bin/c:\\python27\\python.exe
import os
import getpass
import subprocess
import re
from sys import *
import log4erp
from log4erp import *

try:

	hostname = argv[1]
	username = argv[2] 
	password = argv[3]
	appsid = argv[4]
	drive = argv[5]		# KERNEL PATH
	location = argv[6].rstrip()		#SCRIPT LOCATION
	folderpath = argv[7]			#SCRIPT PATH + FILES
	k_id = argv[8]
	re_execute = argv[9]
	logfile1 = argv[10]
	logfile2 = argv[11]

	#################################### REMOTE DRIVE EXISTENCE CHECK ###########################

	command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "' + drive[:1] + ':"'
	write(logfile1, command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	if "The system cannot find the drive specified" in out:
		print "WRPcopy_files:F:Kernel Drive does not exist " + hostname + "_" + appsid.upper() + "_" + re_execute
		write(logfile2,"copy_files:F:Kernel Drive does not exist " + hostname + "_" + appsid.upper() + "_" + re_execute)
		exit()
	else:

	#################################### REMOTE FOLDER EXISTENCE CHECK ###########################

		command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + drive[:1] + ':\\erp_trans "'
		write(logfile1, command)
		command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1,out)
		if "True" in out:

	#################################### SHARING FOLDER ON REMOTE SERVER(IF FOLDER ALREADY EXIST) ###########################

			command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "net share erp_trans=' + drive[:1] + ':\\erp_trans /grant:everyone,full"'
			write(logfile1, command)
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			out, err = command.communicate()
			write(logfile1,out)
		else:

	#################################### CREATING AND SHARING FOLDER ON REMOTE SERVER (IF FOLDER DOES NOT EXIST) ###########################

			command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "md ' + drive[:1] + ':\\erp_trans && net share erp_trans=' + drive[:1] + ':\\erp_trans /grant:everyone,full"'
			write(logfile1, command)
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			out, err = command.communicate()
			write(logfile1, out)

		count = 0
		dirlist = os.listdir(folderpath)
		if command.returncode == 0:
                        sar1 = k_id + "_DBD"
                        sar2 = k_id + "_DBI"
			for dirs in dirlist:
				if sar1 in dirs or sar2 in dirs:
					count = count + 1
					command = 'net use \\\\' + hostname + '\\erp_trans ' + password + '/user:' + username + '& copy ' + folderpath + '\\' + dirs.strip() + ' \\\\' + hostname + '\\erp_trans /y'
					print command
					write(logfile1, command)
					command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
					out, err = command.communicate()
					write(logfile1,out)
					if command.returncode == 0:
						print "WRPcopy_files:P: " + dirs + 'is copied : ' + hostname + "_" + appsid.upper() + "_" + re_execute
						write(logfile2,"copy_files:P: " + dirs + 'is copied : ' + hostname + "_" + appsid.upper() + "_" + re_execute)

		if count == 0 :
			print "WRPcopy_files:F: unable to find the New Kernel Files: " + hostname + "_" + appsid.upper() + "_" + re_execute
			write(logfile2, "copy_files:F: unable to find the New Kernel Files: " + hostname + "_" + appsid.upper() + "_" + re_execute)
			exit()


except Exception as e:
	if str(e).strip() == "list index out of range":
		print "WRPcopy_files:F:GERR_0202:Argument/s missing for the script:"+ hostname + "_" + appsid.upper() + "_" + re_execute
	else:
		print "WRPcopy_files:F: " + str(e)+":"+ hostname + "_" + appsid.upper() + "_" + re_execute
		write(logfile1, "copy_files:F: " + str(e)+":"+ hostname + "_" + appsid.upper() + "_" + re_execute)
