import paramiko
import glob
from sys import *
from paramiko import *
import log4erp
import time
import subprocess
from subprocess import *
try:
    if argv[1] == "--u":
        print "usage: python backup_kernel.py <target hostname> <target sudo user> <target sudo user password> <target app sid> <target db sid> <App/Db> <kernel_id>"
    else:
		
        t_host = argv[1]
        t_user = argv[2]
        t_pass = argv[3]
	t_app_sid = argv[4].lower()
	t_db_sid = argv[5].lower()
	string = argv[6].lower()
	#date = (time.strftime("%d-%m-%Y_%H-%M"))
	logfile = argv[7] 
	log = argv[8]
	kr = argv[9]
	re_execute = argv[10]

	if string.lower() == "ai" or string.lower() == "ci":
        	user_app = t_app_sid + "adm"
		client = SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect( t_host,username = t_user, password = t_pass)
                channel = client.invoke_shell()
		command =  "echo \"su - " + user_app +" -c \"\" ls \" | sudo bash"

		#print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		out = stdout.readlines()
		a = "su: user " +user_app + " does not exist"
                if a in str(out):
			print "WRPBACKUP_KERNEL:F: Provided input for the app SID ( " + t_app_sid + " ) incorrect:" + t_host + "_" + t_app_sid + "_" + re_execute
                        log4erp.write(log,"WRPBACKUP_KERNEL:F: Provided input for the app SID ( " + t_app_sid + " ) in " + t_host + " host is incorrect")
                        exit()



	elif string.lower() == "db":
		user_app = "ora" + t_db_sid
		
	        client = SSHClient()
        	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
     	 	client.connect( t_host,username = t_user, password = t_pass)
       		channel = client.invoke_shell()
       		command = "ls /oracle/" + t_db_sid.upper() + " >&1 /dev/null"
        	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        	status = stdout.channel.recv_exit_status()
        	if status != 0:
            		print "WRPBACKUP_KERNEL:F: Provided input for the database SID ( " + t_db_sid + " ) is incorrect:" + t_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log,"WRPBACKUP_KERNEL:F: Provided input for the database SID ( " + t_db_sid + " ) in " + t_host + " host is incorrect:" + t_app_sid)
            		exit()
	else:
		print "WRPBACKUP_KERNEL:F:Incorrect string(" + string.upper()+ "). Enter AI/CI for application or DB for database :" + t_host + "_" + t_app_sid + "_" + re_execute
		exit()


################################## FETCHING KERNEL PATH ########################################

#        kernel_path= "echo \"su - " + user_app  + " -c \\\"which disp+work\\\" | sed 's/\/disp+work//' | grep -v \\\"MAIL\\\"\" | sudo bash "
	kernel_path = "echo \"su - " + user_app + " -c \"\\\"\" which disp+work\"\\\"\" | sed \'s/\/disp+work//\' | grep -v \"MAIL\"\"|sudo bash "
	print kernel_path
	log4erp.write(logfile,kernel_path)
        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        kernel_path=stdout.readlines()
	log4erp.write(logfile,str(kernel_path))
	kernel_path=kernel_path[0]
	kernel_path=kernel_path.strip()
	#kernel_path = "/sapmnt/" + t_app_sid.upper() + "/exe"
	log4erp.write(logfile,str(kernel_path))
	bkp = kernel_path+'_bkp_'+ str(kr)
	log4erp.write(logfile,str(bkp))

	if stdout.channel.recv_exit_status() == 0:
		command = "sudo ls " + bkp
		#print command
		log4erp.write(logfile,command)
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		out = stdout.readlines()
		log4erp.write(logfile,str(out))
        	status = stdout.channel.recv_exit_status()
		#print status
		if status == 0:
			print "WRPBACKUP_KERNEL:P:backup already exists : " + t_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log,"WRPBACKUP_KERNEL:P:backup already exists")
			exit()
		else:
			command = "sudo chmod -R 777 " + kernel_path
			#print command
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)

			command="echo \" su - " + user_app + " -c \"\\\" cp -Rf " + kernel_path + "/ " + kernel_path + "_bkp_" + kr + "\\\" | sudo bash "
			print command
            		log4erp.write(logfile,command)

            		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
			print out
			log4erp.write(logfile,str(out))
			status = stdout.channel.recv_exit_status()
			print status
            		if status == 0:
				count_ori="echo \" su - " + user_app + " -c \"\\\"ls " + kernel_path + "\\\"\"/ | wc -l | grep -v \"MAIL\"\"| sudo bash "
				print count_ori
	               		log4erp.write(logfile,count_ori)
                		stdin, stdout, stderr = client.exec_command(count_ori, timeout=1000, get_pty=True)
                		count_ori=stdout.readlines()
				print count_ori
				log4erp.write(logfile,str(count_ori))
                		count_ori=''.join(count_ori).strip()
                		count_ori = int(count_ori)
  #              		print count_ori
                		kernel_path=kernel_path + "_bkp_" + kr
                		count_bkp="echo \" su - " + user_app + " -c \"\\\"ls " + bkp + "\\\"\"/ | wc -l | grep -v \"MAIL\"\"| sudo bash"
				#print count_bkp
	             		log4erp.write(logfile,count_bkp)
            	    		stdin, stdout, stderr = client.exec_command(count_bkp, timeout=1000, get_pty=True)
                		count_bkp=stdout.readlines()
				log4erp.write(logfile,str(count_bkp))
                		count_bkp=''.join(count_bkp).strip()
                		count_bkp = int(count_bkp)
#				print count_bkp
				print "lllllllllllllll"
				ccount_ori = count_ori + 1
				print ccount_ori
				if (count_ori == count_bkp) or (ccount_ori) == count_bkp:
                    			print "WRPBACKUP_KERNEL:P: The kernel backup has been taken successfully on the target " + string + " server :" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
					log4erp.write(log, t_app_sid + ":P: The kernel backup has been taken successfully on the target server HOSTNAME - " + argv[1] + ":" + t_app_sid)
				#	command = "sudo su - " + user_app + " -c \"rm " + kernel_path + "_bkp_" + kr + "/ker_file.txt \" "
				#	print command
				#	log4erp.write(logfile,command)
				#	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
					
                		else:
                    			print "WRPBACKUP_KERNEL:F: The kernel backup is failed on the target " + string + " server :" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
					log4erp.write(log, t_app_sid + ":F: The kernel backup is failed on the target server HOSTNAME - " + argv[1] + ":" + t_app_sid)
            		else:
                		print "WRPBACKUP_KERNEL:F: The kernel backup is failed on the target " + string + " server :" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
				log4erp.write(log, t_app_sid + ":F: The kernel backup is failed on the target " + string + " server HOSTNAME - " + argv[1] + ":" + t_app_sid)

        channel.close()
        client.close()
except Exception as e:
	if str(e) == "[Errno -2] Name or service not known":
               print "WRPBACKUP_KERNEL:F:GERR_0201_Hostname unknown:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F:Hostname unknown:" + t_app_sid)
        elif str(e).strip() == "list index out of range":
               print "WRPBACKUP_KERNEL:F:GERR_0202_Argument/s missing for the script:" + t_host
        elif str(e) == "Authentication failed.":
               print "WRPBACKUP_KERNEL:F:GERR_0203_Authentication failed.:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F:Authentication failed.:" + t_app_sid)
        elif str(e) == "[Errno 110] Connection timed out":
               print "WRPBACKUP_KERNEL:F:GERR_0204_Host Unreachable:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log,t_app_sid + ":F:Host Unreachable:" + t_app_sid)
        elif "getaddrinfo failed" in str(e):
               print "WRPBACKUP_KERNEL:F:GERR_0205_ Please check the hostname that you have provide:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F: Please check the hostname that you have provide:" + t_app_sid)
        elif "[Errno None] Unable to connect to port 22" in str(e):
               print "WRPBACKUP_KERNEL:F:GERR_0206_Host Unreachable or Unable to connect to port 22:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F:Host Unreachable or Unable to connect to port 22:" + t_app_sid)
        elif "Permission denied" in str(e):
               print "WRPBACKUP_KERNEL:F:GERR_0206_Permission denied for the user:" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F:Permission denied for the user" + t_user + ":" + t_app_sid)
        else:
               print "WRPBACKUP_KERNEL:F: " + str(e) + ":" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	       log4erp.write(log, t_app_sid + ":F:" + str(e) + ":" + t_app_sid)
