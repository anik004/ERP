import paramiko
from paramiko import *
from sys import *
import log4erp
from log4erp import *
import os
from os import *

	                       	 
# ----------------- Execution Function ---------------------
def execution(hostname,username,password,appsid,db_sid,logfile,logf, seq_no):
	        user = "ora" + db_sid.lower()
		user_app = appsid.lower() + "adm" 
	
	        client = SSHClient()
	        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	        client.connect(hostname,username = username, password = password)
	        channel = client.invoke_shell()
	
		command = "ls /oracle/" + db_sid.upper() + " >&1 /dev/null"
		log4erp.write(logfile,command)
	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        status = stdout.channel.recv_exit_status()

	        if status != 0:
	            print "WRPDBSTART_ORACLE:F: Provided input for the database SID ( " + db_sid + " ) is incorrect :" + hostname + "_" + appsid + "_" + seq_no
	            log4erp.write(logf,'DBSTART_ORACLE:F: Provided input for the database SID ( ' + db_sid + ' ) in '  + hostname + ' host is incorrect')
	            exit()


	        command = 'echo \'su - ' + user + ' -c \"echo \\"startup\\" | sqlplus / as sysdba\"\'|sudo bash'
		print command
		log4erp.write(logfile,command)
	        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		status = stdout.channel.recv_exit_status()
	
	        if status == 0 or status == 1:
	            print "WRPDBSTART_ORACLE:P: The Database has been started on the target server :" + hostname + "_" + appsid + "_" + seq_no
		    log4erp.write(logf,"DBSTART_ORACLE:P: The Database has been started on the target server (HOSTNAME - " + hostname + ")")
	            
	
		    command = 'echo \'su - ' + user + ' -c \"lsnrctl start\"\' | sudo bash'
		    print command
		    log4erp.write(logfile,command)
	            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	            status = stdout.channel.recv_exit_status()
	
	            if status == 0 or status == 1:
	                print 'WRPDBSTART_ORACLE:P: The listener has been started on the target server :' + hostname + "_" + appsid + "_" + seq_no
	                log4erp.write(logf,'DBSTART_ORACLE:P: The listener has been started on the target server (HOSTNAME - ' + hostname +')' )

			command = 'echo \'su - ' + user_app + ' -c \"R3trans -d\"\' | sudo bash'
			print command
			log4erp.write(logfile,command)
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
			if "(0000)." in str(out):
				print "WRPDBSTART_ORACLE:P: R3trans is successful :" + hostname + "_" + appsid + "_" + seq_no
				log4erp.write(logf,"DBSTART_ORACLE:P: R3trans is successful (HOSTNAME - " + hostname +")")

			else:
				print "WRPDBSTART_ORACLE:F:R3trans is not successful :" + hostname + "_" + appsid + "_" + seq_no
				log4erp.write(logf,"DBSTART_ORACLE:F:R3trans is not successful (HOSTNAME - " + hostname +")")
 
		    else:
			print 'WRPDBSTART_ORACLE:F: The listener has not been started on the target server :' + hostname + "_" + appsid + "_" + seq_no
	                log4erp.write(logf,'DBSTART_ORACLE:F: The listener has not been started on the target server (HOSTNAME - ' + hostname +')')
	
	        else:
	            print "WRPDBSTART_ORACLE:F: The database has not been started on the target server :" + hostname + "_" + appsid + "_" + seq_no
	            log4erp.write(logf,'DBSTART_ORACLE:F: The Database has not been started on the target server (HOSTNAME - ' + hostname + ')')
	        channel.close()
	        client.close()

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	db_sid = argv[5]
	logfile = argv[6] 
	logf = argv[7]
	seq_no = argv[8]
	execution(hostname,username,password,appsid,db_sid,logfile,logf,seq_no)

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":                
		print "WRPDBSTART_ORACLE:F:GERR_1301_Hostname unknown: " + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F: Hostname unknown [Error Code - 1301]')
     elif str(e) == "list index out of range":
                print "WRPDBSTART_ORACLE:F:GERR_1302_Argument/s missing for the script"
     elif str(e) == "Authentication failed.":
                print "WRPDBSTART_ORACLE:F:GERR_1303_Authentication failed.:" + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F:Authentication failed.[Error Code - 1303]')
     elif str(e) == "[Errno 110] Connection timed out":
                print "WRPDBSTART_ORACLE:F:GERR_1304_Host Unreachable:" + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F:Host Unreachable.[Error Code - 1304]')
     elif "getaddrinfo failed" in str(e):
                print "WRPDBSTART_ORACLE:F:GERR_1305_ Please check the hostname that you have provide:" + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F: Please check the hostname that you have provide [Error Code - 1305]')
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPDBSTART_ORACLE:F:GERR_1306_Host Unreachable or Unable to connect to port 22 :" + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]')
     elif "invalid decimal" in str(e):
                print "WRPDBSTART_ORACLE:F:GERR_1307_Unknown Error:" + str(e) + ":" + hostname + "_" + appsid + "_" + seq_no
                log4erp.write(logf,'DBSTART_ORACLE:F: Unknown Error:' + str(e) + '[Error Code - 1307]')
     else:
                print "WRPDBSTART_ORACLE:F: " + str(e) + ":" + hostname + "_" + appsid + "_" + seq_no
