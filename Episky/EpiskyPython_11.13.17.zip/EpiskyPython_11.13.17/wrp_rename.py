from __future__ import division
import sys
#from sys import *
import os
from os import *
import subprocess


def rename(old_file, new_file, script_path):
    try:
        path_exist = os.path.isdir(script_path)
	print path_exist
        if "False" in str(path_exist):
            print 'WRPRENAME:F:Script location ( ' + script_path + " ) is incorrect "
            exit()
        sol_osname = name

        if sol_osname.lower() == "nt":
                path = script_path.rstrip('\\')
                command = "c:\\python27\\python.exe " + path + "\win63 " + old_file + " " + new_file + " " + script_path
		print command
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print out

       # elif sol_osname.lower() == "posix":
        #        path = script_path.rstrip('/')
        #        command = "python " + path + "/lwin63 " + old_file + " " + new_file + " " + script_path
        #        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        #        out, err = command.communicate()
        #        print out
	elif sol_osname.lower() == "posix":
		path = script_path.rstrip('/')
		command = "python " + path + "/lin59 " + old_file + " " + new_file + " " + script_path
		print command
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                #print out
		
        else:
            print "WRPRENAME: F: script not found"
    except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
            print "WRPRENAME:F:GERR_0201_Hostname unknown"
        elif str(e).strip() == "list index out of range":
            print "WRPRENAME:F:GERR_0202_Argument/s missing for the script"
        elif str(e) == "Authentication failed.":
            print "WRPRENAME:F:GERR_0203_Authentication failed."
        elif str(e) == "[Errno 110] Connection timed out":
            print "WRPRENAME:F:GERR_0204_Host Unreachable"
        elif "getaddrinfo failed" in str(e):
            print "WRPRENAME:F:GERR_0205_ Please check the hostname that you have provide"
        elif "[Errno None] Unable to connect to port 22" in str(e):
            print "WRPRENAME:F:GERR_0206_Host Unreachable or Unable to connect to port 22"
        else:
            print "WRPRENAME:F: " + str(e)


try:
   
   # old_file = argv[1]
   # new_file = str(argv[2]) + ".SAR"
    script_path = path.dirname(sys.argv[0])
    print script_path 
    renmfl = str(script_path).strip() + "/rename.txt"
    print renmfl
    input_fl = open(str(renmfl),O_RDONLY)

    print input_fl
    input_fi = read(input_fl,1000)
    print input_fi
    old_file = (str(input_fi).strip()).split('|')[0]
    print old_file
    new_file = (str(input_fi).strip()).split('|')[1]
    print new_file
    rename_file = rename(old_file, new_file, script_path)
    print rename_file
    command = "rm -rf " + renmfl
    print command
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    print out


except Exception as e:
    print "WRPRENAME:F: " + str(e)
