#import paramiko
#from paramiko import *
import re
from re import *
import sys
from sys import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *

try:
	if argv[1] == "--u":
		print "usage: python backup_kernel.py <target hostname> <target sudo user> <target sudo user password> <target app sid> <target OS name> <script loc> <kernel path> <kernel id> "

	else:
		hostname = argv[1]
		username = argv[2]
		password = argv[3]
		app_sid = argv[4].lower()
		path = argv[6] #script path
		kernel_path = argv[7]
		k_id = argv[8]
		refresh_id = argv[9]
		logfile2 = argv[10]
		user = app_sid+'adm'


################################### FOLDER EXISTENCE CHECK IN REMOTE SERVER ##################################
		command = 'c:\\python27\\python.exe ' + path + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "powershell.exe;test-path ' + kernel_path + '"'
		write(refresh_id, command)
		command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(refresh_id,out)
		if "True" in out:
			folder = (str(kernel_path).strip()).split('\\')[-1]
			a = (str(kernel_path).strip()).split('\\')[:-1]
			k_path = ""
			for i in a:
				k_path += i + "\\"
				#print k_path
			ker_fold_name = (str(kernel_path).strip()).split('\\')[-1]
		else:
			print "WRPker_rstr:F: Kernel Path - " +  kernel_path + " not found : " + app_sid
			log4erp.write(logfile2, "ker_rstr:F: Kernel Path - " +  kernel_path + " not found : " + app_sid)

		bkp_path = k_path + folder+'_BKP_'+k_id


		command = 'c:\\python27\\python.exe '+ path.rstrip('\\') +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname +' "rename ' + kernel_path  + ' ' + ker_fold_name +'_fail "'
		write(refresh_id, command)
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(refresh_id, out)
		if "The filename, directory name, or volume label syntax is incorrect" in out or "The system cannot find the file specified" in out:
			print "WRPker_rstr:F: File Name is incorrect. Unable to restore the system : " + app_sid
			log4erp.write(logfile2, "ker_rstr:F: File Name is incorrect. Unable to restore the system : " + app_sid)
			exit()
		elif "The process cannot access the file because it is being used by another process" in out:
			print "WRPker_rstr:F: Failed to rename the file.Unable to restore the system : " + app_sid
			log4erp.write(logfile2, "ker_rstr:F: Failed to rename the file.Unable to restore the system : " + app_sid)
			exit()

		command = 'c:\\python27\\python.exe '+ path.rstrip('\\') +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname +' "rename ' + bkp_path  + ' ' + ker_fold_name +' "'
		write(refresh_id, command)
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(refresh_id, out)
		if "The filename, directory name, or volume label syntax is incorrect" in out or "The system cannot find the file specified" in out:
			print "WRPker_rstr:F: File Name is incorrect : " + app_sid
			log4erp.write(logfile2, "ker_rstr:F: File Name is incorrect. Unable to restore the system : " + app_sid)
			exit()
		elif "The process cannot access the file because it is being used by another process" in out:
			print "WRPker_rstr:F: Failed to rename the file.Unable to restore the system : " + app_sid
			log4erp.write(logfile2, "ker_rstr:F: Failed to rename the file.Unable to restore the system : " + app_sid)
			exit()
		else:
			print "WRPker_rstr:P: System Restoration Successfull : " + app_sid
			log4erp.write(logfile2,"ker_rstr:P: System Restoration Successfull : " + app_sid)
		
		
except Exception as e:
	if str(e).strip() == "list index out of range":
		print "ker_rstr:F:GERR_3002:Argument/s missing"
	else:
		print "ker_rstr:F: " + str(e)
		log4erp.write(logfile2,"ker_rstr:F: " + str(e))
