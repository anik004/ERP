from __future__ import division
#from paramiko import *
from sys import *
from os import *
import subprocess
from subprocess import *

def ker(t_host, t_user, t_password, t_app_sid, t_kernelpath, t_sriptloc, t_osname, type_name):
	try:
		sol_osname = name
		if sol_osname.lower() == "nt":
			if t_osname.lower() == "windows" :
				if type_name.upper() == 'DB':
                                        print 'PRE:NA|NA|NA|NA|NA'
                                else:
					path = t_sriptloc.rstrip('\\')
					command = "c:\\python27\\python.exe " + path + "\win56 " + t_host + " " + t_user + " " + t_password + " " + t_app_sid + " " + t_kernelpath + " " + t_sriptloc
					command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
					out, err = command.communicate()
					print "PRE:" + out.strip()
	


		elif sol_osname.lower() == "posix":
			if t_osname.lower() == "windows":
				path = t_sriptloc.rstrip('/')
				command = "python " + path + "/lwin56 " + t_host + " " + t_user + " " + t_password + " " + t_app_sid + " " + t_kernelpath + " " + t_sriptloc
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				print "PRE: " + out.strip()
			elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux" :
				path = t_sriptloc.rstrip('/')
				command = "python " + path + "/lin56 " + t_host + " " + t_user + " " + t_password + " " + t_app_sid + " " + type_name
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print "PRE: " + out.strip()
			else :
				print "WRPdetails_kernel:F:script not found for OS(" + t_osname.upper() + "):" + t_app_sid

		else:
			print "WRPdetails_kernel: F: script not found for os(" + sol_osname.upper() + "):" + t_app_sid

	except Exception as e:
		if str(e).strip() == "list index out of range":
			print "WRPdetails_kernel:F:GERR_0202_Argument/s missing for the script"
		else:
			print "WRPdetails_kernel:F: " + str(e)

try:

	t_host	= argv[1]
	t_user	= argv[2]
	t_password = argv[3]
	t_app_sid = argv[4]
	t_kernelpath = argv[5]
	t_sriptloc = argv[6]
	t_osname = argv[7]
	type_name = argv[8]     #AI/CI/DB
	ker(t_host, t_user, t_password, t_app_sid, t_kernelpath, t_sriptloc, t_osname, type_name)

except Exception as e:
	print "WRPdetails_kernel:F: " + str(e) + ": " + t_host + " " + t_app_sid
