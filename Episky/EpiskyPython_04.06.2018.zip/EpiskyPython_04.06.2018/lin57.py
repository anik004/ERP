###########################################################################################
#  Script Name: lin57.py 
#  Author: Surabhi Priya
#  Description: This scrip performs the extraction of new kernel files in the Target system
############################################################################################

from paramiko import *
import paramiko
import sys
from sys import *
import os
import subprocess
from subprocess import *
from os import *
import log4erp
from log4erp import *
import time

try:
	if argv[1] == "--u":
		print "usage: python extract_kernel.py <target hostname> <target username> <target password> <target app SID> <target db sid> <Filename initial> <App/Db> <kernel_id>"
	else:
		#user=argv[4] + "adm"
		target_host=argv[1]
		target_user = argv[2]
		target_passwd = argv[3]
		t_app_sid = argv[4]
		t_db_sid = argv[5]
		file_init = argv[6]
		string = argv[7]
		logfile = argv[8]
		log = argv[9]
		kr = argv[10]
		re_execute = argv[11]
		icmdb_path = argv[12]
		al11_file_path = argv[13]
	
		client = SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect( target_host,username = target_user,password = target_passwd)
                channel = client.invoke_shell()

		if string.lower() == "ai" or string.lower() == "ci":
			user = t_app_sid.lower() + "adm"
			command = "echo \"su - " + user + " -c \"\" ls \" | sudo bash"

			print command
			write(logfile,command)
	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
			print out
			write(logfile,str(out))
        	        status = stdout.channel.recv_exit_status()
                	if status != 0:
                        	print "WRPExtract_files:F: Provided input for the app SID ( " + t_app_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        	log4erp.write(log,"WRPExtract_files:F: Provided input for the app SID ( " + t_app_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)
                        	exit()

		elif string.lower() == "db":
			user = "ora" + t_db_sid.lower()
			command = "ls /oracle/" + t_db_sid.upper() + " grep -v \"MAIL\"  >&1 /dev/null"
			log4erp.write(logfile,command)
	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
                        write(logfile,out)
        	        status = stdout.channel.recv_exit_status()

                	if status != 0:
                        	print "WRPExtract_files:F: Provided input for the database SID ( " + t_db_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        	log4erp.write(log,"WRPExtract_files:F: Provided input for the database SID ( " + t_db_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)
				exit()

	

		kernel_path  = "echo \"su - " + user + " -c \"\\\"\" which disp+work\"\\\"\" | sed \'s/\/disp+work//\' | grep -v \"MAIL\"\"|sudo bash "

		write(logfile,kernel_path)
	        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
        	kernel_path=stdout.readlines()
		write(logfile,str(kernel_path))
	        kernel_path=kernel_path[0]
        	kernel_path=kernel_path.strip()
		print kernel_path
		

		kernel_files_indi = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_DBI | grep -v \"MAIL\""
		print kernel_files_indi
		write(logfile,kernel_files_indi)
#        	print kernel_files_indi
		stdin, stdout, stderr = client.exec_command(kernel_files_indi, timeout=1000, get_pty=True)
		kernel_files_indi=stdout.readlines()
		write(logfile,str(kernel_files_indi))
		print stdout.channel.recv_exit_status()
		if stdout.channel.recv_exit_status() == 0:
			kernel_files_indi = kernel_files_indi[0]
			kernel_files_indi = kernel_files_indi.strip()
#			print kernel_files_indi

		kernel_files_di = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_DBD | grep -v \"MAIL\""
		print kernel_files_di
	        log4erp.write(logfile,kernel_files_di)
		stdin, stdout, stderr = client.exec_command(kernel_files_di, timeout=1000, get_pty=True)
	        kernel_files_di=stdout.readlines()
		log4erp.write(logfile,str(kernel_files_di))
		if stdout.channel.recv_exit_status() == 0:
			kernel_files_di=kernel_files_di[0]
			kernel_files_di=kernel_files_di.strip()
#			print kernel_files_di

        	#kernel_files_opt="sudo su - " + user  + " -c \" ls " + kernel_path + " \"| grep -i \"" + file_init + "_OPT\" | grep -v \"MAIL\""
	        #log4erp.write(logfile,kernel_files_opt)
		#print kernel_files_opt
		#stdin, stdout, stderr = client.exec_command(kernel_files_opt, timeout=1000, get_pty=True)
	        #kernel_files_opt=stdout.readline()
		#log4erp.write(logfile,str(kernel_files_opt))
		#print stdout.channel.recv_exit_status()
		#if stdout.channel.recv_exit_status() == 0:
		#	kernel_files_opt=kernel_files_opt[0]
		#	kernel_files_opt=kernel_files_opt.strip()
#			print kernel_files_opt		

	        kernel_files = []
        	kernel_files = [kernel_files_indi] + [kernel_files_di]# + [kernel_files_opt]
		kernel_path_bkp = kernel_path+'_bkp_'+ kr
		log4erp.write(logfile,kernel_path_bkp)
		flag = 1

		kernel_files_igs = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_IGSEXE | grep -v \"MAIL\""
                print kernel_files_igs
                log4erp.write(logfile,kernel_files_igs)
                stdin, stdout, stderr = client.exec_command(kernel_files_igs, timeout=1000, get_pty=True)
                kernel_files_igs=stdout.readlines()
                log4erp.write(logfile,str(kernel_files_igs))
                if stdout.channel.recv_exit_status() == 0:
                        kernel_files_igs=kernel_files_igs[0]
                        kernel_files_igs=kernel_files_igs.strip()
#                       print kernel_files_igs
			kernel_files = kernel_files + [kernel_files_igs]


		kernel_files_dw = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_DW | grep -v \"MAIL\""
                print kernel_files_dw
                log4erp.write(logfile,kernel_files_dw)
                stdin, stdout, stderr = client.exec_command(kernel_files_dw, timeout=1000, get_pty=True)
                kernel_files_dw=stdout.readlines()
                log4erp.write(logfile,str(kernel_files_dw))
                if stdout.channel.recv_exit_status() == 0:
                        kernel_files_dw=kernel_files_dw[0]
                        kernel_files_dw=kernel_files_dw.strip()
#                       print kernel_files_dw
                        kernel_files = kernel_files + [kernel_files_dw]

		kernel_files_r3 = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_R3TRANS | grep -v \"MAIL\""
                print kernel_files_r3
                log4erp.write(logfile,kernel_files_r3)
                stdin, stdout, stderr = client.exec_command(kernel_files_r3, timeout=1000, get_pty=True)
                kernel_files_r3=stdout.readlines()
                log4erp.write(logfile,str(kernel_files_r3))
                if stdout.channel.recv_exit_status() == 0:
                        kernel_files_r3=kernel_files_r3[0]
                        kernel_files_r3=kernel_files_r3.strip()
#                       print kernel_files_r3
                        kernel_files = kernel_files + [kernel_files_r3]

		kernel_files_tp = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_TP | grep -v \"MAIL\""
                print kernel_files_tp
                log4erp.write(logfile,kernel_files_tp)
                stdin, stdout, stderr = client.exec_command(kernel_files_tp, timeout=1000, get_pty=True)
                kernel_files_tp=stdout.readlines()
                log4erp.write(logfile,str(kernel_files_tp))
                if stdout.channel.recv_exit_status() == 0:
                        kernel_files_tp=kernel_files_tp[0]
                        kernel_files_tp=kernel_files_tp.strip()
#                       print kernel_files_tp
                        kernel_files = kernel_files + [kernel_files_tp]

		kernel_files_lib = "ls /usr/sap/put/episky_files/ | grep -i " +  file_init + "_LIB | grep -v \"MAIL\""
                print kernel_files_lib
                log4erp.write(logfile,kernel_files_lib)
                stdin, stdout, stderr = client.exec_command(kernel_files_lib, timeout=1000, get_pty=True)
                kernel_files_lib=stdout.readlines()
                log4erp.write(logfile,str(kernel_files_lib))
                if stdout.channel.recv_exit_status() == 0:
                        kernel_files_lib=kernel_files_lib[0]
                        kernel_files_lib=kernel_files_lib.strip()
#                       print kernel_files_lib
                        kernel_files = kernel_files + [kernel_files_lib]
		print kernel_files

		for kernel_file in kernel_files:
			if kernel_file != []:
				#command = "chown -R bwsadm:sapsys /usr/sap/put/episky_files "
                                #print command
                                #log4erp.write(logfile,command)
                                #stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                #print stdout.readlines()

				command = "echo \"su - " + user  + " -c \"\\\"\"" + kernel_path_bkp + "/SAPCAR -xvf /usr/sap/put/episky_files/" + kernel_file + " -R /usr/sap/put/episky_files/ " + "\"\\\"| sudo bash" 
				print command
				log4erp.write(logfile,command)
				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
				st = stdout.readlines()
#				print st
				write(logfile,str(st))
				print stdout.channel.recv_exit_status()
				if "error" in st[-1]:
					flag = flag +1
				elif stdout.channel.recv_exit_status() == 0:
					flag = 1
					command = 'echo "cd /usr/sap/put/episky_files/;sh saproot.sh ' + t_app_sid.upper() + " " + t_app_sid.upper() + '" | sudo bash'
                        		print command
	                	        log4erp.write(logfile,command)
	        	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		                        out = stdout.readlines()
		                        log4erp.write(logfile,str(out))
                		        print out
					command = "echo \'su - " + user + " -c \"cp -rpf /usr/sap/put/episky_files/* " + kernel_path.strip() + "/ \"\'| sudo bash"
					print command
	                                log4erp.write(logfile,command)
	       	                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                	                status = stdout.channel.recv_exit_status()
					output = stdout.readlines()
					print output

################################################################# GIVING PERMISSION TO ICMDB FILE #####################################
				#	if icmdb_path != "BLANK":
					if icmdb_path.lower() == "na" or icmdb_path.lower() == "blank":
                                                print "no softlink"
                                        else:

						icmdb_host = icmdb_path.split(":")[0]
						icmdb_filepath = icmdb_path.split(":")[1]
						f = open(al11_file_path, 'r')
				                content = f.read()
						for line in content.split():
							if icmdb_host.strip() in line and "CI" in line:
								line = line.replace("|", " ")
			                                	line = line.split(" ")
								i_host = line[0]
				                                i_user = line[1]
                	        			        i_passwd = line[2]

						client1 = SSHClient()
			        	        client1.set_missing_host_key_policy(paramiko.AutoAddPolicy())
			                	client1.connect( i_host,username = i_user,password = i_passwd)
				                channel1 = client1.invoke_shell()

						command = "echo 'cp " + icmdb_filepath.strip() + "/icmbnd.new " + icmdb_filepath.strip() + "/icmbnd;chown root:sapsys " + icmdb_filepath.strip() + "/icmbnd;chmod 4750 " + icmdb_filepath.strip() + "/icmbnd'| sudo bash"
						print command
		                                log4erp.write(logfile,command)
                	                        stdin, stdout, stderr = client1.exec_command(command, timeout=1000, get_pty=True)
               	        	                status = stdout.channel1.recv_exit_status()
                       	        	        output = stdout.readlines()
						print output
						log4erp.write(logfile,str(output))
						channel1.close()
						client1.close()
				else:
					flag = flag +1

		if flag == 1:
			print "WRPExtract_files:P: The kernel files has been extracted successfully in the target Server :" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":P: The kernel files has been extracted successfully in the target Server (HOSTNAME - " + target_host + "):" + t_app_sid )
		else:
			print "WRPExtract_files:F: Failed to extract the kernel files successfully in the target server :" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F: The kernel is not upgraded in the target server (HOSTNAME - " + target_host + "):" + t_app_sid)

		channel.close()
		client.close()

except Exception as e:
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
	print(exc_type, fname, exc_tb.tb_lineno)
        if str(e) == "[Errno -2] Name or service not known":
                print "WRPExtract_files:F:GERR_0201_Hostname unknown:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Hostname unknown:" + t_app_sid)
        elif str(e).strip() == "list index out of range":
                print "WRPExtract_files:F:GERR_0202_Argument/s missing for the script:" + target_host + "_" + t_app_sid + "_" + re_execute
        elif str(e) == "Authentication failed.":
                print "WRPExtract_files:F:GERR_0203_Authentication failed.:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Authentication failed.:" + t_app_sid )
        elif str(e) == "[Errno 110] Connection timed out":
                print "WRPExtract_files:F:GERR_0204_Host Unreachable:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Host Unreachable:" + t_app_sid)
        elif "getaddrinfo failed" in str(e):
                print "WRPExtract_files:F:GERR_0205_ Please check the hostname that you have provide:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F: Please check the hostname that you have provide:" + t_app_sid)
        elif "[Errno None] Unable to connect to port 22" in str(e):
                print "WRPExtract_files:F:GERR_0206_Host Unreachable or Unable to connect to port 22:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Host Unreachable or Unable to connect to port 22:" + t_app_sid)
        elif "Permission denied" in str(e):
                print "WRPExtract_files:F:GERR_0206_Permission denied for the user" + t_user + ":" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F:Permission denied for the user" + t_user + ":" + t_app_sid)
	elif "coercing to Unicode: need string or buffer, list found" in str(e):
		print "WRPExtract_files:F:GERR_0207_ Application SID / DB SID incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
        else:
                print "WRPExtract_files:F:" + str(e) + ":" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log, t_app_sid + ":F: " + str(e) + ":" + t_app_sid)
