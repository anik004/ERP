####################################################################################################
#  Script Name: wrp_start_ai_indep.py
#  Author: Jesna Jose
#  Description: This is the Main wrapper for start SAP for independent systems( calls win60 and lin62 )
#####################################################################################################

#!/usr/bin/python
from sys import *
import subprocess
import log4erp
from log4erp import *
import os

def sapstart_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2):
    try:
        if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI" :
            path_exist = os.path.isdir(scriptloc)
            if "False" in str(path_exist):
                print 'WRPSTOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no
                write(logfile1, 'STOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no)
                exit()

            sol_osname = os.name

            if sol_osname.lower() == "nt":
                if t_osname.lower() == "windows" or t_osname.lower() == "suse_linux" :
                    path = scriptloc
                    #print path
                    command = "c:\\python27\\python.exe " + path + "\win60 " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + tenant_type + " " + seq_no + " " + logfile1 + " " + logfile2
                    write(logfile1, command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    if ":F:" in out:
                        print "WRP"+ out
                        exit()
                    else:
                        print "WRP"+ out

            elif sol_osname.lower() == "posix":
                if t_osname.lower() == "windows":
                    path = scriptloc.rstrip('/')
                    command = "c:\\python27\\python.exe " + path + "\lwin60 " + + hostname + " " + username + " " + password + " " + appsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seq_no + " " + logfile1 + " " + logfile2
                    write(logfile1,command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    if ":F:" in out:
                        print "WRP"+ out
                        exit()
                    else:
                        print "WRP"+ out
		elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux": 
			path = scriptloc.rstrip('/')
			logfile1 = scriptloc + "/" + ker_refid + "_log.log"
                	logfile2 = scriptloc + "/" + "EpiskyClient_log.log"
			
			command  = "python " + path + "/lin62 "  + hostname + " " + username + " " + password + " " + appsid + " " + sys_type + " " +kernel_path + " " + logfile1 + " " + logfile2 + " " + ai_ci_db + " " + dbsid + " " + path + " " + seq_no + " " + db_type + " " + profile_path
                        write(logfile1,command)
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
			if ":F:" in out:
                        	print "WRP"+ out
                        	exit()
                    	else:
                        	print "WRP"+ out

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPSAPSTARTINDEP_WRP:F:GERR_1202:Argument/s missing for the script"
        else:
            print "WRPSAPSTARTINDEP_WRP:F: " + str(e)



try:
    file_path = argv[1]
    error_code = argv[2]
    error_code = error_code.split("_")
    seq_no = error_code[2]
    step_name = argv[3]

    if seq_no == "0":
        content = ""
        for cont in reversed(open(file_path).readlines()):
            if "indep" in cont:
                content = content + "|" + cont.rstrip()

        arg_string = content.replace("|", " ")
        arg_string = arg_string.lstrip()
        argv = arg_string.split(" ")
        argv_len = len(argv) - 2

        for index in range(0,argv_len,19):
                hostname = argv[index]
                username = argv[index+1]
                password = argv[index+2]
                appsid = argv[index+3].upper()
		dbsid =  argv[index+4].upper()
                kernel_path = argv[index+5]
                scriptloc = argv[index+6].rstrip('\\')
                t_osname = argv[index+7].lower()
                ker_refid = argv[index+9]
                sys_type = argv[index+10]  # ABAP/JAVA
                profile_path = argv[index+11]
                db_type = argv[index+13]
                ai_ci_db = argv[index+14]
		tenant_type = argv[index+15]
                seqno = argv[index+16]
                logfile1 = scriptloc + "\\" + ker_refid + "_log"
                logfile2 = scriptloc + "\\" + "client_read_log"

                sapstart_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1,logfile2)



    else:
        content = ""
        for cont in reversed(open(file_path).readlines()):
            content = content + "\n" + cont

        for line in content.split("\n"):
            if "indep" in line:
		ln = line.split('|')
                if ln[16] < seq_no or ln[16] == seq_no:
                    arg_string = line.replace("|"," ")
                    arg_string = arg_string.split()
                    hostname = arg_string[0]
                    username = arg_string[1]
                    password = arg_string[2]
                    appsid = arg_string[3].upper()
		    dbsid =  arg_string[4].upper()
                    kernel_path = arg_string[5]
                    scriptloc = arg_string[6].rstrip('\\')
                    t_osname = arg_string[7].lower()
                    ker_refid = arg_string[9]
                    sys_type = arg_string[10]  # ABAP/JAVA
                    profile_path = arg_string[11]
                    db_type = arg_string[13]
                    ai_ci_db = arg_string[14]
		    tenant_type = arg_string[15]
                    seqno = arg_string[16]
                    logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
                    logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"

                    sapstart_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type,profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2)


except Exception as e:
    if str(e) == "list index out of range":
        print "WRPSAPSTARTINDEP_WRP:F:GERR_1202:Argument/s missing for the script"
    else:
        print "WRPSAPSTARTINDEP_WRP:F: " + str(e)
