##############################################################################################################
#  Script Name: wrp_sapstopindep.py
#  Author: Surabhi Priya
#  Description: This is the main wrapper for stop SAP and DB for indepenedent systems (calls sapindep and lin63 )
###############################################################################################################

from sys import *
import subprocess
import log4erp
from log4erp import *
import os

def sapstop_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2, step_name):
    try:
        path_exist = os.path.isdir(scriptloc)
        if "False" in str(path_exist):
            print 'STOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no  + " " + step_name
            write(logfile1, 'STOPSAPINDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + hostname + "_" + appsid.upper() + "_" + seq_no + " " + step_name)
            exit()

        sol_osname = os.name

        if sol_osname.lower() == "nt":
            if t_osname == "windows":
                path = scriptloc
                command = "c:\\python27\\python.exe " + path + "\sapindep " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + str(seq_no) + " " + tenant_type + " " + logfile1 + " " + logfile2
                #print command
                write(logfile1, "command : " + command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                out = out.split('\n')
                output = ''
                for i in out:
                    if i.strip():
                        output = output + i.strip() + '\n'
                if ":F:" in output:
                    print "WRP" + output.strip() + ":" + step_name
                    exit()
                else:
                    print "WRP" + output.strip() + ":" + step_name

            elif t_osname.lower() == "suse_linux":
                path = scriptloc
                command = "c:\\python27\\python.exe " + path + "\sapindep " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + str(seq_no) + " " + tenant_type + " " + logfile1 + " " + logfile2
                #print command
                write(logfile1, "command : " + command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                out = out.split('\n')
                output = ''
                for i in out:
                    if i.strip():
                        output = output + i.strip() + '\n'
                if ":F:" in output:
                    print "WRP" + output.strip() + ":" + step_name
                    exit()
                else:
                    print "WRP" + output.strip() + ":" + step_name

        elif sol_osname.lower() == "posix":
		if t_osname.lower() == "windows":
                	path = scriptloc.rstrip('/')
                	command = "c:\\python27\\python.exe " + path + "\sapindep " + + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + kernel_path + " " + scriptloc + " " + ker_refid + " " + sys_type + " " + profile_path + " " + db_type + " " + ai_ci_db + " " + seq_no + " " + logfile1 + " " + logfile2
                	write(logfile1, "command : " + command)
                	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	out, err = command.communicate()
               		out = out.split('\n')
                	output = ''
                	for i in out:
                    		if i.strip():
                        		output = output + i.strip() + '\n'
                	if ":F:" in output:
                    		print "WRP" + output.strip() + ":" + step_name
                    		exit()
                	else:
                    		print "WRP" + output.strip() + ":" + step_name


	  	elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux":
                        path = scriptloc.rstrip('/')
			logfile1 = scriptloc + "/" + ker_refid + "_log.log"
                    	logfile2 = scriptloc + "/" + "EpiskyClient_log.log"
                        command = "python " + path + "/lin63 " + hostname + " " + username + " " + password + " " + path + " " + appsid + " " + dbsid + " " + ai_ci_db + " " + sys_type + " " + db_type + " " + kernel_path + " " + seq_no + " " + logfile1 + " " + logfile2 + " " + profile_path + " " + tenant_type
                        write(logfile1, "command : " + command)
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
			out = out.split('\n')
                	output = ''
                	for i in out:
                    		if i.strip():
                        		output = output + i.strip() + '\n'
                	if ":F:" in output:
                    		print output.strip() + ":" + step_name
                    		exit()
                	else:
                    		print output.strip() + ":" + step_name
		else :
			print "WRPSTOPSAPINDEP:F:script not found for OS(" + t_osname.upper() +"):"+ appsid
			exit()
	else:
		 print "WRPSTOPSAPINDEP:F:script not found for OS(" +sol_osname.upper + " ):" + appsid
		 exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "STOPSAPINDEP:F:GERR_1202:Argument/s missing for the script"
        else:
            print "STOPSAPINDEP:F: " + str(e) + ":" + step_name



try:
    file_path = argv[1]
    error_code = argv[2]
    error_code = error_code.split("_")
    seq_no = error_code[2]
    step_name = argv[3]

    command = "chmod 777 -R " + file_path
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()

    f = open(file_path, 'r')
    content = f.read()

    if seq_no == "0":
        arg_string = ""
        for line in content.split("\n"):
            if "indep" in line:
                arg_string = arg_string + "|" + line

        arg_string = arg_string[1:]


        arg_string = arg_string.replace("|"," ")

        argv = arg_string.split(" ")
        argv_len = len(argv) - 1
        #print argv_len

        for index in range(0,argv_len,19):
            hostname = argv[index]
            username = argv[index+1]
            password = argv[index+2]
            appsid = argv[index+3].upper()
            dbsid = argv[index+4].upper()
            kernel_path = argv[index+5]
            scriptloc = argv[index+6].rstrip('\\')
            t_osname = argv[index+7].lower()
            ker_refid = argv[index+9]
            sys_type = argv[index+10]  # ABAP/JAVA
            profile_path = argv[index+11]
            db_type = argv[index+13]
            ai_ci_db = argv[index+14]
            tenant_type = argv[index+15]
            seqno = argv[index+16]
            logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
            logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"
            #print hostname + " "  + username+" "+password +" "+appsid+" "+ker_refid +" "+ scriptloc+" "+ t_osname+" "+ ker_refid+" "+ sys_type+" "+ instance+" " +db_type+" "+ ai_ci_db+ " " seq_no+ " " +logfile1

            sapstop_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type, profile_path, db_type, ai_ci_db, tenant_type, seq_no, logfile1, logfile2, step_name)



    else:
        for line in content.split("\n"):
            if "indep" in line:
		ln = line.split('|')
                if ln[16] < seq_no or ln[16] == seq_no:
                    arg_string = line.replace("|"," ")
                    arg_string = arg_string.split()
                    hostname = arg_string[0]
                    username = arg_string[1]
                    password = arg_string[2]
                    appsid = arg_string[3].upper()
                    dbsid = arg_string[4].upper()
                    kernel_path = arg_string[5]
                    scriptloc = arg_string[6].rstrip('\\')
                    t_osname = arg_string[7].lower()
                    ker_refid = arg_string[9]
                    sys_type = arg_string[10]  # ABAP/JAVA
                    profile_path = arg_string[11]
                    db_type = arg_string[13]
                    ai_ci_db = arg_string[14]
                    tenant_type = arg_string[15]
                    seqno = arg_string[16]
                    logfile1 = scriptloc + "\\" + ker_refid + "_log.log"
                    logfile2 = scriptloc + "\\" + "EpiskyClient_log.log"

                    sapstop_indep(hostname, username, password, appsid, dbsid, kernel_path, scriptloc, t_osname, ker_refid, sys_type,profile_path, db_type, ai_ci_db,tenant_type, seq_no, logfile1, logfile2, step_name)


except Exception as e:
    if str(e) == "list index out of range":
        print "WRPSTOPSAPINDEP:GERR_1202:Argument/s missing for the script"
    else:
        print "WRPSTOPSAPINDEP: " + str(e)
