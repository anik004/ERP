################################################################
#  Script Name: lin52.py
#  Author: Jesna Jose
#  Description: This script will check the space at the target system
################################################################

#!/usr/bin/sh
from __future__ import division
import paramiko
import glob
import os
from paramiko import *
from sys import *
import subprocess
import log4erp
from log4erp import *
import unicodedata

def check_space(target_host,target_user,target_password,file_init,string,user,folder_path,sid,logfile,log,t_osname):
   try:
	print folder_path
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( target_host,username = target_user, password = target_password)
        channel = client.invoke_shell()
	print user

        kernel_path = "echo \" su - " + user + " -c 'which disp+work' | sed \'s/\/disp+work//\'\" | sudo bash "
	print kernel_path
 	log4erp.write(logfile,str(kernel_path))
        stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
	log4erp.write(logfile,str(stdout))
	kernel_path = stdout.readlines()
	print kernel_path
	
        if stdout.channel.recv_exit_status() != 0:
            print "WRP:F:Not able to fetch the Kernel path from target " + string.upper() + " server Hostname ( " + target_host + " ):" + sid.upper()
	    log4erp.write(log,"WRP:F:Not able to fetch the Kernel path from target " + string.upper() + " server Hostname ( " + target_host + " ):" + sid.upper())
            exit()
        else:
	    
            print kernel_path
            kernel_path = ''.join(stdout.readlines()).strip()
            log4erp.write(logfile,str(kernel_path))
	    if t_osname.lower() == "redhat" or t_osname.lower() == "suse_linux":
	            available_space = "echo \" su - " + user + " -c 'df -h " + kernel_path + " | tail -n 1 ' | awk '{print \"\$\"2}\' | sed \'s/G//\'|tail -n -1\"|sudo bash"
		    print available_space
		    log4erp.write(logfile, str(available_space))
                    stdin, stdout, stderr = client.exec_command(available_space, timeout=1000, get_pty=True)
                    available_space= (stdout.readlines()[0]).strip()
                    available_space = available_space[:-1]
		 
                    available_space = float(available_space)
                    log4erp.write(logfile, str(available_space))

	    elif t_osname.lower() == "aix":
		    available_space = "echo \" su - " + user + " -c 'df -k " + kernel_path + " | tail -n 1 ' | awk '{print \"\$\"3}\' | sed \'s/G//\'|tail -n -1\"|sudo bash"
	#	    print str(available_space) + "available_space"
		    log4erp.write(logfile, str(available_space))
	            stdin, stdout, stderr = client.exec_command(available_space, timeout=1000, get_pty=True)
		    available_space= (stdout.readlines()[0]).strip()
		    print available_space
		    available_space = float(available_space)
		    log4erp.write(logfile, str(available_space))

	    print stdout.channel.recv_exit_status()
            if stdout.channel.recv_exit_status() != 0:
                print "WRP:F:Not able to fetch the available space from target " + string.upper() + " server Hostname ( " + target_host + " ):" + sid.upper() 
		log4erp.write(log,"WRP:F:Not able to fetch the available space from target " + string.upper()  + " server Hostname ( " + target_host + " ):" + sid.upper())
                exit()
            else:
                available_space = (available_space * 1024)
		print str(available_space) + "available_space"
                log4erp.write(logfile,str(available_space))
		if str(os.path.exists(folder_path.strip())) == "True":
			out = glob.glob(folder_path + "*")
			log4erp.write(logfile,str(out))
			if out != []:
                		kernel_size = "ls -l " + folder_path + "|grep \"" +str(file_init)+"_\" | awk \'{print $5}\'"# > /dev/null 2>&1"
				log4erp.write(logfile,str(kernel_size))
        	        	command = subprocess.Popen(kernel_size, shell=True, stdout=subprocess.PIPE)
                		out, err = command.communicate()
#				print out	
				log4erp.write(logfile,str(out))
                		kernel_size = out.split('\n')

	                	total_size = float(0)
	
	        	        for each_size in kernel_size:
                    			if (each_size.strip()!= ""):
                            			total_size = total_size + float(each_size.strip())
	                	total_size = (total_size*2.5)/(1024*1024)
				print str(total_size) + "total_size"
				log4erp.write(logfile,str(total_size))
				print type(available_space)
            			necessary_space = total_size + ( available_space / 1024 )
				print str(necessary_space) + "necessary_space"
				log4erp.write(logfile,str(necessary_space))	
        	    		if necessary_space > available_space:
                	        	print "WRPCHECK_SPACE:F: There are not enough space present on the Target " + string.upper()  + " server for Kernel Upgrage HOSTNAME - " + argv[1] + ":" + sid.upper() 
					log4erp.write(log,"WRPCHECK_SPACE:F: There are not enough space present on the Target " + string.upper()  + " server for Kernel Upgrage HOSTNAME - " + argv[1] + ":" + sid.upper() )
                        		exit()
				else:
        	        		print "WRPCHECK_SPACE:P: There are enough space present on the target " + string.upper()  + " Server for the Kernel Upgrade HOSTNAME - " + argv[1] + ":" + sid.upper() 
					log4erp.write(log,"WRPCHECK_SPACE:P: There are enough space present on the target " + string.upper()  + " Server for the Kernel Upgrade HOSTNAME - " + argv[1] + ":" + sid.upper() )
			else:
				print "WRPCHECK_SPACE:F:No file present in " + folder_path + ":" + sid.upper() 
				log4erp.write(log,"WRPCHECK_SPACE:F:No file present in " + folder_path + ":" + sid.upper() )
		else:
			print "WRPCHECK_SPACE:F:Folder Path " + folder_path + " does not exist:" + sid.upper() 
			log4erp.write(log,"WRPCHECK_SPACE:F:Folder Path " + folder_path + " does not exist:" + sid.upper() )
        channel.close()
        client.close()
   except Exception as e:
	if str(e) == "[Errno -2] Name or service not known":
        	print "WRPCHECK_SPACE:F: GERR_0201_Hostname unknown:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0201:Hostname unknown:" + sid.upper() )
        elif str(e).strip() == "list index out of range":
                print "WRPCHECK_SPACE:F: GERR_0202_Argument/s missing for the script:" + sid.upper() 
        elif str(e) == "Authentication failed.":
                print "WRPCHECK_SPACE:F: GERR_0203_Authentication failed.:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0203:Authentication failed.:" + sid.upper() )
        elif str(e) == "[Errno 110] Connection timed out":
                print "WRPCHECK_SPACE:F: GERR_0204_Host Unreachable:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0204:Host Unreachable:" + sid.upper() )
        elif "getaddrinfo failed" in str(e):
                print "WRPCHECK_SPACE:F: GERR_0205_ Please check the hostname that you have provide:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0205: Please check the hostname that you have provide:" + sid.upper() )
        elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPCHECK_SPACE:F: GERR_0206_Host Unreachable or Unable to connect to port 22:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0206:Host Unreachable or Unable to connect to port 22:" + sid.upper() )
	elif "No such file or directory" in str(e):
                print "WRPCHECK_SPACE:F: GERR_0206_No such file exist:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: GERR_0206:No such file exist:" + sid.upper() )
        else:
                print "WRPCHECK_SPACE:F: " + str(e) + ":" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: " + str(e) + ":" + sid.upper() )

try:
    if argv[1] == "--u":
        print "usage: python check_space.py <Target Host> <Target Sudo Username> <Target Sudo Password> <String> <App/DB Sid>"
    else:
    	hostname = argv[1]
        target_user = argv[2]
        target_password = argv[3]
	file_init = argv[4]
	string = argv[5]
	sid = argv[6]
	folder_path = argv[7].rstrip('/')
	logfile = argv[8]
	log = argv[9]
	db_sid = argv[10]
	db_type = argv[11]
	t_osname = argv[12]



	if string.lower() == 'ai' or string.lower() == 'ci':
		user = sid.lower() + "adm"
	elif string.lower() == 'db':
		if db_type.lower() == "db6":
			user = "db2" + db_sid.lower()
		elif db_type.lower() == "ora":
			user = "ora" + db_sid.lower()
		elif db_type.lower() == "hana":
			user = "hdb" + db_sid.lower()

        check_space(hostname,target_user,target_password,file_init,string,user,folder_path,sid,logfile,log,t_osname)

except Exception as e:
	if "No such file or directory" in str(e):
		print "No such file:" + sid.upper() 
		log4erp.write(log,"No such file:" + sid.upper() )
	elif "name 'user' is not defined" in str(e):
		print "WRPCHECK_SPACE:F: Please enter AI or CI for Application Server or Db for Database Server:" + sid.upper() 
		log4erp.write(log,"WRPCHECK_SPACE:F: Please enter AI or CI for Application Server or Db for Database Server:" + sid.upper() )
	elif str(e).strip() == "list index out of range":
                print "WRPCHECK_SPACE:F:GERR_0202_Argument/s missing for the script:" + sid.upper() 
	else:
		print "check_space :" + str(e) + ":" + sid.upper() 
                log4erp.write(log,"check_space :" + str(e) + ":" + sid.upper() )
