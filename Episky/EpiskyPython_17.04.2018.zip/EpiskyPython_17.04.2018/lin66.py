################################################################
#  Script Name: lin66.py
#  Author: Surabhi Priya
#  Description: This script will stop the HANA DB
################################################################



import paramiko
from paramiko import *
from sys import *
#from log4erp import *

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    appsid = argv[4]
    dbsid = argv[5]
    profile_path = argv[6]
    seq_no = argv[7]
    tenant_type = argv[8]  # standalone/multi tenanat
    logfile1 = argv[9]
    logfile2 = argv[10]
    user = str(appsid.lower()) + "adm"

    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect( hostname,username = username, password = password)
    channel = client.invoke_shell()

    command = "cd " + profile_path + ";ls"
    print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()
    #print out

    inst = ""
    for file in out:
        file = file.split()
        for instance in file:
            if dbsid.upper() in instance:
                inst = instance + " " + inst

    instance_no = inst.split()
    #print instance_no

    if len(inst) == 0:
        print "WRPHANASTOP:F:could not find the instance no"
    else:
        for ins in instance_no:
            ins = ins.split("_")
            ins = ins[1][-2:]

	    command = 'echo "su - ' + user + ' -c "\\"/usr/sap/hostctrl/exe/sapcontrol -nr ' + ins + ' -function GetProcessList \\"""|sudo bash'
            print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
            #print out

            for i in out:
                i = (str(i)).split(',')
                if len(i) == 7:
                    status = i[2].strip()
      #              print status
                    if 'GREEN' in status:
                        out = 'SSS:F:The server ' + hostname + ' is up and running'
                        break
                    elif 'YELLOW' in status:
                        out = 'SSS:F:The server ' + hostname + ' is running with warning'
                        break
                    elif 'GRAY' in status:
                        out = 'SSS:P:The server ' + hostname + ' is stopped '

            if ":F:" in out:
                command = 'echo "su - ' + user + ' -c "\\"/usr/sap/' + dbsid.upper() + '/HDB' + ins + '/HDB stop\\""" | sudo bash'
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                out = stdout.readlines()
		print out
                if "hdbdaemon is stopped." in out[-1]:
		    command = 'echo "su - ' + user + ' -c "\\"/usr/sap/hostctrl/exe/sapcontrol -nr ' + ins + ' -function GetProcessList \\"""|sudo bash'
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    out = stdout.readlines()
		    print out

                    for i in out:
                        i = (str(i)).split(',')
                        if len(i) == 7:
                            status = i[2].strip()
                            print status
                            if 'GREEN' in status or 'YELLOW' in status:
                                out = 'SSS:F:The server ' + hostname + ' is up and running'
                                break
                            elif 'GRAY' in status:
                                out = 'SSS:P:The server ' + hostname + ' is stopped '

                    if ":F:" in out:
                        print "WRPHANASTOP:F: Failed to stop the Database on the target server (" + hostname + ") :" + hostname + "_" + appsid + "_" + seq_no
                    else:
                        print "WRPHANASTOP:P: The Database has been stopped successfully on the target server (" + hostname + ") :" + hostname + "_" + appsid + "_" + seq_no

            else:
                print "WRPHANASTOP:P: The Database is already stopped on the target server :" + hostname + "_" + appsid + "_" + seq_no



except Exception as e:
    print "WRPHANASTOP:F: " + str(e)
