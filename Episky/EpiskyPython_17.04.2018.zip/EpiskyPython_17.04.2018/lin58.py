################################################################
#  Script Name: lin58.py
#  Author: Jesna Jose
#  Description: This script performs the connectivity check
################################################################

from sys import *
from os import *
from subprocess import *
import os
import subprocess
import log4erp
from log4erp import * 


try:
    if argv[1] == "--u":
        print "python ping.py <Target Hostname> <string>"
    else:
	t_host = argv[1]
	appsid = argv[2]
	logfile = argv[3]
	log = argv[4]
        osname = name
        if osname == "nt":
        	command = "ping -n 1 " + str(t_host) #+ " > /dev/null 2>&1"
		log4erp.write(logfile,command)
            	#stdout = popen(command).read()
            	response = os.system(command)
		log4erp.write(logfile,str(response))
            	#print "response"
            	#print response

        elif osname == "posix":
        	command = "ping -c1 -i3 " + str(t_host) + " > /dev/null 2>&1"
		log4erp.write(logfile,command)
            	#stdout = popen(command).read()

            	response = os.system(command)
		log4erp.write(logfile,str(response))
	#    	print response

        if response == 0:
		print "PING:P: The connectivity check for Target  Server (Hostname: " + t_host + " ) is Successful:"+appsid
		log4erp.write(log,"PING:P: The connectivity check for Target  Server (Hostname: " + t_host + " ) is Successful:"+appsid)
        else:
        	print "PING:F: Please check the IP address or t_host. Unable to reach the Host ( Hostname: " + t_host + " ):"+appsid
		log4erp.write(log,"PING:F: Please check the IP address or t_host. Unable to reach the Host ( Hostname: " + t_host + " ):"+appsid)

except Exception as e:
	if str(e) == "[Errno -2] Name or service not known":
               print "PING:F:GERR_0201_Hostname unknown:"+appsid
	       log4erp.write(log,"PING:F:GERR_0201:Hostname unknown:"+appsid)
        elif str(e).strip() == "list index out of range":
               print "PING:F:GERR_0202_Argument/s missing for the script:"+appsid
        elif str(e) == "Authentication failed.":
               print "PING:F:GERR_0203_Authentication failed.:"+appsid
	       log4erp.write(log,"PING:F:GERR_0203:Authentication failed.:"+appsid)
        elif str(e) == "[Errno 110] Connection timed out":
               print "PING:F:GERR_0204_Host Unreachable:"+appsid
	       log4erp.write(log,"PING:F:GERR_0204:Host Unreachable:"+appsid)
        elif "getaddrinfo failed" in str(e):
               print "PING:F:GERR_0205_ Please check the t_host that you have provide:"+appsid
	       log4erp.write(log,"PING:F:GERR_0205: Please check the t_host that you have provide:"+appsid)
        elif "[Errno None] Unable to connect to port 22" in str(e):
               print "PING:F:GERR_0206_Host Unreachable or Unable to connect to port 22:"+appsid
	       log4erp.write(log,"PING:F:GERR_0206:Host Unreachable or Unable to connect to port 22:"+appsid)
        else:
               print "PING:F: " + str(e)+":"+appsid
	       log4erp.write(log,"PING:F: " + str(e)+":"+appsid)
