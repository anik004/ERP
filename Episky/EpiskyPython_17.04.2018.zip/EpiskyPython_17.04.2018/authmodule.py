################################################################
#  Script Name: authmodule.py
#  Author: Satyaki Chatterjee
#  Description: This is the module for authorization check 
################################################################
import subprocess
import log4erp
from log4erp import *

def auth(hostname,username,password,appsid,path,seq_no,logfile):
    command = 'c:\\python27\\python.exe ' + path.rstrip() + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' \"exit\"'
    write(logfile, command)
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile, 'OUTPUT : ' + out)
    if 'Errno Connection error' in out:
        print 'ACCESS_CHECK:F:Please check the hostname that you have provide : ' + hostname + "_" + appsid.upper() + "_" + seq_no
        write(logfile,'ACCESS_CHECK:F:Please check the hostname that you have provide : ' + hostname + "_" + appsid.upper() + "_" + seq_no)
        exit()
    elif 'dialect used' in out:
        #print 'ACCESS_CHECK:P:Authentication check successful : ' + hostname + "_" + appsid.upper() + "_" + seq_no
        write(logfile,'ACCESS_CHECK:P:Authentication check successful : ' + hostname + "_" + appsid.upper() + "_" + seq_no)
    else:
        print 'ACCESS_CHECK:F:Authentication failed : ' + hostname + "_" + appsid.upper() + "_" + seq_no
        write(logfile, 'ACCESS_CHECK:F:Authentication failed : ' + hostname + "_" + appsid.upper() + "_" + seq_no)
        exit()
