###########################################################################
#  Script Name: win56.py
#  Author: Surabhi Priya
#  Description: This script fetches the kernel details of the target system
############################################################################



#!/usr/bin/python
import os
import getpass
import subprocess
import re
from sys import *

try:

	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	drive = argv[5]			#kernel path
	location = argv[6].rstrip()			#script loc

	command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + drive + '"'
	#print command
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	# print out
	if "True" in out:
		os_name = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' ' + drive + '\disp+work "'
		command=subprocess.Popen(os_name,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
			#print out
		out=out.split('\n')
		for line in out:
			if re.search('compiled on',line):
				os_name = line.split()
				#print os_name
				if os_name[2] == 'NT':
					os_name ='WINDOWS ON '+ str(os_name[6])
					#download_path="/download/kernel_patch"

			elif re.search('compiled for',line):
				bits = line.split()
				bits = bits[2]
			elif re.search('compilation mode',line):
				uc = line.split()
				uc = uc[2]
			elif re.search('kernel release',line):
				kernel_ver = line.split()
				kernel_ver = kernel_ver[2]
			elif re.search('patch number',line):
				kernel_patch = line.split()
				kernel_patch = kernel_patch[2]


		#download_path="/download/kernel_patch"

	#print app_sid + "|" + app_host + "|" + os_name_app + "|" + uc_app + "|" + bits_app + " bit|" + kernel_ver_app + "|" + kernel_patch_app + "|" + db_sid + "|" + db_host + "|" + os_name_db + "|" + uc_db + "|" + bits_db + " bit|" + kernel_ver_db + "|" + kernel_patch_db + "|" + download_path

		print os_name + "|" + uc + "|" + bits + " bit|" + kernel_ver + "|" + kernel_patch
	else:
		print "WRPdetails_kernel:F:Kernel path "+drive+" does not exist :" + hostname + " " +appsid

# SID|AI/DB|OS|DB|bit|Uni/non|ver|patch
except Exception as e:
	if str(e).strip() == "list index out of range":
		print "WRPdetails_kernel:F:GERR_0202:Argument/s missing for the script:" + hostname + " " +appsid
	else:
		print "WRPdetails_kernel:F: " + str(e)+":" + hostname + " " +appsid

