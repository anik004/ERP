################################################################
#  Script Name: win50.py
#  Author: Surabhi Priya
#  Description: This script performs Authentication check
################################################################

#!/usr/bin/python
import os
import subprocess
from subprocess import *
from sys import *
import log4erp
from log4erp import *

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	path  = argv[5]		#script path
	logfile = path + "\\" + "checklog"

	command = 'c:\\python27\\python.exe ' + path.rstrip() + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"exit\"'
        #print command
	write(logfile, command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	#print out
	write(logfile,out)

	if 'Errno Connection error' in out:
		print 'WRPACCESS_CHECK:F:Please check the hostname that you have provide : ' + hostname + "_" + appsid.upper()
		exit()

	elif 'This is either due to a bad username or authentication' in out:
                print 'WRPACCESS_CHECK:F:Authentication failed : ' + hostname + "_" + appsid.upper()
	else:
		print 'WRPACCESS_CHECK:P:Authentication check successful : ' + hostname + "_" + appsid.upper()


except Exception as e:
	if str(e).strip() == "list index out of range":
		print "WRPACCESS_CHECK:F:GERR_0202:Argument/s missing for the script : " + hostname + "_" + appsid.upper()
	else:
		print "WRPACCESS_CHECK:F: " + str(e) + ": " + hostname + "_" + appsid.upper()


	







