################################################################
#  Script Name: win64.py
#  Author: Surabhi Priya
#  Description: This script performs the MSSQL DB start
################################################################


from sys import *
import subprocess
import os
import log4erp
from log4erp import *

try:	
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	location = argv[5].rstrip('\\') 	#script loc
	seq_no = argv[6]
	logfile1 = argv[7]
	logfile2 = argv[8]

	final = []
###################################### FETCHING SERVICES STARTING WITH SQL #####################################

	command = 'c:\\python27\\python.exe '+location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SQL\\" "'
	write(logfile1, command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	out = (out.strip()).split()
	for each in out:
		if "SQL" in each:
			final += [each]


###################################### FETCHING SERVICES STARTING WITH MSSQL #####################################

	command = 'c:\\python27\\python.exe '+location + '\wmiexec.py  ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: MSSQL\\" "'
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	out = (out.strip()).split()
	for each in out:
		if "MSSQL" in each:
			final += [each]
	for ser in final:
		if "$SQL" in ser:
			ser = ser.replace("$","\$")

###################################### STARTING ALL THE DB SERVICES #####################################

		command = 'c:\\python27\\python.exe '+location + '\wmiexec.py  ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "net start "' + ser + '" "'
		write(logfile1, command)
		command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1, out)
		if "service has already been started" in out:
			#print "DBSTART_MSSQL:P: The service " + ser + " has been already started :"+appsid
			write(logfile2, "DBSTART_MSSQL64:P: The service " + ser + " has been already started : " + hostname + "_" + appsid + "_" + seq_no)
		elif "service was started successfully" in out or "it is disabled" in out:
			#print "DBSTART_MSSQL:P: The service " + ser +"has been started successfully :"+appsid
			write(logfile2, "DBSTART_MSSQL64:P: The service " + ser +"has been started successfully : " + hostname + "_" + appsid + "_" + seq_no)
		else:
			#print "DBSTART_MSSQL:F: The service " + ser + " has not been started successfully"
			write(logfile2, "DBSTART_MSSQL64:F: The service " + ser + " has not been started successfully : " + hostname + "_" + appsid + "_" + seq_no)
	print "WRPDBSTART_MSSQL:P: DB has been started successfully : " + hostname + "_" + appsid + "_" + seq_no
	write(logfile2, "DBSTART_MSSQL64:P: DB has been started successfully : " + hostname + "_" + appsid + "_" + seq_no)


#################################### R3TRANS CHECK ####################################################

	command = "c:\\python27\\python.exe " + location + "\\r3trans_test " + hostname + " " + username + " " + password + " " + appsid + " " + location + " " + seq_no + " " + logfile1 + " " + logfile2
#	# print command
	write(logfile1, command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	out, err = command.communicate()
	print out


except Exception as e:
	if str(e) == "list index out of range":
		print "WRPDBSTART_MSSQL64:F:GERR_1302:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
	else:
		print "WRPDBSTART_MSSQL64:F: " + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no
		write(logfile2, "DBSTART_MSSQL64:F: " + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no)
