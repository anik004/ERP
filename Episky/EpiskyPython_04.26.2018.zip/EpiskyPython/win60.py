################################################################################
#  Script Name: win60.py
#  Author: Surabhi Priya
#  Description: This script performs the DB start and SAP start on windows system
##################################################################################

#!/usr/bin/python 
import re
import log4erp
from log4erp import *
from sys import *
import subprocess
import os
import authmodule
from authmodule import *
import pingmodule
from pingmodule import *

def sapstart(hostname,username,password,appsid,sys_type,profile_path,kernel_path,script_loc,seq_no,logfile1, logfile2):
    try:
        ping(hostname, appsid, seq_no, logfile1)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1)


	#################################################### R3trans check ###########################################################

	#command = "c:\\python27\\python.exe " + script_loc + "\\r3trans_check " + hostname + " " + username + " " + password + " " + appsid + " " + script_loc + " " + seq_no + " " + logfile1 + " " + logfile2
        # print command
        #write(logfile1, command)
        #command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        #out, err = command.communicate()
        #print out

	#if ":P:" in out:
	
        	
	        #################################################### FOLDER EXISTENCE CHECK ON REMOTE SERVER #####################################

        command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + kernel_path + '"'
	#print command
        write(logfile1,command)
	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	write(logfile1,out)

        	#################   CHECKING PROFILE PATH EXISTENCE ON REMOTE SERVER ###################################

	if "True" in out:
        	    command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "powershell.exe;test-path ' + profile_path + '"'
	            #print command
        	    write(logfile1,command)
	            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	    out, err = command.communicate()
	            #print out
        	    write(logfile1,out)

	            if "True" in out:
        	        profile_path = profile_path
                	command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' " dir ' + profile_path + ' | findstr -V START" '
	                #print command
        	        write(logfile1,command)
                	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	                out, err = command.communicate()
        	        #print out
                	write(logfile1, out)
	                a = out.split("\n")
        	        #print a
                	b = "."
	                #print hostname
        	        arr = ""
                	a = a[5:]
	                for dirs in a:
        	            if appsid in dirs:
                	        #print dirs
                        	if b in dirs or "sapmnt" in dirs or "Copy" in dirs or "profile" in dirs:
	                            c = ""
        	                else:
                	            #print dirs
                        	    c = dirs.split()
	                            c = c[-1]
        	                #    print c
                	            arr = arr +" " + c
	                arr = arr.split(" ")
        	        arr = filter(None,arr)
                	#print arr

	                inst = " "
        	        for p in arr:
                	    instance = p.split("_")[1]
	                    inst = instance[-2:] + " " +  inst
	
        	        inst = inst.split(" ")
                	inst = filter(None,inst)
    
	                #print inst
        	

	        ##################################################### SAP STATUS CHECK = RUNNING/STOPPED/INTERMEDIATE ###########################

        	        for ins in reversed(inst):
                	    #print ins
	                    if sys_type.lower() == 'abap':
        	                command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function GetProcessList' + '\"'
                	        write(logfile1, command)
                        	#print command
	                    elif sys_type.lower() == 'java':
        	                command = 'c:\\python27\\python.exe ' + script_loc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' \"' + kernel_path[:1] + ': & cd ' + kernel_path + ' & sapcontrol -nr ' + str(ins) + ' -function J2EEGetProcessList' + '\"'
                	        write(logfile1, command)
	
        	            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                	    out, err = command.communicate()
	                    write(logfile1,out)    
	
        	            #if "NIECONN_REFUSED" in out:
                	    #    print "WRPSAPSTART_WIN60:F:The instance number " + instance + " passed is incorrect : " + hostname + "_" + appsid + seq_no
                            #	write(logfile1, "WRPSAPSTART_WIN60:F:The instance number " + instance + " passed is incorrect :" + appsid)
	                    #    exit()

        	            #out = out.split("\n")
	
        	            #for i in out:
                	    #    i = (str(i)).split(',')
	                    #    if len(i) == 7:
        	            #        status = i[2].strip()
                	    #        if 'YELLOW' in status:
                            #        out = 'SSS:F:The server '+ hostname + ' is running with warning : ' + appsid
                            #    	break
	                    #        elif 'GRAY' in status:
        	            #            out = 'SSS:F:The server ' + hostname + ' is stopped :' + appsid
                	    #            break


	                    #if ":F:" in out:
        	            if sys_type.lower() == 'abap':
                	                command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & startsap.exe name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                        	        write(logfile1,command)
                                	#print command
	                    elif sys_type.lower() == 'java':
        	                        command = 'c:\\python27\\python.exe ' + scriptloc + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "' + kernel_path[:1] + ': & cd ' + kernel_path + ' & startsap.exe j2ee name=' + appsid + ' nr=' + str(ins) + ' SAPDIAHOST=' + hostname + '"'
                	                write(logfile1,command)

	                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        	            out, err = command.communicate()
                	        #print out
	                    write(logfile1,out)
	
	                    if "STARTSAP failed" in out:
        	                        print 'WRPSAPSTART_WIN60:F:The sap system has not been started : ' + hostname + "_" + appsid + "_" + seq_no
                	                write (logfile2, 'SAPSTART_WIN60:F:The sap system has not been started : ' + hostname + "_" + appsid + "_" + seq_no)
                        	        exit()
	                    else:
        	                        print 'WRPSAPSTART_WIN60:P:The sap system for instance no ' + ins + ' has been started successfully : ' + hostname + "_" + appsid + "_" + seq_no
                	                write (logfile2, 'SAPSTART_WIN6:P:The sap system for instance no ' + ins + ' has been started successfully : ' + hostname + "_" + appsid + "_" + seq_no)

	            else:
        	        print "WRPSAPSTART_WIN60:F:The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no
                	write(logfile2,"SAPSTART_WIN60:F:The Profile Path " + profile_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no)
	                exit()

        else:
	            print "WRPSAPSTART_WIN60:F:The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no
        	    write(logfile2,"SAPSTART_WIN60:F:The Kernel Path " + kernel_path + " passed is incorrect : " + hostname + "_" + appsid + "_" + seq_no)
	            exit()

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPSAPSTART_WIN60:F:GERR_1202:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPSAPSTART_WIN60:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1, "SAPSTART_WIN60:F:" + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no)


def dbstart_MSS(hostname, username, password, appsid, script_loc, seq_no, logfile1, logfile2):
    try:
        ping(hostname, appsid, seq_no, logfile1)
        auth(hostname, username, password, appsid, scriptloc, seq_no, logfile1)

        command = "c:\\python27\\python.exe " + script_loc + "\win64 " + hostname + " " + username + " " + password + " " + appsid + " " + script_loc + " " + seq_no + " " + logfile1 + " " + logfile2
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out


    except Exception as e:
        if str(e).strip() == "list index out of range":
            print "WRPDBSTART_WIN60:F:GERR_3002:Argument/s missing for sapstartapp script: " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPDBSTART_WIN60:F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no

def dbstart_HANA(hostname, username, password, appsid, dbsid, profile_path, seq_no, tenant_type, logfile1,logfile2):
    try:
        command = "c:\\python27\\python.exe " + scriptloc + "\hanastart " + hostname + " " + username + " " + password + " " + appsid + " " + dbsid + " " + profile_path + " " + seq_no + " " + tenant_type + " " + logfile1 + " " + logfile2
        #print command
        write(logfile1, command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        write(logfile1, out)
        print out

    except Exception as e:
        if str(e) == "list index out of range":
            print "WRPDBSTOP_HANA:F:GERR_1202:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
        else:
            print "WRPDBSTOP_HANA:F:" + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no
            write(logfile1, "DBSTOP_HANA:F:" + str(e))
            write(logfile2, "DBSTOP_HANA:F:" + str(e))


try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    appsid = argv[4].upper()
    dbsid = argv[5].upper()
    kernel_path = argv[6]
    scriptloc = argv[7]
    ker_refid = argv[8]
    sys_type = argv[9]  # ABAP/JAVA
    profile_path = argv[10]
    db_type = argv[11]
    ai_ci_db = argv[12]
    tenant_type = argv[13]
    seq_no = argv[14]
    logfile1 = argv[15]
    logfile2 = argv[16]
    #print logfile2
    if ai_ci_db.upper() == "CI" or ai_ci_db.upper() == "AI":
        sapstart(hostname, username, password, appsid, sys_type, profile_path, kernel_path, scriptloc, seq_no, logfile1, logfile2)

    elif ai_ci_db.upper() == "DB":
        if db_type == "MSS":
            dbstart_MSS(hostname, username, password, appsid, scriptloc, seq_no, logfile1, logfile2)
        elif db_type == "HDB":
            dbstart_HANA(hostname, username, password, appsid, dbsid, profile_path, seq_no, tenant_type,logfile1,logfile2)


except Exception as e:
    if str(e).strip() == "list index out of range":
        print "WRPSAPSTART_WIN60:F:GERR_3002:Argument/s missing for sapstartapp script: " + hostname + "_" + appsid + "_" + seq_no
    else:
        print "WRPSAPSTART_WIN60:F: " + str(e) + ": " + hostname + "_" + appsid + "_" + seq_no

