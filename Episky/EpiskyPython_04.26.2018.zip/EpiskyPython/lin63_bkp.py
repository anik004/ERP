##########################################################################
#  Script Name: lin63_bkp.py 
#  Author: Jesna Jose
#  Description: This scripts stops the SAP and calls the script for DB stop
##########################################################################


import paramiko
from paramiko import *
import log4erp
from sys import *
import subprocess
from subprocess import *
from log4erp import *
import re


def sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log,app_user):
                client = SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect( hostname,username = username, password = password)
                channel = client.invoke_shell()
                if sys_type == 'abap':
                        command = "echo \"su - " + app_user + " -c \'" + kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + " -function GetProcessList\'\" | sudo bash"
                        log4erp.write(logfile,command)
                elif sys_type == 'java':
                        command = kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function J2EEGetProcessList'
                        log4erp.write(logfile,command)
		else:
			print "WRPSAPSTOPAPP:F:sys_type (" + sys_type + ") is unknown :" + hostname

                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()
                out = stdout.readlines()
		print out
                log4erp.write(logfile,str(out))

                for i in out:
                        i = (str(i)).split(',')
                        if len(i) == 7:
                                status = i[2].strip()
#                               print status
                                server = i[1].strip()
                                if status == 'GREEN':
                                        res = 'SSS:P:The server ' + hostname + ' is up and running'
                                        log4erp.write(log,'SSS:P:The server ' + hostname + ' is up and running')
                                        return res
#                                       print server+' is running in the ' + hostname
                                if status == 'YELLOW':
                                        res = 'SSS:P:The server '+ hostname + ' is running with warning'
                                        log4erp.write(log,'SSS:F:The server '+ hostname + ' is running with warning')
                                        return res
                                        exit()
                                if status == 'GRAY':
                                        res = 'SSS:F:The server ' + hostname + ' is stopped'
                                        log4erp.write(log,'SSS:F:The server ' + hostname + ' is stopped')
                                        return res
                                        exit()
                channel.close()
                client.close()

try:	
				
			
	hostname = argv[1].strip()
	username = argv[2].strip()
	password = argv[3].strip()
	path = argv[4].strip()
	app_sid = argv[5].strip()
	db_sid = argv[6].strip()
	ai_ci_db = argv[7]
	sys_type = argv[8]
	db_type = argv[9]
	kernel_path = argv[10]
	seq_no = argv[11]
	logfile = argv[12]
	log = argv[13]
	profile_path = argv[14]
	tenant_type = argv[15]


	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell


	if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
       			user_sap = app_sid.lower() + "adm"

			command = "echo 'su - " +user_sap+ " -c \" exit() \"' | sudo bash"
			print command
			log4erp.write(logfile,command)
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
                        log4erp.write(logfile,str(out))
			if "does not exist" in str(out):
				print "WRPSAPSTop:F:App sid (" + app_sid.upper() + ") is incorrect :" + hostname + "_" + app_sid.upper() + "_" + seq_no
				log4erp.write(logfile,"WRPSAPSTOP:F:App sid (" + app_sid.upper() + ") is incorrect :" + app_sid.upper())
				exit()
#			command = 'echo "su - ' + user_sap + ' -c \' ls ' + profile_path + ' | grep -i ' + hostname + ' | grep -v \\\"\.\\\" | grep -v \\\"ASC\\\" | grep -v \\\"SCS\\\" | cut -d\\\"_\\\" -f2\'" | sudo bash'
			command = 'echo "su - ' + user_sap + ' -c "\'"ls ' + profile_path + '"\'\'| grep -i ' + hostname + ' | grep -v "\." | grep -v "ASC" | grep -v "SCS" \'| sudo bash'
			print command
	        	log4erp.write(logfile,command)
	        	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        	status = stdout.readlines()
			log4erp.write(logfile,str(status))
			for i in status:
				if "MAIL" not in i:
					instance = i.split("_")[1][-2:]
	        			a= "su: user "+ user_sap +" does not exist"
		       			if str(status).strip() == str(a):
						print "WRPSAPSTOP:F: The user " + user_sap +" does not exist on the target server " + hostname + " ,please provide correct application SID:"+hostname + "_" + app_sid.upper() + "_" + seq_no
		       				log4erp.write(logfile,"SAPSTARTAPP:F: The user " + user_sap + " does not exist on the target server " + hostname + " ,please provide correct application SID:")+ app_sid
        				out = sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log,user_sap)
		        		status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
	#	print status
					log4erp.write(logfile,"status "+status)
					if status == "F":
			    			print "WRPSAPSTOPAPP:P: The SAP service is already stopped on the target server :" + hostname + "_" + app_sid.upper() + "_" + seq_no
					    	log4erp.write(log,"SAPSTOPAPP:P:The SAP service is already stopped on the target server (HOSTNAME - " + hostname + "):"+ app_sid)
	            
					else:
						if sys_type == "abap":
							command = "echo 'su - " + user_sap + ' -c "stopsap r3 '+ '"\' | sudo bash'
							print command
							log4erp.write(logfile,command)
						        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
							out = stdout.readlines()
							#print out
							log4erp.write(logfile,str(out))
							out = sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log,user_sap)
						
					        	if ":F:" in out:
					        		print "WRPSAPSTOPAPP:P: The SAP service has been stopped on the target server :" + hostname + "_" + app_sid.upper() + "_" + seq_no
						        	log4erp.write(log,"SAPSTOPAPP:P:The SAP service has been stopped on the target server (HOSTNAME - " + hostname + "):"+ app_sid)
	           
						        else:
						        	print "WRPSAPSTOPAPP:F: The SAP server has not been successfully stopped on the target server :" + hostname + "_" + app_sid.upper() + "_" + seq_no
						                log4erp.write(log, "SAPSTOPAPP:F:The SAP server has not been successfully stopped on the target server (HOSTNAME - " + hostname + "):"+ app_sid)
                
								exit()
						elif sys_type == "java":
							command = "echo 'su - " + user_sap + ' -c "stopsap j2ee '  + hostname.lower() + '"\' | sudo bash'
							log4erp.write(logfile,command)
							stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
							log4erp.write(logfile,str(stdout))
							status = stdout.channel.recv_exit_status()
							if status == 0:
								print "WRPSAPSTOPAPP:P: The SAP service has been stopped on the target server (HOSTNAME - " + hostname + "):" + hostname + "_" + app_sid.upper() + "_" + seq_no
							        log4erp.write(log,"SAPSTOPAPP:P:The SAP service has been stopped on the target server (HOSTNAME - " + hostname + "):")+ app_sid
                    	
							else:
								print "WRPSAPSTOPAPP:F: The SAP server has not been successfully stopped on the target server (HOSTNAME - " + hostname + "):" + hostname + "_" + app_sid.upper() + "_" + seq_no
							        log4erp.write(log,"SAPSTOPAPP:F:The SAP server has not been successfully stopped on the target server (HOSTNAME - " + hostname + "):"+ app_sid)
	
								exit()
						command = "echo \"su - " + user_sap + " -c \'stopsap sapstartsrv\'\" | sudo bash"
						print command
                                                log4erp.write(logfile,command)
                                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                                out = stdout.readlines()
                                                log4erp.write(logfile,str(out))
						     
						command = "echo \"su - " + user_sap + " -c \'cleanipc " + instance+ ' remove;cleanipc ' + instance + " remove\'\" | sudo bash"
						print command
		        			log4erp.write(logfile,command)
						stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						out = stdout.readlines()
						log4erp.write(logfile,str(out))

						status = stdout.channel.recv_exit_status()
						#print status
			       			if status == 0:
						       print 'WRPSAPSTOPAPP:P: The CLEANIPC has been successfully completed on the target server :' + hostname + "_" + app_sid.upper() + "_" + seq_no
						       log4erp.write(log,'SAPSTOPAPP:P:The CLEANIPC has been successfully completed on the target server (HOSTNAME - ' + hostname + '):'+ app_sid)
						       exit()
            	
						else:
						       print 'WRPSAPSTOPAPP:F: The CLEANIPC has not been successfully done on the target server :' + hostname + "_" + app_sid.upper() + "_" + seq_no
						       log4erp.write(log,'SAPSTOPAPP:F:The CLEANIPC has not been successfully done on the target server (HOSTNAME - ' + hostname + '):'+ app_sid)
						       exit()
				#	channel.close()
		        	#	client.close()

	elif ai_ci_db.upper() == "DB":
	
		if db_type.upper() == "ORA":

			command = "python "+ path + "/lin55 " + hostname + " " + username + " " + password + " " + db_sid + " " + app_sid + " " + seq_no + " " + logfile + " " + log
			log4erp.write(logfile,command)
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			out, err = command.communicate()
			print out

		elif db_type.upper()=="HDB":

			command = "python "+ path + "/lin66 " + hostname + " " + username + " " + password + " " + app_sid + " " + db_sid + " " + profile_path + " " + seq_no + " " + tenant_type + " " +logfile+ " " + log
			print command
		        log4erp.write(logfile,command)
		        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		        out, err = command.communicate()
		        print out
		elif db_type.upper()=="SYB":
                        command = "python "+ path + " /dbstop_sybase " + hostname + " " + username + " " + password + " "  + db_sid  + " " + logfile + " " +  app_sid + " "  + log + " " + seq_no+ " " + ai_ci_db
			print command
                        log4erp.write(logfile,command)
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out

		elif db_type.upper() == "DB6":

			 command = "python " + path + "/dbstop_db2 " + hostname + " " + username + " " + password + " " + app_sid + " " +  db_sid + " " + logfile + " " + log + " " + seq_no
                         write(logfile,command)
                         command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                         out, err = command.communicate()
                         print out
	
		#		channel.close()
		#		client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "WRPSAPSTOPAPP:F:GERR_1201_Hostname unknown:" + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Hostname unknown [Error Code - 1201]')
     elif str(e) == "list index out of range":
                print "WRPSAPSTOPAPP:F:GERR_1202_Argument/s missing for the script:" + hostname + "_" + app_sid.upper() + "_" + seq_no
     elif str(e) == "Authentication failed.":
                print "WRPSAPSTOPAPP:F:GERR_1203_Authentication failed.:" + + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Authentication failed.[Error Code - 1203]')
     elif str(e) == "[Errno 110] Connection timed out":
                print "WRPSAPSTOPAPP:F:GERR_1204_Host Unreachable:" + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Authentication failed.[Error Code - 1204]')
     elif "getaddrinfo failed" in str(e):
                print "WRPSAPSTOPAPP:F:GERR_1205_ Please check the hostname that you have provide:" + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Please check the hostname that you have provide [Error Code - 1205]')
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPSAPSTOPAPP:F:GERR_1206_Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Host Unreachable or Unable to connect to port 22 [Error Code - 1206]')
     elif "invalid decimal" in str(e):
                print "WRPSAPSTOPAPP:F:GERR_1207_Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid.upper() + "_" + seq_no
                log4erp.write(log,'SAPSTOPAPP:F:Unknown Error:' + str(e) + '[Error Code - 1207]')
     else:
                print "WRPSAPSTOPAPP:F:" + str(e) + ":" + hostname + "_" + app_sid.upper() + "_" + seq_no
		#log4erp.write(log,"SAPSTOPAPP:F:" + str(e))


