####################################################################################
#  Script Name: lin62_bkp.py
#  Author: Satyaki Chatterjee
#  Description: This script will start the sap and also calls the script for DB start 
######################################################################################


import paramiko
from paramiko import *
import subprocess
from subprocess import *
from sys import *
import log4erp 
from log4erp import *
import re


def sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log, seq_no, app_user):
	
	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

	if sys_type == 'abap':
                command = " echo \"su - " + app_user + " -c \"\\\"\"" + kernel_path.rstrip("/") + "/sapcontrol -nr " + instance + " -function GetProcessList\"\\\"|sudo bash"
		print command
		log4erp.write(logfile,command)
        elif sys_type == 'java':
                command = kernel_path.rstrip("/") + '/sapcontrol -nr ' + instance + ' -function J2EEGetProcessList'
		log4erp.write(logfile,command)

        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.channel.recv_exit_status()
        out = stdout.readlines()
	print out
	log4erp.write(logfile,str(out))


	for i in out:
		if ',' in i:
			print i
	                i = (str(i)).split(',')
       	        	if len(i) == 7:
                        	status = i[2].strip()
       		                server = i[1].strip()
				print status
               		        if status == 'GREEN':
#      	               		        print server+' is running in the ' + hostname
					res = 'SSS:P:The server ' + hostname + ' is up and running'
					log4erp.write(logfile,res)
	      	                        return res
	                        elif status == 'YELLOW':
       		                        res = 'SSS:F:The server '+ hostname + ' is running with warning'
					log4erp.write(logfile,res)
					return res
                       		elif status == 'GRAY':
                               		res = 'SSS:F:The server ' + hostname + ' is stopped'
					log4erp.write(logfile,res)
					return res
			elif "NIECONN_REFUSED" in i:
				res = 'SSS:F:Instance number is wrong'
				log4erp.write(logfile,res)
		
	channel.close()
	client.close()

def strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log, seq_no, profile_path,ai_ci_db):

        user_sap = app_sid.lower() + "adm"
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

	command = "hostname"
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        p_hostname = stdout.readlines()
	p_hostname = p_hostname[0]


	command = 'echo "su - ' + user_sap + ' -c "\'"ls ' + profile_path + '"\'\'| grep -i ' + hostname + ' | grep -v "\." | grep -v "ASC" | grep -v "bkp" | grep -v "SCS" | grep -v "START" \'| sudo bash'
	print command
        log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        status = stdout.readlines()
	print status
        log4erp.write(logfile,str(status))
        for i in status:
#		print i
#		if "MAIL" not in i:
#	                instance = i.split("_")[1]
#			instance = instance[-2:]
#			out = sys_st(hostname,username,password,sys_type,instance,kernel_path,logfile,log, seq_no, user_sap)
#			log4erp.write(logfile,str(out))
#			print "status: " + str(status)
#			status = str(out)
#			print "status: " + str(status)
#			status = (str(out).split('\n')[len(out.split('\n')) - 2]).split(':')[1]
#			print status

#			if ":P:" in str(status):
#	       			print "WRPSAPSTARTAPP:P: The SAP service is already started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
#	       			log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service is already started on the target server (HOSTNAME - " + hostname + ")")
#				exit()
            
#        		else:
				flag = 0
				command = 'echo "su - ' + user_sap + ' -c "\'"ps -ef "\'\'| grep -i ' + user_sap + ' | grep -i /usr/sap | grep -v "#" | grep -v "sapstartsrv"| grep -v "grep" \'|sudo bash'
				print command
				log4erp.write(logfile,command)
			       	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        			stdout = stdout.readlines()
				all_names = []
                                for each in stdout:
                                        each = each.split(" ")
                                        each = filter(None,each)
                                        all_names.append(each[1])
                                #print all_names
                                all_names = filter(None,all_names)
                                #print all_names
                                sorted(set(all_names))
				print all_names
				log4erp.write(logfile,str(all_names))
				if str(all_names).strip() == '[]':
				   flag = 1
				else:
			           for n in range (0, (len(all_names))):
                			proc = all_names[n].strip()
                			command = "echo \"su - " + user_sap + " -c \"\\\"kill -9 " + proc + "\\\"|sudo bash"
					print command
					log4erp.write(logfile,command)
                			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
					print stdout.readlines()
					log4erp.write(logfile,str(stdout.readlines()))
					print stdout.channel.recv_exit_status()
                			if stdout.channel.recv_exit_status() == 0:
						flag = 1
                    				print "WRPSAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server :" + hostname + "_" + app_sid + "_" + seq_no
                    				log4erp.write(log,"WRPSAPSTARTAPP:I: The processes related to the SAP has been stopped in the target application server (HOSTNAME - " + hostname + ")")
					else:
						flag = 0
				if flag == 1:
				
	    				if sys_type == "abap":
                				command = "echo \"su - " + user_sap + " -c \"\\\"\"startsap r3 "+  "\"\\\"|sudo bash"
						print command
	        				log4erp.write(logfile,command)
                				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout.readlines()))
                				status = stdout.channel.recv_exit_status()
                				if status == 0:
							print "WRPSAPSTARTAPP:P: The SAP service has been started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
							log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
							exit()
          
						else:
						        print "WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
						        log4erp.write(log,"WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
 #           write (log, log)
		    			elif sys_type == "java":
						command = "echo \"su - " + user_sap + " -c \"\\\"\"startsap j2ee "  + hostname+ "\\\"\"|sudo bash"
						log4erp.write(logfile,command)	        
					        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
						log4erp.write(logfile,str(stdout))
					        status = stdout.channel.recv_exit_status()
					        if status == 0:
					                 print "WRPSAPSTARTAPP:P: The SAP service has been started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
					                 log4erp.write(log,"WRPSAPSTARTAPP:P: The SAP service has been started on the target server (HOSTNAME - " + hostname + ")")
                    
					        else:
					                  print "WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seq_no
					                  log4erp.write(log,"WRPSAPSTARTAPP:F: The SAP server has not been successfully started on the target server (HOSTNAME - " + hostname + ")")
                    
        channel.close()
        client.close()



try:

	hostname = argv[1]
	username = argv[2]
 	password = argv[3]
	app_sid = argv[4]
	sys_type = argv[5]
	kernel_path = argv[6]
 	logfile = argv[7]
  	log = argv[8]
	ai_ci_db = argv[9]
	db_sid = argv[10]
  	path = argv[11].rstrip('/')
	seq_no = argv[12]
	db_type = argv[13]
	profile_path = argv[14]
	if ai_ci_db.upper() == "AI" or ai_ci_db.upper() == "CI":
		strtsap(hostname,username,password,app_sid,sys_type,kernel_path,logfile,log, seq_no, profile_path,ai_ci_db)

	elif ai_ci_db.upper() == "DB":
		
		if db_type.lower() == "hdb":
			tenant_type = argv[15]
			command = "python "+ path + "/lin65 " + hostname + " " + username + " " + password + " " + profile_path + " " + db_sid + " " + seq_no + " " + tenant_type + " " +logfile+ " " + log
                        log4erp.write(logfile,command)
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
                elif db_type.lower() == "db6":
			command = "python " + path + "/dbstart_db2 " + hostname + " " + username + " " + password + " " + app_sid + " " +  db_sid + " " + logfile + " " + log + " " + seq_no
			print command
                        write(logfile,command)
                        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
		elif db_type.lower() == "syb":

                         command = "python " + path + "/dbstart_sybase "  + hostname + " " + username + " " + password + " " + db_sid  + " " + logfile + " " +  app_sid + " "  + log + " " + seq_no+ " " + ai_ci_db
                         write(logfile,command)
                         command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                         out, err = command.communicate()
                         print out

                elif db_type.lower() == "ora":
			command = os.path.exists( path + "/lin54")
	                log4erp.write(logfile, str(command))
	                out = command
	                log4erp.write(logfile,str(out))
			if str(out).strip() == 'True':
			
				command = "python " + path + "/lin54 " + hostname + " " + username + " " + password + " " + app_sid + " " + db_sid + " " + logfile + " " + log + " " + seq_no
				write(logfile,command)
	                	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	                	out, err = command.communicate()
	            		print out

			else:
				print "WRPSAPSTARTAPP:F:" + path + "/lin54 not found :" + hostname + " " + app_sid + " " + seq_no
	
		
		
except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "WRPSAPSTARTAPP:F:GERR_1301_Hostname unknown :" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F: Hostname unknown [Error Code - 1301]')
     elif str(e) == "list index out of range":
                print "WRPSAPSTARTAPP:F:GERR_1302_Argument/s missing for the script"
     elif str(e) == "Authentication failed.":
                print "WRPSAPSTARTAPP:F:GERR_1303_Authentication failed. :" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F:Authentication failed.[Error Code - 1303]')
     elif str(e) == "[Errno 110] Connection timed out":
                print "WRPSAPSTARTAPP:F:GERR_1304_Host Unreachable :" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F:Host Unreachable.[Error Code - 1304]')
     elif "getaddrinfo failed" in str(e):
                print "WRPSAPSTARTAPP:F:GERR_1305_ Please check the hostname that you have provide :" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F: Please check the hostname that you have provide [Error Code - 1305]')
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "WRPSAPSTARTAPP:F:GERR_1306_Host Unreachable or Unable to connect to port 22 :" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]')
     elif "invalid decimal" in str(e):
                print "WRPSAPSTARTAPP:F:GERR_1307_Unknown Error " + str(e) + ":" + hostname + " " + app_sid + " " + seq_no
                log4erp.write(log,'WRPSAPSTARTAPP:F: Unknown Error:' + str(e) + '[Error Code - 1307]')
     else:
                print "WRPSAPSTARTAPP:F: " + str(e) + ":" + hostname + " " + app_sid + " " + seq_no
		log4erp.write(log, "WRPSAPSTARTAPP:F: " + str(e))


