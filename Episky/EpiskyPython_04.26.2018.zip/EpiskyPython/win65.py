################################################################
#  Script Name: win65.py
#  Author: Jesna Jose
#  Description: This script performs the DB stop of MSSQL DB
################################################################


import log4erp
from log4erp import *
from sys import *
import subprocess

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	appsid = argv[4]
	location = argv[5]		#script location
	seq_no = argv[6]
	logfile1 = argv[7]
	logfile2 = argv[8]

	final = []

###################################### FETCHING SERVICES STARTING WITH SQL #####################################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: SQL\\" "'
	write(logfile1, command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	out = (out.strip()).split()

	for each in out:
		if "SQL" in each:
			final += [each]
	#print final
###################################### FETCHING SERVICES STARTING WITH MSSQL #####################################

	command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "sc queryex type= service state= all | find /i \\"SERVICE_NAME: MSSQL\\" "'
	write(logfile1,command)
	command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
	out, err = command.communicate()
	write(logfile1, out)
	out = (out.strip()).split()
	#print out
	for each in out:
		if "MSSQL" in each:
			final += [each]
	#print final
	for ser in final:
		if "$SQL" in ser:
			ser = ser.replace("$","\$")
			#print ser
###################################### STOPPING ALL THE DB SERVICES #####################################

		command = 'c:\\python27\\python.exe '+ location +'\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "net stop "' + ser + '" "'
		#print command
		write(logfile1, command)
		command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		write(logfile1, out)
		if "service is not started" in out:
			#print "DBSTOP_MSSQL:P: The service " + ser + " has already been stopped : " + hostname + "_" + appsid + " " + seq_no
			write(logfile2, "DBSTOP_MSSQL:P: The service " + ser + " has already been stopped :" + appsid )
		elif 'service was stopped successfully' in out:
			#print "DBSTOP_MSSQL:P: The service " + ser + " has been stopped successfully : " + hostname + "_" + appsid + " " + seq_no
			write(logfile2,"DBSTOP_MSSQL:P: The service " + ser + " has been stopped successfully :" + appsid)
		else:
			print "WRPDBSTOP_MSSQL:F: The service " + ser + " has not been stopped successfully :" + hostname + "_" + appsid + "_" + seq_no
			write(logfile2, "DBSTOP_MSSQL:F: The service " + ser + " has not been stopped successfully :" + appsid)
			exit()
	print "WRPDBSTOP_MSSQL:P: DB has been stopped successfully :" + hostname + "_" + appsid + "_" + seq_no
	write(logfile2,"DBSTOP_MSSQL:P: DB has been stopped successfully : " + hostname + "_" + appsid + "_" + seq_no )

except Exception as e:
	if str(e) == "list index out of range":
		print "WRPDBSTOP_MSSQL:F:GERR_1302:Argument/s missing for the script : " + hostname + "_" + appsid + "_" + seq_no
	else:
		print "WRPDBSTOP_MSSQL:F: " + str(e) + " : " + hostname + "_" + appsid + "_" + seq_no
		write(logfile1, str(e))
