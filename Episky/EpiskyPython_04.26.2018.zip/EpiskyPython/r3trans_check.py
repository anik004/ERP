################################################################
#  Script Name: r3trans_check.py
#  Author: Jesna Jose
#  Description: This script performs the R3trans check
################################################################


import log4erp
from log4erp import *
from sys import *
import subprocess

try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    app_sid = argv[4]
    location = argv[5]		#script location
    seq_no = argv[6]
    logfile1 = argv[7]
    logfile2 = argv[8]

    command = 'c:\\python27\\python.exe ' + location + '\wmiexec.py ' + username.strip() + ':' + password.strip() + '%' + hostname + ' "R3trans -d "'
    #print command
    write(logfile1, command)
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    write(logfile1, out)
    if "R3trans finished (0000)" in out:
        print "WRPR3TRANS:P:R3trans is successfull :" + hostname + "_" + app_sid + "_" + seq_no
        write(logfile2, "WRPR3TRANS:P:R3trans is successfull :" + hostname + "_" + app_sid + "_" + seq_no)
    else:
        print "WRPR3TRANS:F:R3trans is not successfull :" + hostname + "_" + app_sid + "_" + seq_no
        write(logfile2, "WRPR3TRANS:F:R3trans is not successfull :" + hostname + "_" + app_sid + "_" + seq_no)

except Exception as e:
    if str(e) == "list index out of range":
        print "WRPR3trans:F:GERR_1202:Argument/s missing for the script"
    else:
        print "WRPR3trans:F: " + str(e)


