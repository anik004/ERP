import log4erp
from log4erp import *
import os
import time

def ping(t_host,sid,seq_no,logfile,string):
    osname = os.name
    if osname == "nt":
        command = "ping -n 1 " + str(t_host)  # + " > /dev/null 2>&1"
        write(logfile, command)
        response = os.system(command)

    elif osname == "posix":
        command = "ping -c1 -i3 " + str(t_host) + " > /dev/null 2>&1"
        write(logfile, command)
        response = os.system(command)

    if response == 0:
        #print "PING:P: The connectivity check for Target Server is Successful : " + t_host + "_" + sid + "_" + seq_no
        write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":P: The connectivity check for Target Server is Successful : " + t_host + "_" + sid + "_" + seq_no + ":" + string + ":" + t_host + ":" + sid)
    else:
        print "SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: Please check the IP address. Unable to reach the Host : " + t_host + "_" + sid + "_" + seq_no + ":" + string + ":" + t_host + ":" + sid
        write(logfile,"SSS:" + time.strftime("%Y-%m-%d %H-%M-%S") + ":F: Please check the IP address. Unable to reach the Host : " + t_host + "_" + sid + "_" + seq_no + ":" + string + ":" + t_host + ":" + sid)
        exit()
