import paramiko
from paramiko import *

hostname = 'sapredhat01'
sudo_user = 'root'
password = 'amigo123'


client = SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect( hostname,username = sudo_user, password = password)
channel = client.invoke_shell()



command = 'echo "su - qrpadm -c \'which disp+work\'" | sudo bash'
print command
stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
print stdout.readlines()
