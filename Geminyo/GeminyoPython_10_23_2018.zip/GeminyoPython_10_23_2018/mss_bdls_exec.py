# ---------------------------------- Import Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import subprocess
from subprocess import *
from time import strftime
from datetime import datetime
import time

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('\\')
    clientname = argv[12]
    profile_path = argv[13].rstrip('\\')

    write(refid + '_BDLS_detailed.log', "BDLS execution : " + refid + " starting at " + strftime("%Y-%m-%d %H:%M "))
    starttime = strftime("%H:%M:%S")

#-------------------------Find instance name -----------------------------
    command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -L"'
    print command
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    out = out.split()
    for each in out:
        if hostname in each:
            servername = each.strip()
    print servername

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '\\bdls.txt')
    row_top = file.readlines()
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, dbuser, dbpasswd, dbname, clientname):
        # ------------------------------- Get table column names ---------------------------------
        #tablename = table_size[row_top].strip()

        start_time = strftime("%H:%M:%S")
        rowname = tablename.split()[1]
        print rowname

        tablename = tablename.split()[0]
        file2 = open (script_loc + '/' + refid + '_BDLS_detailed.log')
        log_content = file2.read()
#       print log_content
        print tablename
        if 'POST|P|' + tablename+  ' |' in  log_content:
            return

        command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -Q \\"set nocount on;use ' + sid.upper() + ';select column_name from INFORMATION_SCHEMA.COLUMNS where table_name = \'' + tablename.strip() + '\'\\""'
        print command
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        #print out
        out = out.split('--')
        columnname = out[-1].split('\r\n')
        columnname = filter(None, columnname)
        print columnname

        # ----------------------- Put Case statement --------------------------------------
        wholecolumn = ''
        for each in columnname:
            each = each.strip()
            if each:
                #if rowname in each:
                if each.strip() + ';' in str(rowname):
                    if 'MANDT' in str(columnname):
#                       wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                        wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' and MANDT=\'" + clientname + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                    else:
                        wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                else:
                    wholecolumn = ' ' + wholecolumn + each + ','

        # --------------------------- Conversion ------------------------------------------
        command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -Q \\"use ' + sid.upper() + ';select ' + wholecolumn[:-1].strip() + ' into ' + sid.lower() + '.' + tablename + '_BDLSS from ' + sid.lower() + '.' + tablename.strip() + '\\""'
        print command
        write(refid + '_det.log', '---------------------------- backup --------------------------------')
        write(refid + '_det.log', command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        status = command.returncode
        out = out.split("\r\n")
        out = filter(None, out)
        print out[-1].strip()
        row_num = out[-1].strip()
        print row_num
        row_num = row_num.strip("(").strip(")")
        print row_num
        write(refid + '_det.log', str(out))

        # ------------------------- Rename to _OLD ---------------------------------------
        print status
        if status == 0:
            command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -Q \\"set nocount on;use ' + sid.upper() + ';drop table ' + sid.lower() + '.' + tablename.strip() + '\\""'
            print command
            write(refid + '_det.log', '---------------------------- rename to old --------------------------------')
            write(refid + '_det.log', command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            out = out.split()
            status = command.returncode
            write(refid + '_det.log', str(out))

            # ----------------- Rename _BDLS to original ------------------------------
            if status == 0:
                command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -Q \\"set nocount on;use ' + sid.upper() + ';exec sp_rename \'' + sid.lower() + '.' + tablename.strip() + '_BDLSS\', \'' + tablename.strip() + '\'\\""'
                print command
                write(refid + '_det.log','---------------------------- rename to bdls --------------------------------')
                write(refid + '_det.log', command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                out = out.split()
                status = command.returncode
                write(refid + '_det.log', str(out))
                end_time = strftime("%H:%M:%S")
                FMT = '%H:%M:%S'
                duration = datetime.strftime(end_time, FMT) - datetime.strftime(start_time, FMT)
                if status == 0:
                    print 'The conversion has been completed successfully for the table ' + tablename.strip()
                    write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed successfully for the table ' + tablename.strip())
#                   write(refid + '_BDLS_detailed.log','POST|P|' +  tablename.strip() + ' | ' + str(duration) + ' | ' + str(row_num) )
                    if len(str(row_num).split()) == 3:
                        write(refid + '_BDLS_detailed.log','\nclient: ' + clientname + " from " + oldls + " to " + newls + " Table " + tablename.strip() + ' ' + str(row_num) + ' duration ' + str(duration) + ' ')

                # ------------------------------------- ELSE -------------------------------------------------------
                else:
                    print 'The conversion has not been completed successfully for the table ' + tablename.strip() + ' with error code: 1'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
            else:
                print 'The conversion has not been completed successfully for the table ' + tablename.strip() + ' with error code: 2'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
        else:
            print 'The conversion has not been completed successfully for the table ' + tablename.strip() + ' with error code: 3'
            write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')

    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------

    # print row_top[0]

    #    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname)
    #    exit()

    threadfirst = Thread(target=exebdls,args=(row_top[0], 'first', dbuser, dbpasswd, dbname, clientname))
    threadfirst.start()
    threadsecond = Thread(target=exebdls,args=(row_top[1], 'second', dbuser, dbpasswd, dbname, clientname))
    threadsecond.start()
    threadthird = Thread(target=exebdls,args=(row_top[2], 'third', dbuser, dbpasswd, dbname, clientname))
    threadthird.start()
    threadfourth = Thread(target=exebdls,args=(row_top[3], 'fourth', dbuser, dbpasswd, dbname, clientname))
    threadfourth.start()

    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1

    for each in row_top[4:]:
        print each

        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
            if flag_first == 0:
                threadfirst = Thread(target=exebdls, args=(each, 'first', dbuser, dbpasswd, dbname, clientname))
                threadfirst.start()
                flag_first = 1
                break
            if flag_second == 0:
                threadsecond = Thread(target=exebdls, args=(each, 'second', dbuser, dbpasswd, dbname, clientname))
                threadsecond.start()
                flag_second=1
                break
            if flag_third == 0:
                threadthird = Thread(target=exebdls, args=(each, 'third', dbuser, dbpasswd, dbname, clientname))
                threadthird.start()
                flag_third=1
                break
            if flag_fourth == 0:
                threadfourth = Thread(target=exebdls, args=(each, 'fourth', dbuser, dbpasswd, dbname, clientname))
                threadfourth.start()
                flag_fourth = 1
                break

# ------------------------------is alive---------------------------------
            if threadfirst.isAlive() == False:
                flag_first = 0
                print "thread first is not alive"

            if threadsecond.isAlive() == False:
                flag_second = 0
                print "thread second  is not alive"

            if threadthird.isAlive() == False:
                flag_third = 0
                print "thread third  is not alive"

            if threadfourth.isAlive() == False:
                flag_fourth = 0
                print "thread fourth is not alive"

    print "end of first loop"
    while threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
        #  while flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:

        #       if flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
        if threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
            continue
        else:
            print "end of second loop"
            break

    print 'POST|P|The BDLS is over'
    endtime = strftime("%H:%M:%S")

    FMT = '%H:%M:%S'
    total_duration = datetime.strptime(endtime, FMT) - datetime.strptime(starttime, FMT)
    write(refid + '.log', "POST:P: " + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')
    write(refid + '_BDLS_detailed.log','\nThe BDLS is completed for ' + clientname + ' ' +  strftime("%Y-%m-%d %H:%M "))
    logf = open(refid + '_BDLS_detailed.log', 'r')
    count = 0
    logfl = logf.readlines()
    for each in logfl:
        #if "rows affected" in str(each) or "row affected" in str(each):
        if 'client: ' + clientname + " from " + oldls + " to " + newls in str(each):
            #if "0 rows affected " not in str(each):
            count = count + 1
    logf.close()
    write(refid + '_BDLS_detailed.log','\ntotal duration ' + str(total_duration))
    write(refid + '_BDLS_detailed.log', str(count)+' tables are converted for ' + clientname + ' ' )


# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))