# ------------------- importing module --------------------------
import os
import sys
from sys import *
import subprocess
import platform
import getpass

# -------------------- OS name -----------------------------------
os_name = os.name

try:
  #  if argv[1] == '--u':
#	print 'python checklist_status.py <Solman Application SID> <Solman Sudo Username> <Target hostname or IP> <Target Root username> <target Root user\'s Password> <target Sudo uername><Script Location>'
 #   else:
# ---------------------- Log4erp and paramiko --------------------
	import log4erp
	import paramiko
	from paramiko import *
	import md5
	import Crypto
	import  hashlib

# ---------------------- Variable Decalration --------------------
	app_sid = raw_input("Enter the app SID of the local system: ")
	l_user = raw_input("Enter the local system sudo username: ")
	t_host = raw_input("Enter the target hostname: ")
	t_user = raw_input("Enter the target sudo user: ")
	t_passwd = getpass.getpass("Enter the password for the target sudo user: ")
	t_sid = raw_input("Enter the appp SID for the target system: ")
	gem =  raw_input("Are you going to perform Geminyo (yes/no): ")
	epi =  raw_input("Are you going to perform episky (yes/no): ")
	l_sidadm = app_sid.lower() + 'adm'
	t_sidadm = t_sid.lower() + 'adm'

# ---------------------- Set the platform ------------------------
	if os_name == 'posix':

###################################################################
# ------------------------- for Unix -----------------------------#
###################################################################

# ------------------------- check paramiko -----------------------
		client = SSHClient()
	        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        	client.connect(t_host, username = t_user, password = t_passwd)
	        channel = client.invoke_shell()
		command = 'whoami'
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		output = stdout.readlines()
		output = ''.join(output)
		if output.strip() == t_user:
			print 'check:P:Paramiko is already installed'
		elif stderr.readlines():
			print 'check:F:Paramiko is not installed correctly and it has exited with the error: ' + str(stderr.readlines())
		else:
			print 'check:F:Paramiko is not installed correctly'

# ---------------------- check folder existance ------------------
		
		gem_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/geminyo')
		gem_path_p = '/home/' + app_sid.lower() + 'adm/geminyo'
		gem_sc_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/geminyo/scripts')
		gem_sc_path_p = '/home/' + app_sid.lower() + 'adm/geminyo/scripts'
		epi_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/episky')
		epi_path_p = '/home/' + app_sid.lower() + 'adm/episky'
		epi_sc_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/episky/scripts')
		epi_sc_path_p = '/home/' + app_sid.lower() + 'adm/episky/scripts'
		kry_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/kryptex')
		kry_path_p = '/home/' + app_sid.lower() + 'adm/kryptex'
		kry_sc_path = os.path.isdir('/home/' + app_sid.lower() + 'adm/kryptex/scripts')
		kry_sc_path_p = '/home/' + app_sid.lower() + 'adm/kryptex/scripts'
		if gem.strip() == 'yes':
			if gem_path == True and gem_sc_path == True and kry_path == True and kry_sc_path == True:
				print 'check:P:The folder strcture is created properly for Geminyo'
###################################################################################################
# ------------------ Folder permission ---------------------------
				command = 'stat -c %a ' + gem_path_p
		        	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        			out_gem_path, err = command.communicate()
				command = 'stat -c %a ' + gem_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_gem_sc_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_kry_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_kry_sc_path, err = command.communicate()
				if out_gem_path.strip() != '777' or out_gem_sc_path.strip() != '777' or out_kry_path.strip() != '777' or out_kry_sc_path.strip() != '777':
					print 'check:F:The permission of the script location is not 777'
				else:
					print 'check:P:The permission for the script location is proper'
######################################################################################################
		elif epi.strip() == 'yes':
                        if epi_path == True and epi_sc_path == True and kry_path == True and kry_sc_path == True:
                                print 'check:P:The folder strcture created properly for Episky'
######################################################################################################
# ------------------ Folder permission ---------------------------
                                command = 'stat -c %a ' + epi_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_epi_path, err = command.communicate()
                                command = 'stat -c %a ' + epi_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_epi_sc_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_kry_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_gem_sc_path, err = command.communicate()
                                if out_epi_path.strip() != '777' or out_epi_sc_path.strip() != '777' or out_kry_path.strip() != '777' or out_gem_sc_path.strip() != '777':
                                        print 'check:F:The permission of the script location is not 777'
                                else:
                                        print 'check:P:The permission for the script location is proper'
		elif epi.strip() == 'yes' and gem.strip() == 'yes':
				command = 'stat -c %a ' + epi_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_epi_path, err = command.communicate()
                                command = 'stat -c %a ' + epi_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_epi_sc_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_kry_path, err = command.communicate()
                                command = 'stat -c %a ' + kry_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_kry_sc_path, err = command.communicate()
				command = 'stat -c %a ' + gem_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_gem_path, err = command.communicate()
                                command = 'stat -c %a ' + gem_sc_path_p
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out_gem_sc_path, err = command.communicate()
				if out_epi_path.strip() != '777' or out_epi_sc_path.strip() != '777' or out_kry_path.strip() != '777' or out_kry_sc_path.strip() != '777' or out_gem_sc_path.strip() != '777' or out_gem_path.strip() != '777':
                                        print 'check:F:The permission of the script location is not 777'
                                else:
                                        print 'check:P:The permission for the script location is proper'
########################################################################################################
		else:
			print 'check:F:The folder structure has not been created properly'

# --------------------- connectivity check -----------------------
		command = "ping -c1 -i3 " + str(t_host) + " > /dev/null 2>&1"
                response = os.system(command)
		if response == 0:
			print "check:P:The connectivity check for Target Server (Hostname: " + t_host + ") is Successful"
		else:
			print "check:F:Please check the IP address, Unable to reach the Host (Hostname: " + t_host + ")"

# ---------------- local check sudo access ------------------------
		command = 'sudo su - ' + l_sidadm + ' -c "whoami"'
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
		if out.strip() == l_sidadm:
			print 'check:P:Sudo access check to for sudo user ' + l_user + ' is Successful on SOLMAN system'
		elif err:
			print 'check:F:Sudo access check to for sudo user ' + l_user + ' has failed on SOLMAN system with the error: ' + str(err)
		else:
			print 'check:F:Sudo access check to for sudo user ' + l_user + ' has failed on SOLMAN system'

# -------------------  check sudo access -------------------------
		command = 'sudo su - ' + t_sidadm + ' -c "whoami"'
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		output = ''.join(stdout.readlines())
                if output.strip() == t_sidadm:
			print 'check:P:Sudo access check to for sudo user ' + t_user + ' is Successful on target system'
		else:
			print 'check:F:Sudo access check to for sudo user ' + t_user + ' has failed on target system'

# ------------------------ Python version -------------------------
	        req_version = (2.7)
	        cur_version = sys.version

        	if str(req_version) in str(cur_version):
			print 'check:P:The installed python is having proper  version'
		else:
			print 'check:F:The installed python version is lesser that 2.7'

# ------------------------ Home Directory check -------------------
		command = 'sudo su - ' + t_sidadm + ' -c "getent passwd \\"' + t_sidadm + '\\""'
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                output = str(stdout.readlines()).split(':')
		if output:
			print 'check:P:The user ' + t_sidadm + ' has proper home folder'
		else:
			print 'check:F:The user ' + t_sidadm + ' does not have proper home folder'

# -------------------------- OS version check ----------------------
	        os_name = platform.system()
	        os_version = platform.release()
	        version = float(os_version.split('-')[0].split('.')[0] + '.' + os_version.split('-')[0].split('.')[1])
		if os_name == 'AIX' and version > 6.1:
			print 'check:F:The check has failed as the OS version is AIX and the version is greater than 6.1'
		else:
			print 'check:P:the OS check has been passed'

		if gem.strip() == 'yes':
#-------------------------- DIR_TRANS value -------------------------
			command = 'cd /sapmnt/' + t_sid.upper() + '/profile'
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			stdout = stdout.read()
			if "No such file or directory" not in stdout:
#			folder_exist = os.path.isdir('/sapmnt/' + app_sid.upper() + '/profile')
#	        	if folder_exist == True:
	                	profile_path = ' /sapmnt/' + t_sid.upper() + '/profile'
	        	        command = 'ls -l /sapmnt/' + t_sid.upper() + '/profile | grep -i ' + t_sid.upper() + '_D00'
		                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        		        profile = stdout.readlines()[0].split()[8].strip()
                		command = 'sudo cat ' + profile_path + '/'  + profile + ' | grep -i DIR_TRANS'
		                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        		        stdout = stdout.readlines()#[0].split()[8].strip()i
	                	if stdout:
	                        	print 'check:P:The DIR_TRANS entry is present in the instance profile'
	                	else:
	                        	print 'check:F:The DIR_TRANS entry is not present in the instance profile'

#----------------------- trans local or shared -----------------------
				profile_path = '/sapmnt/' + t_sid.upper() + '/profile'
			        command = 'ls -l /sapmnt/' + t_sid.upper() + '/profile | grep -i ' + t_sid.upper() + '_D00'
	        		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		        	profile = stdout.readlines()[0].split()[8].strip()
		        	command = 'sudo cat ' + profile_path + '/'  + profile + ' | grep -i DIR_TRANS | grep -v "#"'
			        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        		out = stdout.readlines()
				if out:
			        	file_path = str(str(str(str(out).split('=')[1])[:-2].strip()).replace('\\r\\n', ''))
	        			if '\\\\' in file_path[:2]:
	                			print 'check:F:The trans directory is not local'

			       		else:
	        		        	print 'check:P:The trans directory is local'
	        	else:
	                	print 'check:F:The profile folder does not exist on /sapmnt mountpoint'

#------------------------ TP profile --------------------------------
			trans_fol = "/usr/sap/trans/bin"

			command = 'sudo ls ' + trans_fol
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			stdout = (stdout.read()).split()

			prof = "TP_DOMAIN_" + t_sid.upper() + ".PFL"
			flag = 0

			for each in stdout:
			        if prof in each.strip():
			                command = 'sudo cat ' + trans_fol + '/' + each + ' | grep -i -e DIR_TRANS -e transdir | grep -v "#"'
					stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			                stdout = stdout.readlines()
			                flag = 1
			                if stdout:
			                        print 'check:P:The TRANSDIR entry is present in the TP profile'
			                else:
	                       			print 'check:F:The TRANSDIR entry is not present in the TP profile'

			if flag == 0:
			        print 'check:F:STMS is not configured'

	else:
###################################################################
# ----------------------------- for windows ----------------------#
###################################################################
# ---------------------- Script location -------------------------
#		import Crypto
		location = raw_input("Enter the script location: ")
		prof_drive = raw_input("Enter the profile drive: ")
# ----------------------- check folder existance -----------------
		gem_path = os.path.isdir(location + '\\geminyo')
		gem_sc_path = os.path.isdir(location + '\\geminyo\\scripts')
                epi_path = os.path.isdir(location + '\\episky')
                epi_sc_path = os.path.isdir(location + '\\episky\\scripts')
		kry_path = os.path.isdir(location + '\\kryptex')
                kry_sc_path = os.path.isdir(location + '\\kryptex\\scripts')
#		gem_path = os.path.isdir('c:\\' + app_sid + 'adm\\geminyo')
#                gem_sc_path = os.path.isdir('c:\\' + app_sid + 'adm\\geminyo\\scripts')
#                epi_path = os.path.isdir('c:\\' + app_sid + 'adm\\episky')
#                epi_sc_path = os.path.isdir('c:\\' + app_sid + 'adm\\episky\\scripts')

		if gem.strip() == "yes":
			location = location + '\\geminyo\\scripts'
			if gem_path == False or gem_sc_path == False or kry_path == False or kry_sc_path == False:
	                        print 'check:F:The folder strcture is not created properly'
        	        else:
                	        print 'check:P:The folder structure has been created properly'

		if epi.strip() == "yes":
			location = location + '\\episky\\scripts'
	                if epi_path == False or epi_sc_path == False or kry_path == False or kry_sc_path == False:
        	                print 'check:F:The folder strcture is not created properly'
                	else:
                        	print 'check:P:The folder structure has been created properly'

# ----------------------------- connectivity check --------------
		command = "ping -n 1 " + str(t_host) #+ " > /dev/null 2>&1"
                response = os.system(command)
		if response == 0:
                        print "check:P:The connectivity check for Target Server (Hostname: " + t_host + ") is Successful"
                else:
                        print "check:F:Please check the IP address, Unable to reach the Host (Hostname: " + t_host + ")"
# ------------------------------- Impacket ----------------------
		command = 'c:\python27\python ' + location.strip('\\') + '\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host + ' "exit"'
		response = os.system (command)
		if response == 0:
			print 'check:P:The impacket installation check in the solman system is successful'
		else:
			print 'check:F:The impacket installation check in the solman system is failed'
# ------------------------ Python version -------------------------
                req_version = (2.7)
                cur_version = sys.version

                if str(req_version) in str(cur_version):
                        print 'check:P:The installed python is having proper  version'
                else:
                        print 'check:F:The installed python version is lesser that 2.7'


		if gem.strip() == 'yes':
#-------------------------- DIR_TRANS value -------------------------
			profile_path = prof_drive + '\\sapmnt\\' + app_sid.upper() + '\\SYS\\profile'
			command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host +  ' \" dir ' + profile_path + '\"'
#			print  command
	                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	                out, err = command.communicate()
			if "File Not Found" not in out:
		        	command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host +  ' \" dir ' + profile_path + ' |  findstr ' + app_sid.upper() + '_DVEBMGS\"'
#				print  command
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			        out, err = command.communicate()
			        out = (out.strip()).split('\n')
		        	for each in out:
		               		b = t_host + "."
			                if b not in each:
	               			        each = each.split(" ")
		                	        each = filter(None,each)
	               		        	if len(each) == 5:
		                               		each = each[4]
			                                each = str(each).strip()
	               			                command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host +  ' \" type ' + profile_path + '\\' + each +'|  findstr " DIR_TRANS\"'
		                	                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	               		        	        out, err = command.communicate()
	                               			if out:
			                                        print 'check:P:The DIR_TRANS entry is present in the instance profile'
	        	       		                else:
	                	               		        print 'check:F:The DIR_TRANS entry is not present in the instance profile'
#----------------------- trans local or shared -----------------------
			        command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host +  ' \" dir ' + profile_path + ' |  findstr ' + app_sid.upper() + '_DVEBMGS\"'
#			        print  command
	        		command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			        out, err = command.communicate()
	        		out = (out.strip()).split('\n')
		        	for each in out:
	        	        	b = t_host + "."
		                	if b not in each:
	        	                	each = each.split(" ")
		        	                each = filter(None,each)
	        	        	        if len(each) == 5:
	                	        	        each = each[4]
	                        	        	each = str(each).strip()
		                                	command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host + ' \" type ' + profile_path + '\\' + each +'|  findstr " DIR_TRANS " | findstr -V "#\"'
			                                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	        		                        out, err = command.communicate()
	                		                #print out
	                                		file_path = out.split("=")[1].strip()
		                                	#print out
		        	                        #file_path = str(str(str(str(out).split('=')[1])[:-2].strip()).replace('\\r\\n', ''))
	        	        	                #print file_path
	                	        	        if '\\\\' in file_path[:2]:
	                        	        	        print 'check:P:The TRANS is shared'
		                        	        else:
	        	                        	        print 'check:P:The TRANS is local'
			else:
        	                print 'check:F:The profile folder does not exist on /sapmnt mountpoint'

#------------------------ TP profile --------------------------------
			trans_fol = prof_drive + "\\usr\\sap\\trans\\bin"

			command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host + '\"dir ' + prof_drive + '\"'
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			out, err = command.communicate()
			out = (out.strip()).split("\n")
#			print out

			prof = "TP_DOMAIN_" + t_sid + ".PFL"
			flag = 0

			for each in out:
			        if prof in each:
#	                		print each
			                each = (each.strip()).split()
	                		each = each[4]
			                command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + t_user.strip() + ':' + t_passwd.strip() + '@' + t_host + '\"type ' + trans_fol + '/' + each + ' | findstr "TRANSDIR DIR_TRANS" | findstr /v "#" \"'
	                		command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
			                out, err = command.communicate()
	                		flag = 1

			                if out:
	                		        print 'check:P:The TRANSDIR entry is present in the TP profile'
			                else:
	                		        print 'check:F:The TRANSDIR entry is not present in the TP profile'

			if flag == 0:
			        print 'check:F:STMS is not configured'


# ------------------------------- Exceptions --------------------
except Exception as e:
	exc_type, exc_obj, tb = sys.exc_info()
	lineno = str(tb.tb_lineno)
	if str(e) == 'No module named log4erp':
		print 'check:F:The module "log4erp" does not exist in the solam system'
	if str(e) == 'No module named hashlib':
                print 'check:F:The module "hashlib" does not exist in the solam system'
	if str(e) == 'No module named md5':
                print 'check:F:The module "md5" does not exist in the solam system'
	if str(e) == 'No module named crypto':
                print 'check:F:The module "PyCrypto" does not exist in the solam system'
	if str(e) == 'No module named paramiko':
                print 'check:F:The module "paramiko" does not exist in the solam system'
	if str(e) == 'Name or service not known':
		print 'check:F:The hostname or IP is not rechable'
	else:
		print 'check:F:' + str(e) + ':' + lineno
