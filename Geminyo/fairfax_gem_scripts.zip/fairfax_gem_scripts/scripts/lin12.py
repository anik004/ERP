print 'PRE:W:The database type "DB2" is not supported'
