import subprocess
from os import *
from sys import *
from subprocess import *
from log4erp import *


hostname = argv[1]
username = argv[2]
password = argv[3]
app_sid = argv[4]
instance = argv[5]
host = argv[6]
logfile= argv[7] + ".log"
profile_path = argv[8].rstrip('/')

s_path = argv[9]
tr_id = argv[10]
t_path = argv[11]
domain = argv[12].upper()
tr_part = tr_id[4:]
sid = app_sid.upper()
s_sid = argv[13].upper()

path = argv[14]
client_name= argv[15]
step_name = argv[16]


command = 'python ' + path.rstrip('/') + '/lin20 ' + s_path + ' ' + tr_id + ' ' + t_path + ' ' + hostname + ' ' + app_sid + ' ' + domain + ' ' + username + ' ' + password + ' ' + s_sid + ' ' + logfile + ' ' + profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.strip('\\').rstrip('/') + '/lin19 ' + hostname + ' ' + username + ' ' + password + ' ' + client_name + ' ' + step_name + ' ' + app_sid + ' ' + logfile + ' ' + path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.strip('\\') + '/lin17 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + instance + ' ' + logfile + ' ' + host + ' ' +  profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + scr + '/lin23 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + profile_path
print command
write('reflogfile.log',command)
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

print "PRE-REFRESH COMPLETED"


