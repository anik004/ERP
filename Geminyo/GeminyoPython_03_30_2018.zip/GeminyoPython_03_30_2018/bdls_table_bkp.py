# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    #hostname = '10.213.63.29'
    #username = 'cgngupta'
    #password = 'B9526em27'
    #sidadm = 'tstadm'

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = str(sid.strip()) + 'adm'
    sidadm = sidadm.lower()


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -ibdls.sql\\\"" | sudo bash'
    print command
    #command = 'echo "su - ' + sidadm + ' -c \\\"isql -USAPSR3 -PNetra0001 -STST -w9999 -ibdls.sql\\\"" | sudo bash'
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()
#    print out
#    file = open("tst.txt", "w+")
#    file.write(str(out).split('\n'))
#    file.close
    os.remove (script_loc +'/bdls.txt')
    # --------------------------- Get number of rows ----------------------------------------
    print out[:-2]
    exit()
    for each in out[:-2]:
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each:
            continue
        else:
            tablename = each.strip()
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + tablename.split(' ')[0] + '\'\r\ngo\\\\\\\" > table.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable.sql\\\"" | sudo bash'
	    print command
            #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable.sql\\\"" | sudo bash'
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
	    print out
            rowcount = int(out[3].split()[1])
            table_size[rowcount] = each
            print str(rowcount) + ' : ' + str(each)
    row_top = sorted(table_size, reverse=True)
#    row_top = row[0:16]
    print row_top

    for rownumber in row_top:
            tablename = table_size[rownumber].strip()
	    print 'POST:P:' + tablename  + ':' + rownumber
	    file = open(script_loc +'/bdls.txt', 'a')
	    file.write(tablename + str(rowcount) + '\n')
	    file.close()

    # ------------------------------- Close connection -----------------------------------------
    channel.close()
    client.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
