# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime
from datetime import datetime

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    clientname = argv[12]
    sidadm = str(sid.strip()).lower() + 'adm'


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    """
    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -ibdls.sql\\\"" | sudo bash'
    #command = 'echo "su - ' + sidadm + ' -c \\\"isql -USAPSR3 -PNetra0001 -STST -w9999 -ibdls.sql\\\"" | sudo bash'
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()

    # --------------------------- Get number of rows ----------------------------------------
    for each in out[:-2]:
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each or SWWWIHEAD in each:
            continue
        else:
           each = each.strip()
           command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
            #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table' + num + '.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable' + num + '.sql\\\"" | sudo bash'
           stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
           out = stdout.readlines()
           rowcount = int(out[3].split()[1])
           table_size[rowcount] = each
            #print str(rowcount) + ' : ' + str(each)
    row = sorted(table_size, reverse=True)
    row_top = row[0:16]
    """

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls.txt')
    row_top = file.readlines()
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname, clientname):
        # ------------------------------- Get table column names ---------------------------------
            #tablename = table_size[row_top].strip()
	    start_time = strftime("%H:%M:%S")
	    rowname = tablename.split()[1]
	    tablename = tablename.split()[0]
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select TOP 1 * from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            columnname = out[1]
	    print columnname
            # ----------------------- Put Case statement --------------------------------------
            wholecolumn = ''
            for each in columnname.split():

		      if rowname in each:
#                    	    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
        	            wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' and MANDT=\'" + clientname + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
	      	      else:
                    	    wholecolumn = ' ' + wholecolumn + each + ','
            # --------------------------- Conversion ------------------------------------------
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select ' + wholecolumn[:-1].strip() + ' into ' + tablename + '_BDLSS from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
            print command
	    write(refid + '_det.log', '---------------------------- backup --------------------------------')
	    write(refid + '_det.log', command)
	    exit()
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
	    row_num = out[-1].strip() 
	    row_num = row_num.strip("(").strip(")")
	    #print "row_num = " + row_num
            status = stdout.channel.recv_exit_status()
            write(refid + '_det.log', out)
	    
            # ------------------------- Rename to _OLD ---------------------------------------
            print status
            if status == 0:
                command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"drop table ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
                write(refid + '_det.log', '---------------------------- rename to old --------------------------------')
	        write(refid + '_det.log', command)
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                out = stdout.readlines()
                status = stdout.channel.recv_exit_status()
                write(refid + '_det.log', out)
		print out

                # ----------------- Rename _BDLS to original ------------------------------
                if status == 0:
                    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + '_BDLSS,' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
                    write(refid + '_det.log', '---------------------------- rename to bdls --------------------------------')
		    write(refid + '_det.log', command)
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                    out = stdout.readlines()
		    print "sp_rename"
		    print out
                    status = stdout.channel.recv_exit_status()
                    write(refid + '_det.log', out)
		    end_time = strftime("%H:%M:%S")
		    FMT = '%H:%M:%S'
	            duration = datetime.strptime(end_time, FMT) - datetime.strptime(start_time, FMT)
		    print duration
                    if status == 0:
                        print 'The conversion has been completed succesfully for the table ' + tablename.strip()
                        write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())
		        write(refid + '_BDLS_detailed.log','POST:P:' +  tablename.strip() + ' | ' + str(duration) + ' | ' + str(row_num) )

                    # ------------------------------------- ELSE -------------------------------------------------------
                    else:
                        print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
                else:
                    print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 2'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
            else:
                print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')


    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------

    #print row_top[0]
    
#    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname)
#    exit()

    threadfirst = Thread(target=exebdls, args=(row_top[0], 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfirst.start()
    exit()
    threadsecond = Thread(target=exebdls, args=(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadsecond.start()
    threadthird = Thread(target=exebdls, args=(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadthird.start()
    threadfourth = Thread(target=exebdls, args=(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfourth.start()



#    threadfive = Thread(target=exebdls, args=(row_top[4], 'five', sidadm, dbuser, dbpasswd, dbname))
#    threadfive.start()
#    threadsix = Thread(target=exebdls, args=(row_top[5], 'six', sidadm, dbuser, dbpasswd, dbname))
#    threadsix.start()

    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1
#    flag_five = 1
#    flag_six = 1

    for each in row_top:

        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
                if flag_first == 0:
                        threadfirst = Thread(target=exebdls, args=(each, 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfirst.start()
                        flag_first = 1
			print "Assigning thread first with " + str(each)
			break
		if flag_second == 0:
			threadsecond = Thread(target=exebdls, args=(each, 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadsecond.start()
			flag_second=1
			print "Assigning thread second with " + str(each)
			break
		if flag_third == 0:
			threadthird = Thread(target=exebdls, args=(each, 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadthird.start()
			flag_third=1
			print "Assigning thread third with " + str(each)
			break
		if flag_fourth == 0:
			threadfourth = Thread(target=exebdls, args=(each, 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfourth.start()
			flag_fourth = 1
			print "Assigning thread fourth with " + str(each)
			break

#		if flag_five == 0 :
#			threadfive = Thread(target=exebdls, args=(row_top[4], 'five', sidadm, dbuser, dbpasswd, dbname))
#			threadfive.start()
#			flag_five = 1
#			print "Assigning thread five with " + str(each)
#			break

#		if flag_six == 0:
#			threadsix = Thread(target=exebdls, args=(row_top[5], 'six', sidadm, dbuser, dbpasswd, dbname))
#			threadsix.start()
#			flag_six = 1
#			print "Assigning thread six with " + str(each)
#			break 


#------------------------------is alive---------------------------------
		if threadfirst.isAlive() == False:
			flag_first = 0
			print "thread first is not alive"

		if threadsecond.isAlive() == False:
			flag_second=0
			print "thread second  is not alive"
		
		if threadthird.isAlive() == False:
			flag_third = 0
			print "thread third  is not alive"

		if threadfourth.isAlive() == False:
                        flag_fourth = 0
			print "thread fourth is not alive"

#		if threadfive.isAlive() == False:
#			flag_five = 0
#			print "thread fifth is not alive"
#		if threadsix.isAlive() == False:
#			flag_six = 0
#			print "thread six  is not alive"

		

#    for each in range (0, len(row_top), 4):
#        threadfirst = Thread(target=exebdls, args=(row_top[each], 'first', sidadm, dbuser, dbpasswd, dbname))
#	threadfirst.start()
#        threadsecond = Thread(target=exebdls, args=(row_top[each + 1], 'second', sidadm, dbuser, dbpasswd, dbname))
#	threadsecond.start()
#        threadthird = Thread(target=exebdls, args=(row_top[each + 2], 'third', sidadm, dbuser, dbpasswd, dbname))
#	threadthird.start()
#        threadfourth = Thread(target=exebdls, args=(row_top[each + 3], 'fourth', sidadm, dbuser, dbpasswd, dbname))
#	threadfourth.start()
	#exebdls(each, table_size, sidadm, dbuser, dbpasswd, dbname)

        # ------------------ check thread status ------------------------------------------
#        flag = True
#        while flag == True:
#            if threadfirst.isAlive() == True or threadsecond.isAlive() == True or threadthird.isAlive() == True or threadfourth.isAlive() == True:
#                flag = True
#	    else:
#		flag = False

    while flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
		if flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
			continue
		else:
			exit()


    print 'POST:P: The BDLS is over'
   

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
