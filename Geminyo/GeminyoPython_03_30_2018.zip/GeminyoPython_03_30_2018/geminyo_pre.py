import subprocess
from os import *
from sys import *
from subprocess import *
from log4erp import *


sapredhat01 = argv[1]
root = argv[2]
amimgo123 = argv[3]
app_sid = argv[4]
instance = argv[5]
host = argv[6]
logfile= argv[7] + ".log"
profile_path = argv[8].rstrip('/')

s_path = argv[9]
tr_id = argv[10]
t_path = argv[11]
domain = argv[12].upper()
tr_part = tr_id[4:]
sid = app_sid.upper()
s_sid = argv[13].upper()

path = argv[14]
client_name= argv[15]
step_name = argv[16]

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin20 /usr/sap/trans_SO SOLK900620 /usr/sap/trans sapredhat01 QRP DOMAIN_QRP root amigo123 SOL trail /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin19 sapredhat01 root amimgo123 000 PRE_TLOCK QRP trail '
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.strip('\\') + '/lin17 ' + sapredhat01 + ' ' + root + ' ' + amimgo123 + ' ' + app_sid + ' ' + instance + ' ' + logfile + ' ' + host + ' ' +  profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin23 ' + sapredhat01 + ' ' + root + ' ' + amimgo123 + ' ' + app_sid + ' ' + profile_path
print command
write('reflogfile.log',command)
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

print "PRE-REFRESH COMPLETED"


