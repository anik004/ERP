import subprocess
from os import *
from sys import *
from subprocess import *
from log4erp import *

command = 'python ' + path + '/lin32 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin25 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.rstrip('/') + '/lin26 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + clientname + ' ' + path + ' ' + db_user + ' ' + db_passwd + ' ' + db_type
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin33 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + inst_no + ' ' + inst_nm + ' ' + ref_id + ' ' +  profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin28 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + inst_no + ' ' + inst_nm + ' ' + ref_id + ' ' +  profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.rstrip('/') + '/lin20 ' + s_path + ' ' + tr_id + ' ' + t_path + ' ' + t_host + ' ' + t_sid + ' ' + dom + ' ' + t_user + ' ' + t_passwd + ' ' + s_sid + ' ' + ref_id + ' ' + profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin27 ' + s_path + ' ' + tr_id + ' ' + t_path + ' ' + t_host + ' ' + t_sid + ' ' + dom + ' ' + t_user + ' ' + t_passwd + ' ' + s_sid + ' ' + ref_id + ' ' + client + ' ' + t_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path.rstrip('/') + '/lin18 ' + hostname + ' ' + username + ' ' + password + ' ' + client_name + ' ' + step_name + ' ' + appsid + ' ' + logfile + ' ' + drive.rstrip('/')
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path + '/lin22 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python ' + path  + '/lin24 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out


command = 'python ' + path + '/lin33 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + inst_no + ' ' + inst_nm + ' ' + ref_id + ' ' +  profile_path
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

print 'POST-REFRESH COMPLETED'


