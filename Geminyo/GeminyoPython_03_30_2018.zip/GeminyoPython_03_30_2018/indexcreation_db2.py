from paramiko import *
import paramiko
from sys import *
import re
import subprocess

#from log4erp import *
try:

	hostname = argv[1]
        username = argv[2]
        password = argv[3]
        database_sid=argv[4].strip()
        db_user = argv[5]
        db_password = argv[6]
        path = argv[7]
        ref_id = argv[8]

	user = "db2" + database_sid.lower()
	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()
	
	file3=open(path + "/sapschema.sql","w+")
        file3.write('connect to ' + database_sid.upper() + ';\n')
        file3.write('select tabschema from syscat.tables where tabname = \'SVERS\';')
        file3.close()

        port = 22
        remote1= '/tmp/sapschema.sql'
        print remote1
        local1 = path + '/sapschema.sql'
        print local1

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local1, remote1)


        command = 'echo "su - ' + user + ' -c"\'"db2 -tvmf /tmp/sapschema.sql"\'\'| grep -i "SAP"\'| sudo bash'
        print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        schema = stdout.read().strip()
        schema = str(schema)
        print schema

	
        file1=open(path.rstrip('/') + "/indextable.sql","w+")
	file1.write('connect to ' +  database_sid + ';\n')
	file1.write('select ' + schema + '.DD03L.tabname, ' + schema + '.DD03L.fieldname from ' + schema + '.DD03L inner join ' + schema + '.DD02L on ' + schema + '.DD02L.tabname = ' + schema + '.DD03L.tabname where ( ' + schema + '.DD03L.domname IN ( \'LOGSYS\' , \'EDI_PARNUM\' , \'ADDRLOGSYS\' )) and ' + schema + '.DD02L.tabclass = \'TRANSP\';\n')
	file1.close()

	port = 22

	remote= '/tmp/indextable.sql'
        print remote
        local= path + '/indextable.sql'
        print local

	transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)

#	command = "sudo su - " + user + " -c\"db2 -tvmf indextable.sql\""
	command = 'echo "su - ' + user + ' -c "\'"db2 -tvmf /tmp/indextable.sql"\'| sudo bash '
	print command
	
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	out = (stdout.read()).strip()
#	print out
#	exit()
	status = stdout.channel.recv_exit_status()

	out = out.split("FIELDNAME")[1].split('\n')
	file2=open("index.sql","w+")
	file2.write('connect to ' +  database_sid + ';\n')
	for i in out:
		if not '--' in i.strip() and "selected" not in i.strip():
			if i.strip():
			
				table_field = i.split()[-1]
				table_name = i.split()[0]

				file2.write('CREATE INDEX '+ table_name + '_' + table_field + ' on ' + schema + '.' + table_name + '(' + table_field + ');\n')
	print table_field


		
	file2.close()
	port = 22
	
	remote= '/tmp/index.sql'
        print remote
        local= path + '/index.sql'
        print local
	
	transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)

#	command = "sudo su - " + user + " -c\"db2 -tvmf index.sql\""
	command = 'echo "su - ' + user + ' -c "\'"db2 -tvmf /tmp/index.sql"\'| sudo bash '
        print command
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	out = stdout.readlines()
	print out

	if out:
		print "PRE:P:Index created successfully"
	else:
		print "PRE:F:Index created failed"

	sftp.close()
        transport.close()
        channel.close()
        client.close()
except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
                print "PRE:F:GERR_0201:Hostname unknown"
        elif str(e).strip() == "list index out of range":
                print "PRE:F:GERR_0202:Argument/s missing for the script"
        elif str(e) == "Authentication failed.":
                print "PRE:F:GERR_0203:Authentication failed for the " + string + " system " + hostname + " for user " + sudo_user
        elif str(e) == "[Errno 110] Connection timed out":
                print "PRE:F:GERR_0204:Host Unreachable"
        elif "getaddrinfo failed" in str(e):
                print "PRE:F:GERR_0205: Please check the hostname that you have provide"
        elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
        else:
                print "PRE:F: " + str(e)
