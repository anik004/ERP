################################################################
#  Script Name: win28.py
#  Author: Anik Chanda
#  Description: check if CUA is active or not
################################################################
# Embedded file name: win28.py
from sys import argv
import subprocess
import os
try:
    if argv[1] == '--ani':
        print 'usage'
    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        sid = argv[4]
        location = argv[5].strip('\\')
        logfile = argv[6]
        stepname = argv[7]
        command = 'c:\\python27\\python.exe ' + location.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname.strip() + ' "hostname"'
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        domain_name = out.split('\n')[3]
        command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sqlcmd -E -S ' + domain_name.strip() + '\\' + sid.upper() + ' -Q \\"use ' + sid.upper() + '; select  TOP 1 TABLE_SCHEMA from INFORMATION_SCHEMA.TABLES\\""'
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        schema = out.split('\n')[5].strip()
        if schema:
            command = 'c:\\python27\\python ' + location.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + ' "sqlcmd -E -S ' + domain_name.strip() + '\\' + sid.upper() + ' -Q \\"use ' + sid.upper() + '; select CUAMON from ' + schema + '.USBAPILINK\\""'
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            cua = out.split('\n')[5].strip()
            if cua == '':
                print stepname + ':P:CUA is inactive'
            else:
                print stepname + ':F:CUA is active'
except Exception as e:
    if str(e) == '[Errno -2] Name or service not known':
        print 'PRE:F:GERR_0201:Hostname unknown'
    elif str(e).strip() == 'list index out of range':
        print 'PRE:F:GERR_0202:Argument/s missing for the script'
    elif str(e) == 'Authentication failed.':
        print 'PRE:F:GERR_0203:Authentication failed.'
    elif str(e) == '[Errno 110] Connection timed out':
        print 'PRE:F:GERR_0204:Host Unreachable'
    elif 'getaddrinfo failed' in str(e):
        print 'PRE:F:GERR_0205: Please check the hostname that you have provide'
    elif '[Errno None] Unable to connect to port 22' in str(e):
        print 'PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22'
    else:
        print 'PRE:F: ' + str(e)
