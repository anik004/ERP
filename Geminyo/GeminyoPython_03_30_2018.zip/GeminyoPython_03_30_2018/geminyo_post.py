import subprocess
from os import *
from sys import *
from subprocess import *
from log4erp import *

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin32 sapredhat01 root amigo123 QRP /sapmnt/QRP/profile'
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin25 sapredhat01 root amigo123 QRP /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin26 sapredhat01 root amigo123 QRP 000 /home/soladm/gem/geminyo/final/final_script_geminyo_all system Welcome2 ORA'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin33 sapredhat01 root amigo123 QRP 00 sapredhat01 trail /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python  /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin28 sapredhat01 root amigo123 /usr/sap/QRP/SYS/exe/uc/linuxx86_64 /home/soladm/gem/geminyo/final/final_script_geminyo_all abc_license.txt /sapmnt/QRP/profile QRP'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out
command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin20 /usr/sap/trans_SO SOLK900620 /usr/sap/trans sapredhat01 QRP DOMAIN_QRP root amigo123 SOL trail /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin27 /usr/sap/trans_SO SOLK900620 /usr/sap/trans sapredhat01 QRP DOMAIN_QRP root amigo123 SOL trail 000 /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin18  sapredhat01 root amigo123 000 PRE_TLOCK QRP trail /home/soladm/gem/geminyo/final/final_script_geminyo_all'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin22 sapredhat01  root amigo123 QRP /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

command = 'python  /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin24 sapredhat01 root amigo123 QRP /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out


command = 'python /home/soladm/gem/geminyo/final/final_script_geminyo_all/lin33 sapredhat01 root amigo123 QRP 00 sapredhat01 trail /sapmnt/QRP/profile'
print command
command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

print 'POST-REFRESH COMPLETED'


