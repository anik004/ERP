# Embedded file name: win08.py
print 'PRE:F:Script does not exist'