import os
import sys
import subprocess

command = 'ls'
command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()

for each in out.split('\n'):
	if each != 'wmiexec.py' and each != 'log4erp.pyc' and each != '' and each != 'encr.py' and '.py' in each:
		command = 'cxfreeze --no-copy-deps ' + each
		print command
		command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
		out, err = command.communicate()
