from log4erp import *
from os import path
import os
from os import getcwd
from sys import *
import sys
import subprocess

try:

	# ----------------------- Variable declaration -------------------------------------------
	s_path = argv[1]
        tr_id = argv[2]
	t_sid = argv[3]
	clientname = '000'
	domain = argv[4]

	# ------------------- Check TRANS DIR Existance ------------------------------------------
	existance = os.path.isdir(s_path)
	if existance != True:
		print 'Import:F: The provided path does not exist'
		exit()

	# ----------------------- Check co and data file existence -------------------------------
	tr_number = tr_id[4:] + '.SOL'
	cofile = str(os.getcwd()) + '/K' + tr_number
	datafile = str(os.getcwd()) + '/R' + tr_number
	existance = ''
	existance = str(os.path.isfile(cofile)) + ' ' + str(os.path.isfile(datafile))
	if 'False' in existance:
		print 'Import:F: TRs are not present in the current working directory'
		exit()

	# -------------------------- Copy TRs to Target ---------------------------------------------
	tr_number = tr_id[4:] + '.SOL'
	command = 'cp -rpf ' + cofile + ' ' + s_path + '/cofiles/; cp -rpf ' + datafile + ' ' + s_path + '/data/'
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        status = command.returncode
        if status != 0:
		print 'Import:F: File transfer has failed with status code: ' + str(status)
		exit()
	else:

	# -------------------------- Permission to TRs ---------------------------------------------
        	command = 'echo \'chown ' + t_sid.lower() + 'adm:sapsys ' + s_path + '/cofiles/' + cofile.split('/')[len(cofile.split('/')) - 1] + ';chmod 777 ' + s_path + '/cofiles/' + cofile.split('/')[len(cofile.split('/')) - 1] +  '; chown ' + t_sid.lower() + 'adm:sapsys ' + s_path + '/data/' + datafile.split('/')[len(datafile.split('/')) - 1] + '; chmod 777 ' + s_path + '/data/' + datafile.split('/')[len(datafile.split('/')) - 1] +  '\' | sudo bash'
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        	out, err = command.communicate()
		status = command.returncode
		if status != 0:
			print 'Import:F: The cofiles and datafile can not be given permission because of the status code: ' + str(status)
			exit()

	# ---------------------------- Import TRs ----------------------------------------------------
	command = 'tp addtobuffer ' + tr_id + " " + t_sid  + ' Client=' + clientname + ' pf=' + s_path + '/bin/TP_' + domain + '.PFL | grep --color=never -i "tp finished with return code:" | grep -v "CG"| tail -n 1 | cut -d ":" -f2'
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
        status = command.returncode

        if str(status) == "0" or str(status) == "4":
        	command = 'tp modbuffer ' + tr_id + " " + t_sid + ' mode=u+12 Client=' + clientname + ' pf=' + s_path + '/bin/TP_' + domain + '.PFL | grep --color=never -i "tp finished with return code:" | grep -v "CG" | tail -n 1 | cut -d ":" -f2'
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                out, err = command.communicate()
                status = command.returncode

        	if str(status) == "0" or str(status) == "4":
                	command = 'tp import ' + tr_id + " " +  t_sid + ' Client=' + clientname + ' pf=' + s_path + '/bin/TP_' + domain + '.PFL U123689 |grep -i "tp finished with return code:" | grep -v "CG" |tail -n 1 | cut -d ":" -f2'
			command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        	        out, err = command.communicate()
	                status = command.returncode

                	if str(status) == "0" or str(status) == "4":
                    		print "POST:P:TR " + tr_id + " import is successfull in the target application server"
                    		write(logfile,"POST:P:TR " + tr_id + " import is successfull in the target application server")
                	else:
                    		print "POST:F: TR " + tr_id + " import is failed with the error code: " + status
                    		write(logfile,"POST:F: TR " + tr_id + " import is failed with the error code: " + status)

            	else:
                	print "POST:F: The modbuffer for the TR " + tr_id + " has failed"
                	write(logfile,"POST:F: The modbuffer for the TR " + tr_id + " has failed")

        else:
            print "POST:F: TR " + tr_id + " is failed with the error code: " + str(status)
            write(logfile,"POST:F: TR " + tr_id + " is failed with the error code: " + status)

except Exception as e:
	exc_type, exc_obj, tb = sys.exc_info()
	lineno = tb.tb_lineno
	print 'Error: ' + str(e) + ': ' + str(lineno)
