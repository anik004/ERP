################################################################
#  Script Name: lin09.py
#  Author:Anik Chanda
#  Description: check If user has sudo access or not
################################################################
#!/usr/bin/python

# target IP - $1
# database sid - $2
# application sid - $3
# schema passwd - $4
import paramiko
from sys import *
from paramiko import *


try:
#    if argv[1] == "--u":
 #       print "usage: python sudo_access.py <Host> <sudo user> <sudo password> <sid> <DB/AI/CI> <Source/Target>"
  #  else:
	hostname=argv[1]
        sudo_user=argv[2]
	password=argv[3]
	sid=argv[4]
	string = argv[5]
	db_type = argv[6]
	os_name = argv[7].lower()

	if argv[5].lower() == "db" and db_type.lower() == "ora":
		user = "ora" + argv[4].lower()
	else:
		user = argv[4].lower() + "adm"
	
	#print user
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = sudo_user, password = password)
        channel = client.invoke_shell()

	if os_name == "aix":
                command = "echo \"su - " + user + " -c \"\\\"\"exit\"\\\" | sudo bsh"
        else:
                command = "echo \"su - " + user + " -c \"\\\"\"exit\"\\\" | sudo bash"
	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	stdin.write(password +'\n')
        stdin.flush()
	status = stdout.channel.recv_exit_status()
	print stdout.readlines()
	#print status

	if status == 0:
                print "PRE:P:Sudo access check to " + user + " for sudo user ( " + sudo_user + " ) is Successful on " + hostname
	else:
        	print "PRE:F:Sudo access check to " + user + " for sudo user ( " + sudo_user + " ) is not Successful on " + hostname
        channel.close()
        client.close()
except Exception as e:
 if str(e) == "[Errno -2] Name or service not known":
 	print "PRE:F:GERR_0401:Hostname unknown"
 elif str(e) == "list index out of range":
        print "PRE:F:GERR_0402:Argument/s missing for the script"
 elif str(e) == "Authentication failed.":
	print "PRE:F:GERR_0403:Authentication failed."
 elif str(e) == "[Errno 110] Connection timed out":
	print "PRE:F:GERR_0404:Host Unreachable"
 elif "getaddrinfo failed" in str(e):
        print "PRE:F:GERR_0405: Please check the hostname that you have provide"
 elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "PRE:F:GERR_0406:Host Unreachable or Unable to connect to port 22"
 else:
        print "F: " + str(e)
