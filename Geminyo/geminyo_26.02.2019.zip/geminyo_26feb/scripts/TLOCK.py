export
client=000
file='/home/ectadm/TLOCK.dat'
select * from TLOCK