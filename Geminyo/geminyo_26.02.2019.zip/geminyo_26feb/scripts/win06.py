# Embedded file name: win06.py
print 'PRE:F:Script does not exist'