# Embedded file name: lin15.py
print 'PRE:W:The database type "Hana" is not supported'