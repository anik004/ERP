# Embedded file name: win07.py
print 'PRE:F:Script does not exist'