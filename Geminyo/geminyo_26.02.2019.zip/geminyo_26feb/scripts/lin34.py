from paramiko import *
import paramiko
from sys import *
import sys
import log4erp
from log4erp import *
from time import gmtime, strftime
import paramiko
from paramiko import *
try:
    if argv[1] == "--u":
        print "usage: python ddic_setzero.py <Application Hostname> <Root User Name> <Root user password> <Application SID> <Target/Source>"
    else:

        hostname = argv[1]
        username = argv[2]
        password = argv[3]
#	db_hostname = argv[4]			#for distributed system, creds will be different
#	db_username = argv[5]
#	db_password = argv[6]
        application_sid = argv[4].lower()
	db_sid = argv[5].lower()
        profile_path = argv[6].rstrip("/")
#	db_user = argv[10]			#database username
#	db_pass = arhv[11]			#database password
	db_type = argv[7]
	schema = argv[8]
	schema_password = argv[9]
	db_hostname = argv[10]
        target_os = argv[11]
        user = application_sid.lower() + "adm"
        logfile = "geminyo.txt"

        if db_type.lower() == 'hdb':
            
            client = SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect( hostname,username = username, password = password)
            channel = client.invoke_shell()

            if target_os.lower() == 'aix':
                command = "echo \" su - " + user + " -c \"\'\"cd " + profile_path + ";ls DEFAULT.PFL\"\'| sudo bsh "
            else:
                command = "echo \" su - " + user + " -c \"\'\"cd " + profile_path + ";ls DEFAULT.PFL\"\'| sudo bash "
            print command

            #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            file_exist = stdout.readlines()
            print file_exist
            print file_exist[0]
            #write(logfile, str(file_exist) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

            if file_exist[0].strip() == "DEFAULT.PFL":
#               command = "sudo su - " + user + " -c \'cd ' + profile_path + ';cp " + profilefile + " " + "profilefile_autom_bkp \'"
                if target_os.lower() == 'aix':
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";cp DEFAULT.PFL defaultfile_autom_bkp \"\' | sudo bsh "
                else:
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";cp DEFAULT.PFL defaultfile_autom_bkp \"\' | sudo bash "

                print command
                #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                a = stdout.readlines()
                #write(logfile, str(a) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                if not a:
                        print "PRE:P: Backup file of Default profile  has been created successfully"
                        #write(logfile,"PRE:P: Backup file of Default profile has been created successfully")
                else:
                        print "PRE:F: Failed to take the backup of the default profile "
			#write(logfile,"PRE:F: Failed to take the backup of the default profile " + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                        exit()

            else:
                print "PRE:F: Couldn't find the default profile"
                #write(logfile,"PRE:F: Couldn't find the default profile ")
                exit()


    #	command = "echo \"su - " + user + " -c \"\'\" cd " + profile_path + "; cat DEFAULT.PFL \"\'\' |  grep -iw \"dbs/hdb/schema\" | grep -v \"#\"\'| sudo bash "
            if target_os.lower() == 'aix':
                command = "echo \"su - " + user + " -c \"\'\" cd " + profile_path + "; cat DEFAULT.PFL \"\'\' |  grep -iw \"dbs/" + db_type.lower() + "/schema\" | grep -v \"#\"\'| sudo bsh "
            else:
                command = "echo \"su - " + user + " -c \"\'\" cd " + profile_path + "; cat DEFAULT.PFL \"\'\' |  grep -iw \"dbs/" + db_type.lower() + "/schema\" | grep -v \"#\"\'| sudo bash "
            print command
            #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            output = stdout.readlines()
            #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            print output

            if not output:
#	        command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/hdb/schema = " + schema + "\\\" >> DEFAULT.PFL\"\'|sudo bash "
                if target_os.lower() == 'aix':
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/" + db_type.lower() + "/schema = " + schema + "\\\" >> DEFAULT.PFL\"\'|sudo bsh "
                else:
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/" + db_type.lower() + "/schema = " + schema + "\\\" >> DEFAULT.PFL\"\'|sudo bash "
                print command
                #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                output = stdout.readlines()
                #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                if stdout.channel.recv_exit_status() == 0:
                    print "POST:P: Schema parameter has been set"
                    #write(logfile, "POST:P: Schema parameter has been set" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

                    if target_os.lower() == 'aix':
                        command = "echo \"su - " + user + " -c \"\'\"hdbuserstore SET DEFAULT " + db_hostname + ":30015 " + schema + " " + "'" + schema_password  + "' \"\' | sudo bsh "
                    else:
                        command = "echo \"su - " + user + " -c \"\'\"hdbuserstore SET DEFAULT " + db_hostname + ":30015 " + schema + " " + "'" + schema_password  + "' \"\' | sudo bash "
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    output = stdout.readlines()
                    print output

                    if target_os.lower() == 'aix':
                        command = "echo \" su - " + user + " -c \"\'\"hdbuserstore list\"\'| sudo bsh "
                    else:
                        command = "echo \" su - " + user + " -c \"\'\"hdbuserstore list\"\'| sudo bash "
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    output = stdout.readlines()
                    print output

                    if schema in str(output):
                	print "POST:P: SECSTORE/User Store password reset is successful"
                        #write(logfile, "POST:P: SECSTORE/User Store password reset is successful")
                    else:
                        print "POST:F: SECSTORE/User Store password reset failed"
                        #write(logfile, "POST:F:SECSTORE/User Store password reset failed")

                else:
                    print "POST:F: Schema parameter set has failed"
                    #write(logfile, "POST:F: Schema parameter set has failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

            elif output.__len__() == 1:
                output = ''.join(output).strip()
                output = output.replace('/','\/')
                
                if target_os.lower() == 'aix':
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";sed \\\"s/" + output + "/#" + output + "/g\\\" DEFAULT.PFL >> /tmp/defparam.txt \"\'|sudo bsh "
                else:
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";sed \\\"s/" + output + "/#" + output + "/g\\\" DEFAULT.PFL >> /tmp/defparam.txt \"\'|sudo bash "
                print command
                #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                output = stdout.readlines()
                #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

                if stdout.channel.recv_exit_status() == 0:

#		    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/hdb/schema = " + schema + "\\\" >> /tmp/defparam.txt\"\'|sudo bash "
                    if target_os.lower() == 'aix':
                        command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/" + db_type.lower() + "/schema = " + schema + "\\\" >> /tmp/defparam.txt\"\'|sudo bsh "
                    else:
                        command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"dbs/" + db_type.lower() + "/schema = " + schema + "\\\" >> /tmp/defparam.txt\"\'|sudo bash "
                    print command
                    #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                    output = stdout.readlines()
                    #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                    if stdout.channel.recv_exit_status() == 0:
			command = 'sudo mv /tmp/defparam.txt ' + profile_path + '/DEFAULT.PFL'
	                print command
        	        #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	                output = stdout.readlines()
        	        #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                	if stdout.channel.recv_exit_status() == 0:
                        	print "POST:P: Schema parameter has been set"
	                        #write(logfile, "POST:P: Schema parameter has been set" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
				print "hello"
	                        command = "sudo rm /home/" + application_sid.lower() + "adm/defparam.txt"
	                        #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        	                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                	        output = stdout.readlines()
                        	#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                	        
                                if target_os.lower() == 'aix':
                                    command = "echo \"su - " + user + " -c \"\'\"hdbuserstore SET DEFAULT " + db_hostname + ":30015 " + schema + " " + "'" + schema_password  + "' \"\' | sudo bsh "
                                else:
                                    command = "echo \"su - " + user + " -c \"\'\"hdbuserstore SET DEFAULT " + db_hostname + ":30015 " + schema + " " + "'" + schema_password  + "' \"\' | sudo bash "
				print command
				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                output = stdout.readlines()
				print output

				if target_os.lower() == 'aix':
                                    command = "echo \" su - " + user + " -c \"\'\"hdbuserstore list\"\'| sudo bsh "
                                else:
                                    command = "echo \" su - " + user + " -c \"\'\"hdbuserstore list\"\'| sudo bash "
				print command
                                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                                output = stdout.readlines()
				print output
				
				if schema in str(output):
					print "POST:P: SECSTORE/User Store password reset is successful"
					#write(logfile, "POST:P: SECSTORE/User Store password reset is successful")
				else:
					print "POST:F: SECSTORE/User Store password reset failed"
					#write(logfile, "POST:F:SECSTORE/User Store password reset failed")

	                else:
        	                print "POST:F: Schema parameter set has failed"
                	        #write(logfile, "POST:F: Schema parameter set has failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                else:
                    print "POST:F: Schema parameter set has failed"
                    #write(logfile, "POST:F: Schema parameter set has failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            else:
                print "POST:F: Schema parameter set has failed"
                #write(logfile, "POST:F: Schema parameter set has failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            channel.close()
            client.close()

        else:
            print "POST:P: Schema parameter is not available for the given DB " + db_type



except Exception as e:
    print "POST:F: " + str(e)
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print lineno
