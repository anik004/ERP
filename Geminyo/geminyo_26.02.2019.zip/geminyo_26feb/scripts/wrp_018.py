################################################################
#  Script Name: wrp_018.py
#  Author: Anik Chanda
#  Description: install license in the target system
################################################################
import re
import subprocess
from subprocess import *
from sys import *
import os
from log4erp import *
import paramiko
from paramiko import *
try:
# ---------------------- variable declaration ------------------------------------------
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    location = argv[4].rstrip('/') # kernel location
    drive = argv[5].rstrip('/')    # script location -> AL11 path
    license_file = argv[6].lower() # license file name
    profilepath = argv[7].rstrip('/') # profile path
    appsid = argv[8].lower()
    profilefile = argv[9]
    target_os = argv[10]
    print profilefile
    appuser = appsid + 'adm'
    profile_path = profilepath

    local_os = os.name
    ############ LINUX #################
    if local_os.lower() == 'posix':
    ####################################

        write('reflogfile.log',"wrp_018:This command calls the lin28 script")
	command = 'python ' + drive + '/lin28 ' + hostname + ' ' + username + ' ' + password + ' ' + location + ' ' + drive + ' ' + license_file + ' ' + profilepath + ' ' + appsid + ' ' + profilefile + ' ' + target_os
	print command 
	write('reflogfile.log',command)
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
	print out
        status = command.returncode
	print status
	if status != 0:
            print 'POST:F:The script execution has failed'
            write(ref_id, 'POST:F:The script execution has failed')
	    write('reflogfile.log','POST:F:The script execution has failed')
	
    ########### OTHER (WINDOWS) ########
    else:
    ####################################

        if target_os == 'windows':
            write('reflogfile.log',"wrp_018:This command calls the win30 script")
            command = 'c:\\python27\\python.exe ' + drive + '\win30 ' + hostname + ' ' + username + ' ' + password + ' ' + location + ' ' + drive + ' ' + license_file + ' ' + profilepath
        else:
            write('reflogfile.log',"wrp_018:This command calls the lin28 script")
            command = 'c:\\python27\\python.exe ' + drive + '\lin28 ' + hostname + ' ' + username + ' ' + password + ' ' + location + ' ' + drive + ' ' + license_file + ' ' + profilepath + ' ' + appsid + ' ' + profilefile + ' ' + target_os
        print command
	write('reflogfile.log',command)
	command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
        out, err = command.communicate()
	print out
        status = command.returncode
        if status != 0:
            print 'POST:F:The script execution has failed'
            write(ref_id, 'POST:F:The script execution has failed')
	    write('reflogfile.log','POST:F:The script execution has failed')


		
except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
        print "POST:F:GERR_3001:Hostname unknown"
	write('reflogfile.log',"POST:F:GERR_3001:Hostname unknown")
    elif str(e).strip() == "list index out of range":
        print "POST:F:GERR_3002:Argument/s missing"
	write('reflogfile.log',"POST:F:GERR_3002:Argument/s missing")
    elif str(e) == "Authentication failed.":
        print "POST:F:GERR_3003:Authentication failed."
	write('reflogfile.log',"POST:F:GERR_3003:Authentication failed.")
    elif str(e) == "[Errno 110] Connection timed out":
        print "POST:F:GERR_3004:Host Unreachable"
	write('reflogfile.log',"POST:F:GERR_3004:Host Unreachable")
    elif "getaddrinfo failed" in str(e):
        print "POST:F:GERR_3005: Please check the hostname that you have provide"
	write('reflogfile.log',"POST:F:GERR_3005: Please check the hostname that you have provide")
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "POST:F:GERR_3006:Host Unreachable or Unable to connect to port 22"
	write('reflogfile.log',"POST:F:GERR_3006:Host Unreachable or Unable to connect to port 22")
    else:
        print "POST:F: " + str(e)
	write('reflogfile.log',"POST:F: " + str(e))

