################################################################
#  Script Name: wrp_010.py
#  Author:Anik Chanda
#  Description: background parameter set to 0 (script lin25.py and win16.py is called)
################################################################
import os
from os import *
import sys
from sys import *
import subprocess
from subprocess import *
from log4erp import *

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	prof_path = argv[4]
	scr = argv[5].strip('\\')
	ref_id = argv[6]
	app_sid = argv[7]
	profilefile = argv[8]
	os_name = argv[9]

	local_os = os.name
	############ LINUX #################
	if local_os.lower() == 'posix':
	####################################

		#app_sid = argv[7]
		write('reflogfile.log',"wrp_010:This command calls the lin25 script")
		command = 'python ' + scr + '/lin23 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path + ' ' + profilefile + ' ' + os_name
		print command 
		write('reflogfile.log',command)
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                out, err = command.communicate()
		print out
                status = command.returncode
		print status
		if status != 0:
                        print 'POST:F:The script execution has failed'
                        write(ref_id, 'POST:F:The script execution has failed')
			write('reflogfile.log','POST:F:The script execution has failed')
	
	########### OTHER (WINDOWS) ########
	else:
	####################################

                if os_name == 'windows':
                        write('reflogfile.log',"wrp_010:This command calls the win16 script")
                        command = 'c:\\python27\\python.exe ' + scr + '\win16 ' + hostname + ' ' + username + ' ' + password + ' ' + prof_path + ' ' + ref_id + ' ' + scr
                else:
                        command = 'c:\\python27\\python.exe ' + scr + '\lin23 ' + hostname + ' ' + username + ' ' + password + ' ' + app_sid + ' ' + prof_path + ' ' + profilefile + ' ' + os_name
                print command
		write('reflogfile.log',command)
		command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                out, err = command.communicate()
		print out
                status = command.returncode
                if status != 0:
                        print 'POST:F:The script execution has failed'
                        write(ref_id, 'POST:F:The script execution has failed')
			write('reflogfile.log','POST:F:The script execution has failed')


		
except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
        print "POST:F:GERR_3001:Hostname unknown"
	write('reflogfile.log',"POST:F:GERR_3001:Hostname unknown")
    elif str(e).strip() == "list index out of range":
        print "POST:F:GERR_3002:Argument/s missing"
	write('reflogfile.log',"POST:F:GERR_3002:Argument/s missing")
    elif str(e) == "Authentication failed.":
        print "POST:F:GERR_3003:Authentication failed."
	write('reflogfile.log',"POST:F:GERR_3003:Authentication failed.")
    elif str(e) == "[Errno 110] Connection timed out":
        print "POST:F:GERR_3004:Host Unreachable"
	write('reflogfile.log',"POST:F:GERR_3004:Host Unreachable")
    elif "getaddrinfo failed" in str(e):
        print "POST:F:GERR_3005: Please check the hostname that you have provide"
	write('reflogfile.log',"POST:F:GERR_3005: Please check the hostname that you have provide")
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "POST:F:GERR_3006:Host Unreachable or Unable to connect to port 22"
	write('reflogfile.log',"POST:F:GERR_3006:Host Unreachable or Unable to connect to port 22")
    else:
        print "POST:F: " + str(e)
	write('reflogfile.log',"POST:F: " + str(e))

