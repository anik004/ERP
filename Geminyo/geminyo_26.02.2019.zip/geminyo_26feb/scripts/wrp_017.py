################################################################
#  Script Name: wrp_017.py
#  Author:Anik Chanda
#  Description: truncate the tables 
################################################################
import subprocess
from os import *
import os
from sys import *
from subprocess import *
from log4erp import *

try:
        if argv[1] == '--ani':
                print 'usage: h u p app dr ref os no nm'
        else:
                hostname = argv[1]
                username = argv[2]
                password = argv[3]
                appsid = argv[4]
                drive = argv[5]
                ref_id = argv[6]
                os_name = argv[7]
                inst_no = argv[8]
                inst_nm = argv[9]
                path = argv[10].strip('\\')
                profile_path = argv[11]
                db_user = argv[12]
                db_password = argv[13]
                logfile = "geminyo.log"
#                clean = argv[14].strip()
                db_type = argv[14]

                if os_name.lower() == 'windows':
			if db_type.lower() == "mss":
				command = 'c:\\python27\\python.exe ' + path.rstrip('\\') + '\\cleanupjobmss ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + path.rstrip('\\')  + ' ' + logfile + ' ' + appsid + ' ' + drive
                                print command
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
                                if ":P:" in out:
                                        print "cleanup:P:cleanup is successful for the hostname " + hostname
                                else:
                                        print "cleanup:F:cleanup is failed  for the hostname " + hostname
                                        exit()

		elif os_name.lower() == 'redhat' or os_name.lower() == 'aix' or os_name.upper() == 'SUSE_LINUX':
			if db_type.lower() == "ora":
                                if os.name == 'posix':
                                        command = 'python ' + path + '/cleanupjobora ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + ref_id + ' ' + os_name
                                elif os.name == 'nt':
                                        command = 'c:\\python27\\python.exe ' + path.rstrip('\\') + '\\cleanupjobora ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + ref_id + ' ' + os_name
                                print command
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
                                if ":P:" in out:
                                        print "cleanup:P:cleanup is successful for the hostname " + hostname
                                else:
                                        print "cleanup:F:cleanup is failed  for the hostname " + hostname
                                        exit()

			elif db_type.lower() == "db6":
                                if os.name == 'posix':
                                        command = 'python ' + path + '/cleanupjobdb2 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' + os_name
                                else:
                                        command = 'c:\\python27\\python.exe ' + path.rstrip('\\') + '\\cleanupjobdb2 ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' + os_name
                                print command
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
                                if ":P:" in out:
                                        print "cleanup:P:cleanup is successful for the hostname " + hostname
                                else:
                                        print "cleanup:F:cleanup is failed  for the hostname " + hostname
                                        exit()

#		elif os_name.upper() == 'SUSE_LINUX':
			elif db_type.lower() == "syb" or db_type.lower() == "hdb":
                                if os.name == 'posix':
                                        command = 'python ' + path + '/cleanupjobsyb ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' + os_name
                                else:
                                        command = 'c:\\python27\\python.exe ' + path.rstrip('\\') + '\\cleanupjobsyb ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' +  os_name
                                print command
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
                                if ":P:" in out:
                                        print "cleanup:P:cleanup is successful for the hostname " + hostname
                                else:
                                        print "cleanup:F:cleanup is failed  for the hostname " + hostname
                                        exit()

			elif db_type.lower() == "ada":
                                if os.name == 'posix':
                                        command = 'python ' + path + '/cleanupjobmax ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' + os_name
                                else:
                                        command = 'c:\\python27\\python.exe ' + path.rstrip('\\') + '\\cleanupjobmax ' + hostname + ' ' + username + ' ' + password + ' ' + appsid + ' ' + db_user + ' ' + db_password + ' ' + path + ' ' + db_type + ' ' + os_name
				print command
                                command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out
                                if ":P:" in out:
                                        print "cleanup:P:cleanup is successful for the hostname " + hostname
                                else:
                                        print "cleanup:F:cleanup is failed  for the hostname " + hostname
                                        exit()



except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
        print "PRE:F:GERR_3001:Hostname unknown"
    elif str(e).strip() == "list index out of range":
        print "PRE:F:GERR_3002:Argument/s missing"
    elif str(e) == "Authentication failed.":
        print "PRE:F:GERR_3003:Authentication failed."
    elif str(e) == "[Errno 110] Connection timed out":
        print "PRE:F:GERR_3004:Host Unreachable"
    elif "getaddrinfo failed" in str(e):
        print "PRE:F:GERR_3005: Please check the hostname that you have provide"
    elif "[Errno None] Unable to connect to port 22 on" in str(e):
        print "PRE:F:GERR_3006:Host Unreachable or Unable to connect to port 22"
    else:
        print "PRE:F: " + str(e)

