import os
import sys
import subprocess

command = 'ls | grep py'
command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
out, err = command.communicate()
print out

for each in out.split('\n'):
        if each != 'test.py' and each != 'wmiexec.py' and each != 'log4erp.pyc' and each != '' and '.py' in each :
                print each[:-3]
                command = 'mv ' + each.strip() + ' ' +  each[:-3]
                print command
                command = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                out, err = command.communicate() 
