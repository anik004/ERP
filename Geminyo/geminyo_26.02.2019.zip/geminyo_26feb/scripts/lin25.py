################################################################
#  Script Name: lin25.py
#  Author:Anik Chanda
#  Description: set sap* parameter to 0(unlocking sap* user)
################################################################
from paramiko import *
import paramiko
from sys import *
import log4erp
from log4erp import *
from time import gmtime, strftime

try:
    if argv[1] == "--u":
        print "usage: python ddic_setzero.py <Application Hostname> <Root User Name> <Root user password> <Application SID> <Target/Source>"
    else:

        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        application_sid = argv[4].lower()
	profile_path = argv[5]
	profilefile = argv[6]
	os_name = argv[7].lower()
        user = application_sid.lower() + "adm"
	logfile = "geminyo.txt"

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

	"""
#        command = 'sudo su - ' + user + ' -c \'cd ' + profile_path + ';ls | grep -i "' + application_sid.upper() + '_DVEBMGS" | grep -v "\."\''
	command = " echo \" su - " + user + " -c \"\'\"cd " + profile_path + "; ls\"\'\' | grep -i \"" + application_sid.upper() + "_DVEBMGS\" |  grep -i " + hostname + "  | grep -v \"\.\"\'| sudo bash "

        print command
	#write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	output = stdout.readlines()[0]
	#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        profilefile = ''.join(output).strip()
	"""
	print profilefile

#        command = 'sudo su - ' + user + ' -c \'cd ' + profile_path + ';cat ' + profilefile + ' | grep -iw "login/no_automatic_user_sapstar" | grep -v "#"\''
        if os_name == "aix":
            command = "echo \"su - " + user + " -c \"\'\" cd " + profile_path + "; cat " + profilefile + " \"\'\' |  grep -iw \"login/no_automatic_user_sapstar\" | grep -v \"#\"\'| sudo bsh "
        else:
            command = "echo \"su - " + user + " -c \"\'\" cd " + profile_path + "; cat " + profilefile + " \"\'\' |  grep -iw \"login/no_automatic_user_sapstar\" | grep -v \"#\"\'| sudo bash "
        print command
	#write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        output = stdout.readlines()
	#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
	print output

        if not output:
#            command = "echo \"su - " + user + ' -c \'cd ' + profile_path + ';echo "login/no_automatic_user_sapstar = 0" >> ' + profilefile + '\''
            if os_name == "aix":
                command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"login/no_automatic_user_sapstar = 0\\\" >> " + profilefile + "\"\'|sudo bsh "
            else:
                command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";echo \\\"login/no_automatic_user_sapstar = 0\\\" >> " + profilefile + "\"\'|sudo bash "

	    print command
	    #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	    output = stdout.readlines()
	    #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            if stdout.channel.recv_exit_status() == 0:
                print "PRE:P: Parameter set to 0"
		#write(logfile, "PRE:P: Parameter set to 0" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            else:
                print "PRE:F: Parameter change failed"
		#write(logfile, "PRE:F: Parameter change failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        elif output.__len__() == 1:
            output = ''.join(output).strip()
            output = output.replace('/','\/')
#            command = 'sudo su - ' + user + ' -c \'cd ' + profile_path + ';sed "s/' + output + '/login\/no_automatic_user_sapstar = 0/g" ' + profilefile + ' >> /home/' + application_sid.lower() + 'adm/paramstar.txt \''

#            command = "echo \"su - " + user + " -c \"\'\'cd " + profile_path + ";sed \"s/" + output + "/login\/no_automatic_user_sapstar = 0/g\" " + profilefile + " >> /home/" + application_sid.lower() + "adm/paramstar.txt \"\'|sudo bash "
            if os_name == "aix":
                command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";sed \\\"s/" + output + "/login\/no_automatic_user_sapstar = 0/g\\\" " + profilefile + " >> /tmp/paramstar.txt \"\'|sudo bsh "
            else:
                command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";sed \\\"s/" + output + "/login\/no_automatic_user_sapstar = 0/g\\\" " + profilefile + " >> /tmp/paramstar.txt \"\'|sudo bash "
	    print command
	    #write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            output = stdout.readlines()
	    #write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
	
            if stdout.channel.recv_exit_status() == 0:
                if os_name == "aix":
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";pwd \"\'|sudo bsh "
                else:
                    command = "echo \"su - " + user + " -c \"\'\"cd " + profile_path + ";pwd \"\'|sudo bash "
		print command
		#write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		output = stdout.readlines()
		#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
		output = output[0]
#		command = 'sudo mv /home/' + application_sid.lower() + 'adm/paramstar.txt ' + output.strip()+ '/' + profilefile
		command = 'sudo mv /tmp/paramstar.txt ' + output.strip()+ '/' + profilefile
		print command
		#write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                output = stdout.readlines()
		#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
		if stdout.channel.recv_exit_status() == 0:
                	print "PRE:P: Parameter set to 0"
			#write(logfile, "PRE:P: Parameter set to 0" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
			command = "sudo rm /home/" + application_sid.lower() + "adm/paramstar.txt"
			#write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
			stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			output = stdout.readlines()
			#write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
		else:
			print "PRE:F: Parameter change failed"
			#write(logfile, "PRE:F: Parameter change failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            else:
                print "PRE:F: Parameter change failed"
		#write(logfile, "PRE:F: Parameter change failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        else:
	    print "PRE:F: Parameter change failed"
	    #write(logfile, "PRE:F: Parameter change failed" + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')

        channel.close()
        client.close()

except Exception as e:
    print "F: " + str(e)
