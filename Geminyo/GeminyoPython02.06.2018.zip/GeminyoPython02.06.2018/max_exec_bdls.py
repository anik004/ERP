# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime
from datetime import datetime
import time

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    #hostname = '10.213.63.29'
    #username = 'cgngupta'
    #password = 'B9526em27'
    #sidadm = 'tstadm'

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    clientname = argv[12]
    sidadm = str(sid.strip()).lower() + 'adm'
    
    write(refid + '_BDLS_detailed.log', "BDLS execution : " + refid + " starting at " + strftime("%Y-%m-%d %H:%M "))
    starttime = strftime("%H:%M:%S")
    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls.txt')
    row_top = file.readlines()
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname, clientname):
        # ------------------------------- Get table column names ---------------------------------
            #tablename = table_size[row_top].strip()
	
	    start_time = strftime("%H:%M:%S")
	    rowname = tablename.split()[1]
	    print rowname

	    tablename = tablename.split()[0]
	    file2 = open (script_loc + '/' + refid + '_BDLS_detailed.log')
	    log_content = file2.read()
#	    print log_content
	    print tablename
	    if 'POST|P|' + tablename+  ' |' in  log_content:
		return
	   	 
        #    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select TOP 1 * from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sql_execute select columnname from domain.columns where tablename=\''+ tablename.strip() + '\'\\\\\\\" > table' + num + '.sql; dbmcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -i table' + num + '.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            columnname = out
	    print columnname
            # ----------------------- Put Case statement --------------------------------------
            wholecolumn = ''
            for each in columnname:
	      if rowname.split('|')[0] in each:
		if 'MANDT' in columnname:
#                    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' and MANDT=\'" + clientname + "\' THEN \'" + newls + "\'; ELSE " + each.strip() + "; END CASE ) AS " + each.strip() + ','
		else:
		     wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\'; ELSE " + each.strip() + "; END CASE) AS " + each.strip() + ','
	      else:
                    wholecolumn = ' ' + wholecolumn + each + ','

            # --------------------------- Conversion ------------------------------------------
#            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select ' + wholecolumn[:-1].strip() + ' into ' + tablename + '_BDLSS from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sql_execute create table  ' + tablename + '_BDLSS like  ' + tablename.strip() + ',' +  wholecolumn[:-1].strip() + '\'\\\\\\\" > table' + num + '.sql; dbmcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -i table' + num + '.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
            print command
	    write(refid + '_det.log', '---------------------------- backup --------------------------------')
	    write(refid + '_det.log', command)
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
	    row_num = out[-1].strip() 
	    print row_num
	    row_num = row_num.strip("(").strip(")")
	    print row_num
	    #print "row_num = " + row_num
            status = stdout.channel.recv_exit_status()
            write(refid + '_det.log', out)
	    
            # ------------------------- Rename to _OLD ---------------------------------------
            print status
	    exit()
            if status == 0:
		command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sql_execute drop table ' + tablename.strip() + '\\\\\\\" > table' + num + '.sql; dbmcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -i table' + num + '.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
                write(refid + '_det.log', '---------------------------- rename to old --------------------------------')
	        write(refid + '_det.log', command)
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                out = stdout.readlines()
                status = stdout.channel.recv_exit_status()
                write(refid + '_det.log', out)
	#	print out

                # ----------------- Rename _BDLS to original ------------------------------
                if status == 0:
#                    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + '_BDLSS,' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
		    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sql_execute rename table ' + tablename.strip() + '_BDLSS to ' + tablename.strip() + '\\\\\\\" > table' + num + '.sql; dbmcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -i table' + num + '.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
                    write(refid + '_det.log', '---------------------------- rename to bdls --------------------------------')
		    write(refid + '_det.log', command)
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                    out = stdout.readlines()
	#	    print out
                    status = stdout.channel.recv_exit_status()
                    write(refid + '_det.log', out)
		    end_time = strftime("%H:%M:%S")
		    FMT = '%H:%M:%S'
	            duration = datetime.strptime(end_time, FMT) - datetime.strptime(start_time, FMT)
                    if status == 0:
                        print 'The conversion has been completed succesfully for the table ' + tablename.strip()
                        write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())
#		        write(refid + '_BDLS_detailed.log','POST|P|' +  tablename.strip() + ' | ' + str(duration) + ' | ' + str(row_num) )
			if len(str(row_num).split()) == 3:
				write(refid + '_BDLS_detailed.log', '\nclient: ' + clientname + " from " + oldls + " to " + newls + " Table " + tablename.strip() + ' ' +  str(row_num) + ' duration ' + str(duration) +  ' ')

                    # ------------------------------------- ELSE -------------------------------------------------------
                    else:
                        print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
                else:
                    print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 2'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
            else:
                print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')


    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------

    #print row_top[0]
    
#    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname)
#    exit()

    threadfirst = Thread(target=exebdls, args=(row_top[0], 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfirst.start()
    threadsecond = Thread(target=exebdls, args=(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadsecond.start()

    threadthird = Thread(target=exebdls, args=(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadthird.start()

    threadfourth = Thread(target=exebdls, args=(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfourth.start()


#    threadfive = Thread(target=exebdls, args=(row_top[4], 'five', sidadm, dbuser, dbpasswd, dbname))
#    threadfive.start()
#    threadsix = Thread(target=exebdls, args=(row_top[5], 'six', sidadm, dbuser, dbpasswd, dbname))
#    threadsix.start()

    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1
#    flag_five = 1
#    flag_six = 1

    for each in row_top:
	print each

        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
                if flag_first == 0:
                        threadfirst = Thread(target=exebdls, args=(each, 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfirst.start()
                        flag_first = 1
			break
		if flag_second == 0:
			threadsecond = Thread(target=exebdls, args=(each, 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadsecond.start()
			flag_second=1
			break
		if flag_third == 0:
			threadthird = Thread(target=exebdls, args=(each, 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadthird.start()
			flag_third=1
			break
		if flag_fourth == 0:
			threadfourth = Thread(target=exebdls, args=(each, 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfourth.start()
			flag_fourth = 1
			break

#		if flag_five == 0 :
#			threadfive = Thread(target=exebdls, args=(row_top[4], 'five', sidadm, dbuser, dbpasswd, dbname))
#			threadfive.start()
#			flag_five = 1
#			print "Assigning thread five with " + str(each)
#			break

#		if flag_six == 0:
#			threadsix = Thread(target=exebdls, args=(row_top[5], 'six', sidadm, dbuser, dbpasswd, dbname))
#			threadsix.start()
#			flag_six = 1
#			print "Assigning thread six with " + str(each)
#			break 


#------------------------------is alive---------------------------------
		if threadfirst.isAlive() == False:
			flag_first = 0
			print "thread first is not alive"

		if threadsecond.isAlive() == False:
			flag_second=0
			print "thread second  is not alive"
		
		if threadthird.isAlive() == False:
			flag_third = 0
			print "thread third  is not alive"

		if threadfourth.isAlive() == False:
                        flag_fourth = 0
			print "thread fourth is not alive"

#		if threadfive.isAlive() == False:
#			flag_five = 0
#			print "thread fifth is not alive"
#		if threadsix.isAlive() == False:
#			flag_six = 0
#			print "thread six  is not alive"

		

#    for each in range (0, len(row_top), 4):
#        threadfirst = Thread(target=exebdls, args=(row_top[each], 'first', sidadm, dbuser, dbpasswd, dbname))
#	threadfirst.start()
#        threadsecond = Thread(target=exebdls, args=(row_top[each + 1], 'second', sidadm, dbuser, dbpasswd, dbname))
#	threadsecond.start()
#        threadthird = Thread(target=exebdls, args=(row_top[each + 2], 'third', sidadm, dbuser, dbpasswd, dbname))
#	threadthird.start()
#        threadfourth = Thread(target=exebdls, args=(row_top[each + 3], 'fourth', sidadm, dbuser, dbpasswd, dbname))
#	threadfourth.start()
	#exebdls(each, table_size, sidadm, dbuser, dbpasswd, dbname)

        # ------------------ check thread status ------------------------------------------
#        flag = True
#        while flag == True:
#            if threadfirst.isAlive() == True or threadsecond.isAlive() == True or threadthird.isAlive() == True or threadfourth.isAlive() == True:
#                flag = True
#	    else:
#		flag = False
    print "end of first loop"
    while threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
  #  while flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
		
	#	if flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
		if threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:

			continue
		else:
			print "end of second loop"
			break



    print 'POST|P|The BDLS is over'
    endtime = strftime("%H:%M:%S")
    
    FMT = '%H:%M:%S'
    total_duration = datetime.strptime(endtime, FMT) - datetime.strptime(starttime, FMT)
    write(refid + '.log', "POST:P: " + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')
    write(refid + '_BDLS_detailed.log','\nThe BDLS is completed for ' + clientname + ' ' +  strftime("%Y-%m-%d %H:%M "))
    logf = open(refid + '_BDLS_detailed.log', 'r')
    count = 0
    logfl = logf.readlines()
    for each in logfl:
	   if "rows affected" in str(each) or "row affected" in str(each):
		if "0 rows affected " not in str(each):
			count = count + 1	
    logf.close()
    write(refid + '_BDLS_detailed.log','\ntotal duration ' + str(total_duration))
    write(refid + '_BDLS_detailed.log', str(count)+' tables are converted for ' + clientname + ' ' )
 

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
