################################################################
#  Script Name: lin26.py
#  Author: Anik Chanda
#  Description: query to reset password for sap*(to unlock)
################################################################
from paramiko import *
import paramiko
from sys import *
import log4erp
from log4erp import *
from time import gmtime, strftime

def sapdelete_ora(hostname,username,password,application_sid,clientname,logfile):

	user = "ora" + application_sid.lower()

#	command = 'sudo su - ' + user + ' -c \'echo $dbs_ora_schema\''
	command = 'echo "su - ' + user + ' -c "\'"echo $dbs_ora_schema"\'| sudo bash'
        print command
        write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        output = stdout.readlines()
        write(logfile, str(output) + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        output = ''.join(output).strip()
        #print output
        if stdout.channel.recv_exit_status() == 0:
            #DELETE SAP<SID>.usr02 where mandt='CLIENT.NO' and bname=SAP
#            command = 'sudo su - ' + user + ' -c "echo \'delete '+ output + '.usr02 where mandt=' + clientname + ' and bname=\'\\\'SAP\\*\\\'\';\' | sqlplus / as sysdba"'
	    command = 'echo "su - ' + user + ' -c "\'"echo \'"\'delete '+ output + '.usr02 where mandt=' + clientname + ' and bname=\\\'SAP*\\\';\' | sqlplus / as sysdba"\'"\'| sudo bash'
            print command
            write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            if stdout.channel.recv_exit_status() == 0:
                print "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " 	)"
                write(logfile, "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )" + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
            else:
                print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"
                write(logfile, "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )")
        else:
            print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"
            write(logfile, "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )")	

def sapdelete_syb(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile):

	file=open(path + "/sapdel.sql","w+")
	"""
        file.write('use ' + application_sid.upper() + '\n')
        file.write('delete '+ application_sid.upper()+'.SAPSR3.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')
        file.write('update '+ application_sid.upper()+'.SAPSR3.USR02 set UFLAG = 0 where BNAME = \'SAP*\' and  MANDT=\''+ clientname +'\'\n')
	"""
        if db_type.lower() == "syb":
                user = 'syb' + application_sid.lower()
		file.write('use ' + application_sid.upper() + '\n')^M
       		file.write('delete '+ application_sid.upper()+'.SAPSR3.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')^M
	        file.write('update '+ application_sid.upper()+'.SAPSR3.USR02 set UFLAG = 0 where BNAME = \'SAP*\' and  MANDT=\''+ clientname +'\'\n')^M

                file.write("go");
        elif db_type.lower() == "hdb":
#                user = 'hdb' + application_sid.lower()
		user = application_sid.lower() + 'adm'
		prof_path = "/usr/sap/" + application_sid.upper() + "/SYS/profile"
		command = " echo \" su - " + user + " -c \"\'\"cd " + prof_path + ";ls\"\'\' | grep -i \"" + application_sid.upper() + "_HDB\" |  grep -i " + hostname + "  | grep -v \"\.\"\'| sudo bash " 
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	        profilefile = ''.join(stdout.readlines()).strip()
		print profilefile

		profilefile1 = profilefile.split("_")[1]
		print profilefile1
		profilefile1 = profilefile1[-2:]
		print profilefile1
		file.write('delete from USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')
#                file.write('update USR02 set UFLAG = 0 where BNAME = \'SAP*\' and  MANDT=\''+ clientname +'\'\n')
#		file.write('select * from USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')

#                file.write("exit")
        file.close()

        port = 22

        remote= '/tmp/sapdel.sql'
        print remote
        local= path + '/sapdel.sql'
        print local

        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)


        if db_type.lower() == "syb":
#                command = 'sudo su - ' + user + ' -c \' isql -U' + db_user + " -P" + db_password + " -S"+ application_sid.upper() + " -X -i/tmp/sapdel.sql\'"
		command = 'echo "su - ' + user + ' -c "\'"isql -U' + db_user + ' -P' + db_password + ' -S' + application_sid.upper() + ' -X -i/tmp/sapdel.sql"\'| sudo bash'
        elif db_type.lower() == "hdb":
#                command = 'sudo su - ' + user + ' -c \' hdbsql -U' + db_user + " -P" + db_password + " -S"+ application_sid.upper() + " -I /tmp/sapdel.sql\'"
		command = 'echo "su - ' + user + ' -c "\'"hdbsql -i ' + profilefile1 + ' -u ' + db_user + ' -p ' + db_password + ' -m -I /tmp/sapdel.sql"\'| sudo bash'

        print command
#       write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        print stdout.readlines()
        print stdout.channel.recv_exit_status()
        if stdout.channel.recv_exit_status() == 0:
                print "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )"
#               write(logfile, "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )" + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        else:
                print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"
#               write(logfile, "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )")

def sapdelete_db2(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile):

	user = 'db2' + application_sid.lower()

	file2=open(path + "/sapschema.sql","w+")
	file2.write('connect to ' + application_sid.upper() + ';\n')
	file2.write('select tabschema from syscat.tables where tabname = \'SVERS\';')
	file2.close()
	
	port = 22	
	remote1= '/tmp/sapschema.sql'
	print remote1
	local1 = path + '/sapschema.sql'
	print local1
	
	transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local1, remote1)


	command = 'echo "su - ' + user + ' -c"\'"db2 -tvmf /tmp/sapschema.sql"\'\'| grep -i "SAP"\'| sudo bash'
	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        schema = stdout.read().strip()
	schema = str(schema)
	print schema

	file1=open(path + "/sapdel.sql","w+")
        file1.write('connect to ' + application_sid.upper() + ';\n')
        file1.write('delete '+ schema + '.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\';\n')
#	file1.write('select bname,uflag from ' + schema + '.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\';\n')
#        file1.write('update '+ schema + '.USR02 set UFLAG = 0 where BNAME = \'SAP*\' and  MANDT=\''+ clientname +'\';\n')
        file1.close()

       
	
        remote= '/tmp/sapdel.sql'
	print remote
        local= path + '/sapdel.sql'
	print local


        transport = paramiko.Transport((hostname, port))
        transport.connect(username = username, password = password)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.put(local, remote)



#        command = "sudo su - " + user + " -c\"db2 -tvmf sapdel.sql\""
	command = 'echo "su - ' + user + ' -c"\'"db2 -tvmf /tmp/sapdel.sql"\'| sudo bash'

        print command
#       write(logfile, command + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        print stdout.readlines()
        print stdout.channel.recv_exit_status()
        if stdout.channel.recv_exit_status() == 0 or stdout.channel.recv_exit_status() == 1:
                print "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )"
#               write(logfile, "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )" + ': " ' + strftime("%Y-%m-%d %H:%M:%S", gmtime()) + ' "')
        else:
                print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"
#               write(logfile, "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )")



def sapdelete_maxdb(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile):

	user = application_sid.lower() + "adm"
	schema = "SAP" + application_sid.upper()


	file2=open(path + "/sapdel.sql","w+")
	file2.write('sql_execute delete from ' + schema + '.USR02 where MANDT=\''+ clientname +'\' and BNAME=\'SAP*\'\n')
	file1.close()

	remote= '/tmp/sapdel.sql'
	local= path + '/sapdel.sql'

	transport = paramiko.Transport((hostname, port))
	transport.connect(username = username, password = password)
	sftp = paramiko.SFTPClient.from_transport(transport)
	sftp.put(local, remote)

	command = 'echo "su - ' + user + ' -c"\'"dbmcli -d ' + application_sid.upper() + ' -u ' + db_user + ',' + db_password + ' -i /tmp/sapdel.sql"\'| sudo bash'
	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	print stdout.readlines()
	print stdout.channel.recv_exit_status()
	if stdout.channel.recv_exit_status() == 0 or stdout.channel.recv_exit_status() == 1:
		print "POST:P: password reseted successfully for sap* in  server ( Hostname - " + hostname + " )"
	else:
		print "POST:F: password reset failed for sap* in server ( Hostname - " + hostname + " )"

try:
    if argv[1] == "--u":
        print "usage: python sapdelete.py <Application Hostname> <Sudo User Name> <Sudo user password> <Application SID> <Client Name> <Target/Source>"
    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        application_sid = argv[4]
#        user =  "syb" + application_sid.lower()
        clientname = argv[5]
	print clientname
	path = argv[6].rstrip('/')
	print path
	db_user = argv[7]	
	db_password = argv[8]
	db_type = argv[9]
	print db_type.lower()
	logfile = "geminyo.txt"

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( hostname,username = username, password = password)
        channel = client.invoke_shell()

            #DELETE SAP<SID>.usr02 where mandt='CLIENT.NO' and bname=SAP
#        command = 'sudo su - ' + user + ' -c "echo \'delete ' + application_sid.upper() + '.SAPSR3.usr02 where mandt=' + clientname + ' and bname=\'\\\'SAP\\*\\\'\';\' | sqlplus / as sysdba"'

	if db_type.lower() == 'ora':
		out = sapdelete_ora(hostname,username,password,application_sid,clientname,logfile)
		print out

	elif db_type.lower() == 'syb' or db_type.lower() == 'hdb':
		out = sapdelete_syb(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile)
		print out

	elif db_type.lower() == 'db6':
		print db_type.lower()
		out = sapdelete_db2(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile)
		print out
	elif db_type.lower() == 'ada':
		out = sapdelete_maxdb(hostname,username,password,application_sid,clientname,path,db_user,db_password,db_type,logfile)
		print out

	channel.close()
        client.close()

except Exception as e:
    print "POST:F: " + str(e)
