################################################################
#  Script Name: win03.py
#  Author: Anik Chanda
#  Description: user existance check in the target system
#################################################################
# Embedded file name: win03.py
import os
import getpass
import subprocess
import re
from sys import *
try:
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    path = argv[4]
    command = 'c:\\python27\\python ' + path + '\\wmiexec.py ' + username.strip() + ':' + password.strip() + '@' + hostname + " 'exit'"
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    if 'STATUS_LOGON_FAILURE' in out or 'Name or service not known' in out or 'Connection refused' in out:
        print 'PRE:F:user existance check for the ' + hostname + ' is failed'
    else:
        print 'PRE:P:user existance check for the ' + hostname + ' is successful'
except Exception as e:
    if str(e) == '[Errno -2] Name or service not known':
        print 'PRE:F:GERR_0201:Hostname unknown'
    elif str(e).strip() == 'list index out of range':
        print 'PRE:F:GERR_0202:Argument/s missing for the script'
    elif str(e) == 'Authentication failed.':
        print 'PRE:F:GERR_0203:Authentication failed.'
    elif str(e) == '[Errno 110] Connection timed out':
        print 'PRE:F:GERR_0204:Host Unreachable'
    elif 'getaddrinfo failed' in str(e):
        print 'PRE:F:GERR_0205: Please check the hostname that you have provide'
    elif '[Errno None] Unable to connect to port 22' in str(e):
        print 'PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22'
    else:
        print 'PRE:F: ' + str(e)
