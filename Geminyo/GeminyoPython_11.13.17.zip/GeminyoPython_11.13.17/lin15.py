print 'PRE:W:The database type "Hana" is not supported'
