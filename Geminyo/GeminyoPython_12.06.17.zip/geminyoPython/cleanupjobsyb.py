#print 'PRE:W:The database type "Sybase" is not supported'
# -*- coding: utf-8 -*- 
from paramiko import *
import paramiko
from sys import *
import re
import subprocess

#from log4erp import *
try:

	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	database_sid=argv[4].strip()
	db_user = argv[5]
	db_password = argv[6]
	path = argv[7]
	db_type = argv[8]
	
#	user = "syb" + database_sid.lower()

	client = SSHClient()
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	client.connect( hostname,username = username, password = password)
	channel = client.invoke_shell()
	jobtables = ['BTCEVTJOB','BTC_CRITERIA','BTC_CRITNODES','BTC_CRITPROFILES','BTC_CRITTYPES','BTC_TYPEFIELDS','REORGJOBS','TBTCA','TBTCB','TBTCCNTXT','TBTCCTXTT','TBTCCTXTTP','TBTCI','TBTCJSTEP','TBTCO','TBTCP','TBTCR','TBTCS']
	file=open(path.rstrip('/') + "/truncatetable.sql","w+")
#	file.write('use ' + database_sid.upper() + '\n')
#	for i in jobtables:
#		file.write('Truncate TABLE SAPSR3.' + i + '\n')
	if db_type.lower() == "syb":
		user = 'syb' + database_sid.lower()
		file.write('use ' + database_sid.upper() + '\n')
	        for i in jobtables:
                	file.write('Truncate TABLE SAPSR3.' + i + '\n')
		file.write("go");
	elif db_type.lower() == "hdb":
#                user = 'hdb' + application_sid.lower()
		user = database_sid.lower() + 'adm'
		prof_path = "/usr/sap/" + database_sid.upper() + "/SYS/profile"
                command = " echo \" su - " + user + " -c \"\'\"cd " + prof_path + ";ls\"\'\' | grep -i \"" + database_sid.upper() + "_HDB\" |  grep -i " + hostname + "  | grep -v \"\.\"\'| sudo bash "
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                profilefile = ''.join(stdout.readlines()).strip()
                print profilefile

                profilefile1 = profilefile.split("_")[1]
                print profilefile1
                profilefile1 = profilefile1[-2:]
                print profilefile1

		for i in jobtables:
                        file.write('TRUNCATE TABLE ' + i + ';\n') 
#                file.write("exit")
	file.close()

	port = 22

	remote= '/tmp/truncatetable.sql'
        print remote
        local= path + '/truncatetable.sql'
        print local

	transport = paramiko.Transport((hostname, port))
	transport.connect(username = username, password = password)
	sftp = paramiko.SFTPClient.from_transport(transport)
	sftp.put(local, remote)

	if db_type.lower() == "syb":	

#		command = "sudo su - " + user + " -c \'whoami;isql -U" + db_user + " -P" + db_password + " -S"+ database_sid.upper() +" -X -i/tmp/truncatetable.sql \'"""
		command = 'echo "su - ' + user + ' -c "\'"whoami;isql -U" + db_user + " -P" + db_password + " -S"+ database_sid.upper() +" -X -i/tmp/truncatetable.sql"\' | sudo bash'
	elif db_type.lower() == "hdb":
#		command = "sudo su - " + user + " -c \'whoami;hdbsql -U" + db_user + " -P" + db_password + " -S"+ database_sid.upper() +" -I/tmp/truncatetable.sql \'"""
		command = 'echo "su - ' + user + ' -c "\'"whoami;hdbsql -i ' + profilefile1 + ' -u ' + db_user + ' -p ' + db_password + ' -m -I /tmp/truncatetable.sql"\' | sudo bash'

	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	status = stdout.channel.recv_exit_status()
	print status
	out = ''.join(stdout.readlines())
	out = out.split(user)[1].strip()
	print out
	if not out:
		print "PRE:P:Database login  check for " + user + " is successful on  server " + hostname
	else:
		print "PRE:F:Database login  check for " + user + " is failed on  server " + hostname
#p = []
#out = str(out).replace(" ","")
#p = ' \n'.join(out.split()) 
#out= (out.strip()).split('\n')
#print type(p)
#for each in out:
#	print each.split(' ')
	sftp.close()
	transport.close()
	channel.close()
	client.close()
except Exception as e:
        if str(e) == "[Errno -2] Name or service not known":
                print "PRE:F:GERR_0201:Hostname unknown"
        elif str(e).strip() == "list index out of range":
                print "PRE:F:GERR_0202:Argument/s missing for the script"
        elif str(e) == "Authentication failed.":
                print "PRE:F:GERR_0203:Authentication failed for the " + string + " system " + hostname + " for user " + sudo_user
        elif str(e) == "[Errno 110] Connection timed out":
                print "PRE:F:GERR_0204:Host Unreachable"
        elif "getaddrinfo failed" in str(e):
                print "PRE:F:GERR_0205: Please check the hostname that you have provide"
        elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "PRE:F:GERR_0206:Host Unreachable or Unable to connect to port 22"
        else:
                print "PRE:F: " + str(e)

