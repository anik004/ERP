print 'PRE:W:The database type "Sybase" is not supported'
