# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    #hostname = '10.213.63.29'
    #username = 'cgngupta'
    #password = 'B9526em27'
    #sidadm = 'tstadm'

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = str(sid.strip()).lower() + 'adm'


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    """
    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -ibdls.sql\\\"" | sudo bash'
    #command = 'echo "su - ' + sidadm + ' -c \\\"isql -USAPSR3 -PNetra0001 -STST -w9999 -ibdls.sql\\\"" | sudo bash'
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()

    # --------------------------- Get number of rows ----------------------------------------
    for each in out[:-2]:
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each or SWWWIHEAD in each:
            continue
        else:
           each = each.strip()
           command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
            #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table' + num + '.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable' + num + '.sql\\\"" | sudo bash'
           stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
           out = stdout.readlines()
           rowcount = int(out[3].split()[1])
           table_size[rowcount] = each
            #print str(rowcount) + ' : ' + str(each)
    row = sorted(table_size, reverse=True)
    row_top = row[0:16]
    """

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls.txt')
    row_top = file.readlines()
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname):
        # ------------------------------- Get table column names ---------------------------------
	    print tablename
            #tablename = table_size[row_top].strip()
	    rowname = tablename.split()[1]
	    tablename = tablename.split()[0]
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select TOP 1 * from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
	    #print command
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            columnname = out[1]
	    #print columnname
            # ----------------------- Put Case statement --------------------------------------
            wholecolumn = ''
            for each in columnname.split():
	      if rowname in each:
                    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
	      else:
                    wholecolumn = ' ' + wholecolumn + each + ','

            # --------------------------- Conversion ------------------------------------------
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select ' + wholecolumn[:-1].strip() + ' into ' + tablename + '_BDLSS from ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
            print command
	    write(refid + '_det.log', '---------------------------- backup --------------------------------')
	    write(refid + '_det.log', command)
	    #exit()
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            status = stdout.channel.recv_exit_status()
            write(refid + '_det.log', out)
	    print out

            # ------------------------- Rename to _OLD ---------------------------------------
            print status
            if status == 0:
                command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"drop table ' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
                write(refid + '_det.log', '---------------------------- rename to old --------------------------------')
	        write(refid + '_det.log', command)
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                out = stdout.readlines()
                status = stdout.channel.recv_exit_status()
                write(refid + '_det.log', out)

                # ----------------- Rename _BDLS to original ------------------------------
                if status == 0:
                    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + '_BDLSS,' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
                    write(refid + '_det.log', '---------------------------- rename to bdls --------------------------------')
		    write(refid + '_det.log', command)
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                    out = stdout.readlines()
                    status = stdout.channel.recv_exit_status()
                    write(refid + '_det.log', out)
                    if status == 0:
                        print 'The conversion has been completed succesfully for the table ' + tablename.strip()
                        write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())

                    # ------------------------------------- ELSE -------------------------------------------------------
                    else:
                        print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
                else:
                    print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 2'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
            else:
                print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')


    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------
    for each in range (0, len(row_top), 4):
        threadfirst = Thread(target=exebdls, args=(row_top[each], 'first', sidadm, dbuser, dbpasswd, dbname))
	threadfirst.start()
        threadsecond = Thread(target=exebdls, args=(row_top[each + 1], 'second', sidadm, dbuser, dbpasswd, dbname))
	threadsecond.start()
        threadthird = Thread(target=exebdls, args=(row_top[each + 2], 'third', sidadm, dbuser, dbpasswd, dbname))
	threadthird.start()
        threadfourth = Thread(target=exebdls, args=(row_top[each + 3], 'fourth', sidadm, dbuser, dbpasswd, dbname))
	threadfourth.start()
	#exebdls(each, table_size, sidadm, dbuser, dbpasswd, dbname)

        # ------------------ check thread status ------------------------------------------
        flag = True
        while flag == True:
            if threadfirst.isAlive() == True or threadsecond.isAlive() == True or threadthird.isAlive() == True or threadfourth.isAlive() == True:
                flag = True
	    else:
		flag = False

    print 'POST:P: The BDLS is over'
    write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
