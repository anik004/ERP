# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = (str(sid.strip()) + 'adm').lower()

    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------- Get table list with LS --------------------------------------
    exist = os.path.isfile('./bdls.sql')
    if exist == "True":
	    command = 'echo "su - ' + sidadm + ' -c \\\"isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -ibdls.sql\\\"" | sudo bash'
	    print command# this query is used to select the tables which have 'LOGSYS' , 'EDI_PARNUM' , 'ADDRLOGSYS' in their field name
	    write(refid + '_det.log', command)
    	    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	    out = stdout.readlines()
	    write(refid + '_det.log', out)
    exist = os.path.isfile('./bdls.txt')
    if exist == "True":
        os.remove (script_loc +'/bdls.txt')

    # --------------------------- Get number of rows ----------------------------------------
    for each in out[:-2]:
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each:#removing unwanted lines from the output and getting only the tab
lenames and fieldnames.

            continue
        else:
            tablename = each.strip()
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + tablename.split(' ')[0] + '\'\r\ngo\\\\\\\" > table.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable.sql\\\"" | sudo bash'
	    print command
	    write(refid + '_det.log', command)
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
	    write(refid + '_det.log', out)
	    if 'Object does not exist in this database' not in str(out):
                rowcount = int(out[3].split()[1])
                table_size[rowcount] = each
                print str(rowcount) + ' : ' + str(each)
	    else:
		continue

    row_top = sorted(table_size, reverse=True)

    for rownumber in row_top:
            tablename = table_size[rownumber].strip()
	    print 'POST:P:' + tablename  + ':' + str(rownumber)
	    file = open(script_loc +'/bdls.txt', 'a')
	    file.write(tablename + '|' + str(rowcount) + '\n')
	    file.close()

    # ------------------------------- Close connection -----------------------------------------
    channel.close()
    client.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
