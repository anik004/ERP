# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    #hostname = '10.213.63.29'
    #username = 'cgngupta'
    #password = 'B9526em27'
    #sidadm = 'tstadm'

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    sidadm = str(sid.strip()).lower() + 'adm'


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -ibdls.sql\\\"" | sudo bash'
    #command = 'echo "su - ' + sidadm + ' -c \\\"isql -USAPSR3 -PNetra0001 -STST -w9999 -ibdls.sql\\\"" | sudo bash'
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()

    # --------------------------- Get number of rows ----------------------------------------
    for each in out[:-2]:
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each or SWWWIHEAD in each:
            continue
        else:
           each = each.strip()
           command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable.sql\\\"" | sudo bash'
            #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_spaceused \'' + each.strip() + '\'\r\ngo\\\\\\\" > table.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable.sql\\\"" | sudo bash'
           stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
           out = stdout.readlines()
           rowcount = int(out[3].split()[1])
           table_size[rowcount] = each
            #print str(rowcount) + ' : ' + str(each)
    row = sorted(table_size, reverse=True)
    row_top = row[0:16]
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(row_top, table_size, sidadm, dbuser, dbpasswd, dbname):
        # ------------------------------- Get table column names ---------------------------------
#        for rownumber in row_top:
            tablename = table_size[row_top].strip()
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select TOP 1 * from ' + tablename.strip() + '\r\ngo\\\\\\\" > table.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable.sql\\\"" | sudo bash'
	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
            columnname = out[1]
	    print columnname

            # ----------------------- Put Case statement --------------------------------------
            wholecolumn = ''
            for each in columnname.split():
		print "for loop"
                if 'LOGSYS' not in each.strip() and 'EDI_PARNUM' not in each.strip() and 'ADDRLOGSYS' not in each.strip():
                    wholecolumn = ' ' + wholecolumn + each + ','
		    print "wholecolumn"
                else:
                    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
		    print "else part"

            # --------------------------- Conversion ------------------------------------------
            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select ' + wholecolumn[:-1].strip() + ' into ' + tablename + '_BDLS from ' + tablename.strip() + '\r\ngo\\\\\\\" > table.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable.sql\\\"" | sudo bash'
            print command
            stdin, stdout, stderr = client.exec_command(command, get_pty=True)
            out = stdout.readlines()
            status = stdout.recv_exit_status()

            # ------------------------- Rename to _OLD ---------------------------------------
            if status == 1:
                command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + ' ' + tablename.strip() + '_OLD\r\ngo\\\\\\\" > table.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable.sql\\\"" | sudo bash'
                print command
                stdin, stdout, stderr = client.exec_command(command, get_pty=True)
                out = stdout.readlines()
                status = stdout.recv_exit_status()

                # ----------------- Rename _BDLS to original ------------------------------
                if status == 1:
                    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + '_BDLS ' + tablename.strip() + '\r\ngo\\\\\\\" > table.sql; isql -USAPSR3 -PNetra0001 -STST -w9999 -itable.sql\\\"" | sudo bash'
                    print command
                    stdin, stdout, stderr = client.exec_command(command, get_pty=True)
                    out = stdout.readlines()
                    status = stdout.recv_exit_status()
                    if status == 1:
                        print 'The conversion has been completed scueesfully for the table ' + tablename.strip()
                        write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M:%S ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())

                    # ------------------------------------- ELSE -------------------------------------------------------
                    else:
                        print 'The conversion has not been completed scueesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M:%S ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
                else:
                    print 'The conversion has not been completed scueesfully for the table ' + tablename.strip() + ' with error code: 2'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M:%S ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
            else:
                print 'The conversion has not been completed scueesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M:%S ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')


    # ------------------------- Execute the function -----------------------------------------
    first = 0
    second = 4
    third = 8
    fourth = 12
    print "erp"

    # --------------------------- Loop for four sets ------------------------------------------
    for each in range(1, 5):
	print "test"	
        #threadfirst = Thread(target=exebdls, args=(row_top[first], table_size, sidadm))
        #threadsecond = Thread(target=exebdls, args=(row_top[second], table_size, sidadm))
        #threadthird = Thread(target=exebdls, args=(row_top[third], table_size, sidadm))
        #threadfourth = Thread(target=exebdls, args=(row_top[fourth], table_size, sidadm))

	exebdls(row_top[first], table_size, sidadm, dbuser, dbpasswd, dbname)

        # ------------------ check thread status ------------------------------------------
        flag = True
	print flag
        while flag == True:
            if threadfirst.isAlive() == True or threadsecond.isAlive() == True or threadthird.isAlive() == True or threadfourth.isAlive() == True:
                flag = True
		print "sap"
            else:
                flag = False
                first = first + 1
                second = second + 1
                third = third + 1
                fourth = fourth + 1

    print 'POST:P: The BDLS is over'
    write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M:%S ") + ' The BDLS is over')

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M:%S ") + " The execution has failed with the error: " + str(e))
