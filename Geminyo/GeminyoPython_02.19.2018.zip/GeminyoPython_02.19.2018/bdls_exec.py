################################################################
#  Script Name: wrp_bdls_exec.py
#  Description: wrapper for calling bdls_exec.py scripts according to database type
################################################################

# ---------------------------------- Improt Modules ---------------------------------------------
import os
from os import *
import sys
from sys import *
from log4erp import *
import subprocess
from subprocess import *

try:
	hostname = argv[1]
	username = argv[2]
	password = argv[3]
	sid = argv[4]
	dbuser = argv[5]
	dbpasswd = argv[6]
	dbname = argv[7]
	oldls = argv[8]
	newls = argv[9]
	refid = argv[10]
	script_loc = argv[11].rstrip('/')
	clientname = argv[12]
	profile_path = argv[13]
	dbtype = argv[14]

	local_os = os.name


	######################### LINUX ##############################################################

	if local_os.lower() == 'posix':

                ################## ORACLE ###########################

		if dbtype.lower() == 'ora':
			command = "python " + script_loc.rstrip('/') + "/ora_bdls_exec.py " + hostname + " " + username + " " + password + " " + sid + " " + dbuser + " " + dbpasswd + " " + dbname + " " + oldls + " " + newls + " " + refid + " " + script_loc + " " + clientname
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
			status = command.returncode
			if status == 0:
				print "Script ora_bdls_exec.py is executed successfully"
			else:
				print "Script ora_bdls_exec.py is not executed successfully"
				exit()

		################## SYBASE ###############################

		elif dbtype.lower() == 'syb': 
			command = "python " + script_loc.rstrip('/') + "/syb_bdls_exec.py " + hostname + " " + username + " " + password + " " + sid + " " + dbuser + " " + dbpasswd + " " + dbname + " " + oldls + " " + newls + " " + refid + " " + script_loc + " " + clientname
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
			status = command.returncode
                        if status == 0:
				print "Script bdls_exec.py is executed successfully"
			else:
                                print "Script bdls_exec.py is not executed successfully"
                                exit()
		
		################## MAXDB #############################
		elif dbtype.lower() == 'ada':
			command = "python " + script_loc.rstrip('/') + "/max_bdls_exec.py " + hostname + " " + username + " " + password + " " + sid + " " + dbuser + " " + dbpasswd + " " + dbname + " " + oldls + " " + newls + " " + refid + " " + script_loc + " " + clientname
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
                        status = command.returncode
                        if status == 0:
                                print "Script bdls_exec.py is executed successfully"
                        else:
                                print "Script bdls_exec.py is not executed successfully"
                                exit()



		################## DB2 ###################################

		elif dbtype.lower() == 'db6':
                        command = "python " + script_loc.rstrip('/') + "/db2_bdls_exec.py " + hostname + " " + username + " " + password + " " + sid + " " + dbuser + " " + dbpasswd + " " + dbname + " " + oldls + " " + newls + " " + refid + " " + script_loc + " " + clientname
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
			status = command.returncode
                        if status == 0:
				print "Script db2_bdls_exec.py is executed successfully"
			else:
                                print "Script db2_bdls_exec.py is not executed successfully"
                                exit()

		
		################## HANA ###################################
		
		elif dbtype.lower() == 'hdb':
                        command = "python " + script_loc.rstrip('/') + "/hdb_exec_bdls.py " + hostname + " " + username + " " + password + " " + sid + " " + dbuser + " " + dbpasswd + " " + dbname + " " + oldls + " " + newls + " " + refid + " " + script_loc + " " + clientname + " " + profile_path
                        command=subprocess.Popen(command,shell=True,stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        print out
			status = command.returncode
                        if status == 0:
				print "Script hbd_exec_bdls.py is executed successfully"
			else:
                                print "Script hbd_exec_bdls.py is not executed successfully"
                                exit()

		###################### other DB ########################

		else:
			print "script not found for os " + local_os.upper() + " and DB "+ dbtype.upper() + " combination"
			exit()

	################ other OS ##################

	else:
		print "scriptr not found for" + local_os + " os combination "
		exit()


################## EXECPTION ##################

except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))

