################################################################
#  Script Name: ora_bdls_table.py
#  Description: list the tables in bdls.txt file on which the bdls conversion needs to be done
################################################################


# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    #hostname = '10.213.63.29'
    #username = 'cgngupta'
    #password = 'B9526em27'
    #sidadm = 'tstadm'

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = "ora" + sid.lower().strip()
    sidadm = sidadm.lower()


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------- Get table list with LS --------------------------------------
    command = "echo \"su - " + sidadm + " -c \"\\\"\"sqlplus / as sysdba @bdls_ora.sql\"\\\" | sudo bash"
    print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()
#    print out
    exist = os.path.isfile(script_loc + '/bdls.txt')
    if exist == True:
        os.remove (script_loc +'/bdls.txt')

    #print out
    temp = open('temp.txt','w+')
   # print out[12:]
    #exit()
    for i in out[12:]:

     	
	if str(i) != ' ' or str(i) != '\r\n':
		 if '----' in i or 'TABNAME' in i or '(' in i or ')' in i or 'rows' in i  or not i or 'FIELDNAME' in i:
			continue
		 else:
			table_field = i.split('\n')
			#print table_field[0]
			#exit()
			temp.write(table_field[0].strip()+',')

    temp.close()
    #exit()
    temp2 = open('temp.txt','r').readlines()[0]
#    print temp2
    temp3 = temp2.split(',,') 
#    print len(temp3)
    #print temp3
  
    table = ''
    tab = open('table.txt','w+')
    for i in temp3:
	 if i != []:
		 i = i.lstrip(',')
		 if len(i.split(',')) == 2:
#			 print i
			 
			 table = i.split(',')[0] + '\t' + i.split(',')[1] + '\n'
   			 tab.write(table)    
	
    
#    file = open("tst.txt", "w+")
#    file.write(str(out).split('\n'))
    tab.close()
 #   print os.path.isfile(script_loc +'/bdls.txt')
    if os.path.isfile(script_loc +'/bdls.txt') == True:
	    os.remove (script_loc +'/bdls.txt')
    # --------------------------- Get number of rows ----------------------------------------
    file_table = open('table.txt','r').readlines()
 #   print len(file_table)
    out = file_table
    for each in out:
#	print each
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each:
            continue
        else:
	    tablename = each.split('\t')
	  
            tablename = each.strip()
	#    print tablename
	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"SELECT COUNT(*) FROM SAPSR3.' + tablename.split('\t')[0] + ';\\\\\\\" | sqlplus / as sysdba\\\"" |grep "COUNT"| sudo bash' 
#	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
#	    print out
	    out = out[13].strip()
	   
            rowcount = int(out)
            table_size[rowcount] = each
    row_top = sorted(table_size, reverse=True)
  #  print row_top  
    for rownumber in row_top:

            tablename = table_size[rownumber].strip()
#	    print tablename
	    print 'POST:P:' + tablename  + ':' + str(rownumber)
	    file = open(script_loc +'/bdls.txt', 'a')
	    file.write(tablename + '\n')
	    file.close()
    # ------------------------------- Close connection -----------------------------------------
    channel.close()
    client.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
