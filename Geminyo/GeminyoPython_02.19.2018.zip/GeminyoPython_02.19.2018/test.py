import paramiko
from paramiko import *

try:
	hostname = 'sapredhat01'
	username = 'root'
	password = 'amigo123'
	db_user = 'system'
	db_passwd = 'Welcome2'
	sid = 'qrp'
	user = sid + 'adm'

	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()
	command = "echo \"su - " + user + " -c \'\"\'echo \"exit;\" | sqlplus -s  "+ db_user.strip() + "/" + db_passwd.strip() + "\'\"\'\" | grep -i \"ERROR:\" | grep -v \"#\"|sudo bash "
	command = "echo \"su - " + user + " -c \"\\\"\"echo 'exit;' | sqlplus -s  "+ db_user.strip() + "/" + db_passwd.strip() + "\"\\\" | grep -i \"ERROR:\" | grep -v \"#\"|sudo bash "
	command = "echo \"su - " + user + " -c \"\\\"\"echo 'exit;' | sqlplus -s  "+ db_user.strip() + "/" + db_passwd.strip() + "\"\\\" | sudo bash | grep -i \"ERROR:\" | grep -v \"#\""
	print command
	stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	print stdout.readlines()

except Exception as e:
	print str(e)
