################################################################
#  Script Name: win00.py
#  Author: Anik Chanda
#  Description: resolve hostname to get the IP address
################################################################
# Embedded file name: win00.py
import subprocess
from sys import *
try:
    if argv[1] == '--u':
        print 'usage: ip_check.py <target hostname> <Target/Source>'
    else:
        hostname = argv[1]
        command = ''
        command = 'ping -n 1 ' + hostname
        print command
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print out
        if out:
            print 'PRE:P:The IP of the target is- ' + str(out.split('\r\n')[2].split(' ')[2][:-1])
        else:
            print 'PRE:F:The hostname is not able to resolve'
except Exception as e:
    if 'unknown host' in str(e):
        print 'PRE:F: Unknown Host'
    elif str(e) == 'list index out of range':
        print 'PRE:F: Argument/s missing'
    else:
        print 'PRE:F: Script has exited with the error: ' + str(e)
