command = "echo \"su - " + t_sid.lower()+ "adm" + " -c \"\'\"tp import " + tr_id + " " + t_sid  + " Client=000 pf=" + t_path + "/bin/TP_" + domain + ".PFL U123689 \"\'\'| grep -i \"tp finished with return code:\" | tail -n 1 | cut -d \":\" -f2\' | sudo bash"
print command
