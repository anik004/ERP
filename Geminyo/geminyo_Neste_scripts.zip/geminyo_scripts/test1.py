import sys
from sys import *
import paramiko
from paramiko import *
	
hostname = argv[1]
username = argv[2]
password = argv[3]
application_sid = argv[4].lower()
db_sid = argv[5].lower()
profile_path = argv[6].rstrip("/")
db_type = argv[7]
schema = argv[8]
schema_password = argv[9]
db_hostname = argv[10]

client = SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect( hostname,username = username, password = password)
channel = client.invoke_shell()

user = application_sid.lower() + "adm"

command = "echo \"su - " + user + " -c \"\'\"hdbuserstore SET DEFAULT " + db_hostname + ":30015 " + schema + " " + "'" + schema_password  + "' \"\' | sudo bash "
print command
stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
output = stdout.readlines()
print output

command = "echo \" su - " + user + " -c \"\'\"hdbuserstore list\"\'| sudo bash "
print command
stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
output = stdout.readlines()
print output

if schema in str(output):
	print "POST:P: SECSTORE/User Store password reset is successful"
        #write(logfile, "POST:P: SECSTORE/User Store password reset is successful")
else:
        print "POST:F: SECSTORE/User Store password reset failed"
       #write(logfile, "POST:F:SECSTORE/User Store password reset failed")
channel.close()
client.close()
