delete from USR02 where MANDT='100' and BNAME='SAP*'
