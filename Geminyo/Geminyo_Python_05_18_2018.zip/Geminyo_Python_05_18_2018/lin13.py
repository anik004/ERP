print 'PRE:W:This database type "MSSQL" does not support this check'
