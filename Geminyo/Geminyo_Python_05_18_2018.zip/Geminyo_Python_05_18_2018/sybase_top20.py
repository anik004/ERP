import os
import paramiko
import sys
from paramiko import *

try:
	sql = 'select convert(varchar(30),o.name) AS table_name from sysobjects o where type = 'U' order by table_name'
	username = 'root'
	passwd = 'amigo123'
	db_user = 'srpadm'
	db_passwd = 'amigo123'
	db_name = 'SRP'
	hostname = '10.115.117.107'
	os_name = 'nt'
	location = 'f:'
	
	if os_name.lower() == 'posix':
		client = SSHClient()
        	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        	client.connect(hostname,username = username, password = passwd)
        	channel = client.invoke_shell()

		command = 'echo "' + sql + '" | isql -U ' + db_user + ' -P ' + db_passwd + ' -D ' + db_name + ' -S ' +  hostname
		print command
		#stdin, stdout, stderr = client.exec_command(schema, timeout=1000, get_pty=True)
		#output = stdout.readlines()
		#print output
		
	elif os_name.lower() == 'nt':
		command = 'c:\python27\python ' + location.strip('\\') + '\wmiexec.py ' + username.strip() + ':' + passwd.strip() + '@' + hostname + ' \'echo "' + sql + '" | isql -U ' + db_user + ' -P ' + db_passwd + ' -D ' + db_name + ' -S ' +  hostname + '\''
		print command
		#command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		#out, err = command.communicate()
		#print out


except Exception as e:
	print str(e)
