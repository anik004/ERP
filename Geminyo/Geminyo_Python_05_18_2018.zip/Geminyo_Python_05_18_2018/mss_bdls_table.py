# ---------------------------------- Import Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import subprocess
from subprocess import *

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('\\')
    profile_path = argv[12].rstrip('\\')

    #-------------------------Find instance name -----------------------------
    command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -L"'
    print command
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    out = out.split()
    for each in out:
        if hostname in each:
            servername = each.strip()
    print servername
    # ------------------------- Get table list with LS --------------------------------------
    command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -i \\"' + profile_path[:2] + '\\bdls_mss.sql\\""'
    print command
    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out, err = command.communicate()
    out = out.split('dialect used')
    out = out[1].split('\r\n')
    out = filter(None,out)
    #print out

    exist = os.path.isfile(script_loc + '\\bdls.txt')
    if exist == True:
        os.remove (script_loc +'\\bdls.txt')
    # --------------------------- Get number of rows ----------------------------------------
    for each in out:
        each = each.strip()
        if '----' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each or 'Changed database' in each:
            continue
        else:
            tablename = each.strip()
            flag = 0
            #print tablename

            command = 'c:\\python27\\python ' + script_loc.strip('\\') + '\\wmiexec.py ' + username.strip() + ':' + password + '@' + hostname + ' "sqlcmd -S ' + servername + ' -d master -E -Q \\"set nocount on;use ' + sid.upper() + ';select count(*) from ' + sid.lower() + '.' + tablename.split()[0] + '\\""'
            #print command
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            out = out.split("\r\n")
            out = filter(None,out)
            print out[-1].strip()
            rowcount = int(out[-1].strip())

            table_sorted = table_size.items()
            print table_sorted
            for each_sorted in table_sorted:
                if tablename.split()[0].strip() in each_sorted[1].split()[0].strip():
                    print 'table :' + tablename.strip() + ' ' + str(rowcount)
                    table_size[rowcount] = table_size[rowcount].strip() + ';' + each.split()[1].strip() + ';'
                    #                       print 'table :' +  table_size[rowcount]
                    flag = 1
                    break
            if flag != 1:
                #rowcount = int(out)
                table_size[rowcount] = each.strip() + ';'
                #            table_size[rowcount] = each
    row_top = sorted(table_size, reverse=True)

    #rowcount = int(out[-1].strip())
    #table_size[rowcount] = each
#            print str(rowcount) + ' : ' + str(each)
#    row_top = sorted(table_size, reverse=True)
    #    row_top = row[0:16]
    print row_top

    for rownumber in row_top:
        tablename = table_size[rownumber].strip()
        print 'POST:P:' + str(tablename) + ':' + str(rownumber)
        file = open(script_loc + '\\bdls.txt', 'a')
        file.write(tablename + '\n')
        file.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)

