# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = str(sid.strip()) + 'adm'
    sidadm = sidadm.lower()

#    print sidadm
    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i bdls_max.sql | grep -v \'OK\' | grep -v \"CONTINUE\"\\\"" | sudo bash'
    print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()

    print out
    exist = os.path.isfile(script_loc + '/bdls_' + refid + '.txt')
    if exist == True:
        os.remove (script_loc +'/bdls_' + refid + '.txt')
    # --------------------------- Get number of rows ----------------------------------------
    for each in out:
	each = each.strip()
	
        if '---' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or '/' in each or not each:
            continue
        else:
	    tablename = each.split('|')[1].strip() +'|' + ';' + each.split('|')[2].strip()
	    print tablename


	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select rowcount from sysinfo.tablesize where tablename=\''+ tablename.split('|')[0] + '\'\\\\\\\" > table.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i table.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
	    print out
            print "hello"
	    flag = 0
	    if '* 0: ' not in str(out):
#	   	    print (str(out[2].strip('|')).strip()).strip('|')
#            rowcount = int((str(out[2].strip('|')).strip()).strip('|'))
		rowcount = (str(out[2].strip('|')).strip()).strip('|')
                rowcount = int(rowcount.strip())
		table_sorted = table_size.items()
		print table_sorted
		for each_sorted in table_sorted:
		    if tablename.split('|')[0].strip() in each_sorted[1].split('|')[0].strip():
			table_size[rowcount] = table_size[rowcount].strip() +  each.split('|')[2].strip() + ';'		    	
			flag = 1
			break
		if flag != 1:
			table_size[rowcount] = each.split('|')[1].strip() + '|' +  each.split('|')[2].strip() + ';'
	    else:
		continue
	    
#	    print rowcount
            #table_size[rowcount] = each
#	    table_size[rowcount] = each.split('|')[1].strip() + ';' + each.split('|')[2].strip()
#            print str(rowcount) + ' : ' + str(each)
#	    print table_size[rowcount]
    row_top = sorted(table_size, reverse=True)
#    row_top = row[0:16]
#    print row_top
    for rownumber in row_top:
            tablename = table_size[rownumber].strip()
	    print 'POST:P:' + tablename +':' + str(rownumber)
	    file = open(script_loc +'/bdls_' + refid + '.txt', 'a')
	    file.write(tablename + '\n')
	    file.close()
    file = open(script_loc +'/bdls_' + refid + '.txt', 'a')
    file.write('T000|LOGSYS;\n')
    file.close()

    # ------------------------------- Close connection -----------------------------------------
    channel.close()
    client.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
