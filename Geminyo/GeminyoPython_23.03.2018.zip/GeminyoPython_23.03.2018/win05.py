# Embedded file name: win05.py
print 'PRE:F:Script does not exist'