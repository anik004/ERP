# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime
from datetime import datetime
import time

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''

    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    clientname = argv[12]
    sidadm = str(sid.strip()).lower() + 'adm'
    write(refid + '_BDLS_detailed.log', "BDLS execution : " + refid + " starting at " + strftime("%Y-%m-%d %H:%M "))
    starttime = strftime("%H:%M:%S")
    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls_' + refid + '.txt')
    row_top = file.readlines()

#   print row_top
#   print "first " + row_top[0]
#   print "second " + row_top[1]
#   print "third " + row_top[2]
#   print "fourth " + row_top[3]

    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname, clientname, sid):
        # ------------------------------- Get table column names ---------------------------------
	    start_time = strftime("%H:%M:%S")
#	    print "tabele "+num + " "+ tablename
	    rowname = tablename.split('|')[1].strip()
#	    print rowname
	    tablename = tablename.split('|')[0].strip()
#	    print  tablename
#	    print log_content
	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select columnname from domain.columns where tablename=\''+ tablename.strip() + '\'\\\\\\\" > table' + num + '.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i table' + num + '.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
	    print command
	    write(refid + '_det.log',command)
	    write(refid + '_' + num +'_det.log',command)
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            columnname = out
	    write(refid + '_det.log',str(columnname))
	    write(refid + '_' + num +'_det.log',str(columnname))
	    print columnname
            # ----------------------- Put Case statement --------------------------------------
	    update_query = ''
	    colum = rowname.split(';')
	    print colum
	    
	    col = ''
	    colwhen = ''

	    for each_column in colum:
		if each_column.strip():
			update_query = update_query + 'update of SAP' + sid.upper() + '.'  + tablename + ' set ' + each_column.strip() +' = \'' + newls + "\' where " + each_column.strip() + " = \'" + oldls  + '\'\n//\n'

	    exist = os.path.isfile(script_loc + '/testfile_' + num + ".txt")
	    if exist == True:
        	os.remove (script_loc +'/testfile_' + num + ".txt")
	    print 'update query:' + update_query
	   
	    f1 = open(script_loc +"/testfile_" + num + ".txt","w+")
	    f1.write(update_query)
	    f1.close()
	    port = 22
	    write(refid + '_det.log',update_query)
	    write(refid + '_' + num +'_det.log',update_query)
	    remote= '/home/' + sid.lower()+'adm/tableconv' + num + '.sql' 
 #           print remote
            local= script_loc + '/testfile_' + num +'.txt'
#            print local

            transport = paramiko.Transport((hostname, port))
            transport.connect(username = username, password = password)
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.put(local, remote)
	    command = 'echo "su - ' + sidadm + ' -c \\\"sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i tableconv' + num + '.sql | grep -v \'OK\' | grep -v \"CONTINUE\"\\\"" | sudo bash'
#    	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()  
#            print out
	    write(refid + '_det.log',str(out))
	    write(refid + '_' + num +'_det.log',str(out))
#	    print stdout.channel.recv_exit_status()
            if not out or '* 0: ' in str(out):
		end_time = strftime("%H:%M:%S")
		FMT = '%H:%M:%S'
	        duration = datetime.strptime(end_time, FMT) - datetime.strptime(start_time, FMT)
                print 'The conversion has been completed succesfully for the table ' + tablename.strip()
                write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())
#		write(refid + '_BDLS_detailed.log','POST|P|' +  tablename.strip() + ' | ' + str(duration) + ' | ' + str(row_num) )
#		if len(str(row_num).split()) == 3:
		write(refid + '_BDLS_detailed.log', '\nclient: ' + clientname + " from " + oldls + " to " + newls + " Table " + tablename.strip() + ' ' + ' duration ' + str(duration) +  ' ')

	    
            else:
                print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')
	   

    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------
#    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname, clientname, sid)
#    exebdls(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname, sid)
#    exebdls(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname, sid)
#    exebdls(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname, sid)

    threadfirst = Thread(target=exebdls, args=(row_top[0], 'first', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
 #   print "threadfirst"
    threadfirst.start()
    threadsecond = Thread(target=exebdls, args=(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#    print "threadsecond"
    threadsecond.start()

    threadthird = Thread(target=exebdls, args=(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#    print "threadthird"
    threadthird.start()

    threadfourth = Thread(target=exebdls, args=(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#    print "threadfourth"
    threadfourth.start()
    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1

    for each in row_top[4:]:


        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
                if flag_first == 0:
                        threadfirst = Thread(target=exebdls, args=(each, 'first', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#			print "threadfirst " + each
			threadfirst.start()
                        flag_first = 1
			break
		if flag_second == 0:
			threadsecond = Thread(target=exebdls, args=(each, 'second', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#			print "threadsecond " + each
			threadsecond.start()
			flag_second=1
			break
		if flag_third == 0:
			threadthird = Thread(target=exebdls, args=(each, 'third', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#			print "threadthird " + each
			threadthird.start()
			flag_third=1
			break
		if flag_fourth == 0:
			threadfourth = Thread(target=exebdls, args=(each, 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname, sid))
#			print "threadfourth " + each
			threadfourth.start()
			flag_fourth = 1
			break



#------------------------------is alive---------------------------------
		if threadfirst.isAlive() == False:
			flag_first = 0
			print "thread first is not alive"

		if threadsecond.isAlive() == False:
			flag_second=0
			print "thread second  is not alive"
		
		if threadthird.isAlive() == False:
			flag_third = 0
			print "thread third  is not alive"

		if threadfourth.isAlive() == False:
                        flag_fourth = 0
			print "thread fourth is not alive"


		

    print "end of first loop"
    while threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
		if threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:

			continue
		else:
			print "end of second loop"
			break



    print 'POST|P|The BDLS is over'
    endtime = strftime("%H:%M:%S")
    
    FMT = '%H:%M:%S'
    total_duration = datetime.strptime(endtime, FMT) - datetime.strptime(starttime, FMT)
    write(refid + '.log', "POST:P: " + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')
    write(refid + '_BDLS_detailed.log','\nThe BDLS is completed for ' + clientname + ' ' +  strftime("%Y-%m-%d %H:%M "))
    logf = open(refid + '_BDLS_detailed.log', 'r')
    count = 0
    logfl = logf.readlines()
    for each in logfl:
	   if "client: " + clientname + " from " + oldls + " to " + newls in str(each):
			count = count + 1	
    logf.close()
    write(refid + '_BDLS_detailed.log','\ntotal duration ' + str(total_duration))
    write(refid + '_BDLS_detailed.log', str(count)+' tables are converted for ' + clientname + ' ' )
 

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
