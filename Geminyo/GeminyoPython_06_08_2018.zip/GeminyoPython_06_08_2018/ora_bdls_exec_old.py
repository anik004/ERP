# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime
from datetime import datetime

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''


    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    clientname = argv[12].strip()

    sidadm = "ora" + str(sid.strip()).lower()  


    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls.txt')
    row_top = file.readlines()
#    print row_top
   
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname, clientname):
        # ------------------------------- Get table column names ---------------------------------
            #tablename = table_size[row_top].strip()
	    start_time = strftime("%H:%M:%S")
	    rowname = tablename.split()[1]
	    tablename = tablename.split()[0]
	    #print 'tablename: ' + str(tablename)
	    #print 'rwoname: ' + str(rowname)

	    schema = "echo \"su - " + sidadm + " -c \"\\\'\"echo \\$dbs_ora_schema\"\\\' | sudo bash"
	    print schema
	    stdin, stdout, stderr = client.exec_command(schema, timeout=100000, get_pty=True)
	    schema = stdout.readlines()[0]

	    print schema
	
	    #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select * from ' + schema.strip()  + '.' + tablename.strip()  + ' where ROWNUM = 1;\\\\\\\" | sqlplus / as sysdba\\\"" | sudo bash'
	    
	    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select column_name from all_tab_columns where table_name = \'' + tablename.strip() + '\';\\\\\\\" | sqlplus / as sysdba\\\"" | sudo bash'
	    print command
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
	    print out
            columnname = out[11:-4]
#	    print columnname
	    fieldname = ''
	    for each in columnname:
		if "COLUMN_NAME" not in each and "----" not in each:
		    b= str(each.strip()).split('\n')
#			a = a.append(b)
	#	    print each.strip()
		    if each != '':
			for each in b:
				each = filter(None,each )
				fieldname = fieldname + each + ','
	    fieldname = fieldname.split(',')
	    fieldname = filter(None,fieldname)
#	    print abc
				
	    #for each in abc:
	#	print each
	#	if rowname in each:
	#		print "hi"				
			
	    
            # ----------------------- Put Case statement --------------------------------------
	    wholecolumn = ''
			
            for each in fieldname:

            	if rowname in each:
			if 'MANDT' in fieldname:
#				    print each
#                           wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                	            wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' and MANDT=\'" + clientname + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
#				    print "wholecolumn"
			else:
				    print "whole"
				    wholecolumn = ' ' + wholecolumn + ' (CASE WHEN ' + each.strip() + "=\'" + oldls + "\' THEN \'" + newls + "\' ELSE " + each.strip() + " END) AS " + each.strip() + ','
                else:
                	wholecolumn = ' ' + wholecolumn + each + ','
			    	#rint wholecolumn[:-1].strip()
	    print wholecolumn
            # --------------------------- Conversion ------------------------------------------
	    command =  'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"CREATE TABLE ' + schema.strip() + '.'  + tablename + '_BDLSS as select ' + wholecolumn[:-1].strip() + ' from '  + schema.strip() + '.' + tablename + ';\\\\\\\" | sqlplus / as sysdba\\\"" | sudo bash'
            print command
	    write(refid + '_det.log', '---------------------------- backup --------------------------------')
	    write(refid + '_det.log', command)
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
	    print out
	    """
	    row_num = out[-1].strip() 
	    row_num = row_num.strip("(").strip(")")
	    print row_num
	    exit()
	    #print "row_num = " + row_num
	    """
	    
            status = stdout.channel.recv_exit_status()
            write(refid + '_det.log', out)
	    print status	    
	    

            # ------------------------- Rename to _OLD ---------------------------------------
            print status
            if status == 0:
                command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"drop table ' + schema.strip() + '.' + tablename.strip() + ';\\\\\\\" | sqlplus / as sysdba \\\"" | sudo bash'
                write(refid + '_det.log', '---------------------------- rename to old --------------------------------')
	        write(refid + '_det.log', command)
                print command
                stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                out = stdout.readlines()
		print out
                status = stdout.channel.recv_exit_status()
                write(refid + '_det.log', out)
#		print out
		print status

                # ----------------- Rename _BDLS to original ------------------------------
                if status == 0:
#                    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"sp_rename ' + tablename.strip() + '_BDLSS,' + tablename.strip() + '\r\ngo\\\\\\\" > table' + num + '.sql; isql -U' + dbuser + ' -P' + dbpasswd + ' -S' + dbname + ' -w9999 -itable' + num + '.sql\\\"" | sudo bash'
		    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"alter table ' + schema.strip() + '.' + tablename.strip() + '_BDLSS rename to ' + tablename.strip() + ';\\\\\\\" | sqlplus / as sysdba \\\"" | sudo bash'
                    write(refid + '_det.log', '---------------------------- rename to bdls --------------------------------')
		    write(refid + '_det.log', command)
                    print command
                    stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
                    out = stdout.readlines()
		    print out
		    print "sp_rename"
#		    print out
                    status = stdout.channel.recv_exit_status()
                    write(refid + '_det.log', out)
		    end_time = strftime("%H:%M:%S")
		    FMT = '%H:%M:%S'
	            duration = datetime.strptime(end_time, FMT) - datetime.strptime(start_time, FMT)
		    print duration
                    if status == 0:
                        print 'The conversion has been completed succesfully for the table ' + tablename.strip()
                        write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())
		        write(refid + '_BDLS_detailed.log','POST:P:' +  tablename.strip() + ' | ' + str(duration)  )

                    # ------------------------------------- ELSE -------------------------------------------------------
                    else:
                        print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')
                else:
                    print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 2'
                    write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 2')
            else:
                print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 3'
                write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 3')


    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------

    #print row_top[0]
    
#    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname)
#    exit()

    threadfirst = Thread(target=exebdls, args=(row_top[0], 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfirst.start()
    exit()
    threadsecond = Thread(target=exebdls, args=(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadsecond.start()
    threadthird = Thread(target=exebdls, args=(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadthird.start()
    threadfourth = Thread(target=exebdls, args=(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfourth.start()

    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1

    for each in row_top[4:]:

        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
                if flag_first == 0:
                        threadfirst = Thread(target=exebdls, args=(each, 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfirst.start()
                        flag_first = 1
			print "Assigning thread first with " + str(each)
			break
		if flag_second == 0:
			threadsecond = Thread(target=exebdls, args=(each, 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadsecond.start()
			flag_second=1
			print "Assigning thread second with " + str(each)
			break
		if flag_third == 0:
			threadthird = Thread(target=exebdls, args=(each, 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadthird.start()
			flag_third=1
			print "Assigning thread third with " + str(each)
			break
		if flag_fourth == 0:
			threadfourth = Thread(target=exebdls, args=(each, 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfourth.start()
			flag_fourth = 1
			print "Assigning thread fourth with " + str(each)
			break

#------------------------------is alive---------------------------------
		if threadfirst.isAlive() == False:
			flag_first = 0
			print "thread first is not alive"

		if threadsecond.isAlive() == False:
			flag_second=0
			print "thread second  is not alive"
		
		if threadthird.isAlive() == False:
			flag_third = 0
			print "thread third  is not alive"

		if threadfourth.isAlive() == False:
                        flag_fourth = 0
			print "thread fourth is not alive"

    """
    while flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
		if flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
			continue
		else:
			break
    """
    print "first loop completed"
    while threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
    	if threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
		continue
	else:
		print "second loop completed"
		break
    print 'POST|P|The BDLS is over'
    write(refid + '.log', "POST:P: " + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')
    write(refid + '_BDLS_detailed.log','POST|P|The BDLS is over' )
   

    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
