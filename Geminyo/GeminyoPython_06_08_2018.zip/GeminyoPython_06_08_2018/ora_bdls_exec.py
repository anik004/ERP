################################################################
#  Script Name: ora_bdls_exec.py
#  Description: the logical system name conversion will be done in the tables and threading is used here.
################################################################

# ---------------------------------- Improt Modules ---------------------------------------------
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
from time import strftime
from datetime import datetime

try:
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''


    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    clientname = argv[12].strip()

    sidadm = "ora" + str(sid.strip()).lower()  
    write(refid + '_BDLS_detailed.log', "BDLS execution : " + refid + " starting at " + strftime("%Y-%m-%d %H:%M "))
    starttime = strftime("%H:%M:%S")

    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------------ Read file and get top 16 ------------------------------------
    file = open (script_loc + '/bdls_'+ refid +'.txt')
    row_top = file.readlines()
#    print row_top
   
    # ----------------------------------- Function for Threading ---------------------------------
    def exebdls(tablename, num, sidadm, dbuser, dbpasswd, dbname, clientname):
        # ------------------------------- Get table column names ---------------------------------
            #tablename = table_size[row_top].strip()
	    start_time = strftime("%H:%M:%S")
	    rowname = tablename.split()[1]
	    tablename = tablename.split()[0]
	    #print 'tablename: ' + str(tablename)
	    #print 'rwoname: ' + str(rowname)
	    file2 = open (script_loc + '/' + refid + '_BDLS_detailed.log')
            log_content = file2.read() 
	    if 'POST|P|' + tablename+  ' |' in  log_content:
                return

	    schema = "echo \"su - " + sidadm + " -c \"\\\'\"echo \\$dbs_ora_schema\"\\\' | sudo bash"
#	    print schema
	    stdin, stdout, stderr = client.exec_command(schema, timeout=100000, get_pty=True)
	    schema = stdout.readlines()[0]

#	    print schema
	
	    #command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select * from ' + schema.strip()  + '.' + tablename.strip()  + ' where ROWNUM = 1;\\\\\\\" | sqlplus / as sysdba\\\"" | sudo bash'
	    command = 'echo "su - ' + sidadm + ' -c "\'"echo \\\"select column_name from all_tab_columns where table_name = \'"\'' + tablename.strip() + '\';"\'\\\" | sqlplus / as sysdba"\' | sudo bash'
	    print command
	    write(refid + '_det.log',command)
            write(refid + '_' + num +'_det.log',command) 
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
#	    print out
            columnname = out[11:-4]
#	    print columnname
	    fieldname = ''
	    for each in columnname:
		if "COLUMN_NAME" not in each and "----" not in each:
		    b= str(each.strip()).split('\n')
#			a = a.append(b)
	#	    print each.strip()
		    if each != '':
			for each in b:
				each = filter(None,each )
				fieldname = fieldname + each + ','
	    fieldname = fieldname.split(',')
	    fieldname = filter(None,fieldname)
	    print fieldname
	    write(refid + '_det.log',str(fieldname))
            write(refid + '_' + num +'_det.log',str(fieldname)) 
	    table_column = rowname.split(';')
	    update = ''
	    for each_column in table_column:
		if each_column.strip():	
			update = update + 'update ' + schema.strip() + '.' + tablename.strip() + ' set ' + each_column.strip() +' = \'' + newls + "\' where " + each_column.strip() + " = \'" + oldls  + '\'; \\n'
			
            # --------------------------- Conversion ------------------------------------------
#	    command =  'echo "su - ' + sidadm + ' -c "\'"echo \'\'\\\"' + update  + '\\\" | sqlplus / as sysdba\'\'"\' | sudo bash'
	    command = 'echo "su - ' + sidadm + ' -c "\'"echo \'\'\\\"\'"' + update + ' "\'\\\" > table' + num + '.sql"\' |sudo bash'
            print command
	    write(refid + '_det.log', '---------------------------- update --------------------------------')
	    write(refid + '_det.log', command)
            stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
	    print out
	    status = stdout.channel.recv_exit_status()
	
	    command =   'echo "su - ' + sidadm + ' -c "\'"echo \'\'\\\"@table' + num + '.sql\\\" | sqlplus / as sysdba "\' | sudo bash ' 
	    print command
	    stdin, stdout, stderr = client.exec_command(command, timeout=100000, get_pty=True)
            out = stdout.readlines()
            print out
	    write(refid + '_det.log',str(out))
            write(refid + '_' + num +'_det.log',str(out))
            status = stdout.channel.recv_exit_status()
	    end_time = strftime("%H:%M:%S")
	    FMT = '%H:%M:%S'
            duration = datetime.strptime(end_time, FMT) - datetime.strptime(start_time, FMT)
            if status == 0 or 'ERROR' not in str(out):

			print 'The conversion has been completed suceesfully for the table ' + tablename.strip()
			write(refid + '.log', 'POST:P: ' + strftime("%Y-%m-%d %H:%M ") + ' The conversion has been completed scueesfully for the table ' + tablename.strip())

                        write(refid + '_BDLS_detailed.log', '\nclient: ' + clientname + " from " + oldls + " to " + newls + " Table " + tablename.strip() + '(ColumnName: ' + rowname.rstrip(";") + ') duration ' + str(duration) +  ' ')

            else:
                        print 'The conversion has not been completed suceesfully for the table ' + tablename.strip() + ' with error code: 1'
                        write(refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The conversion for the table " + tablename.strip() + ' has failed with the error code: 1')


    # ------------------------- Execute the function -----------------------------------------
    # --------------------------- Loop for four sets ------------------------------------------

    #print row_top[0]
    
#    exebdls(row_top[0],'first', sidadm, dbuser, dbpasswd, dbname)
#    exit()

    threadfirst = Thread(target=exebdls, args=(row_top[0], 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfirst.start()
    print  threadfirst.isAlive()
    threadsecond = Thread(target=exebdls, args=(row_top[1], 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadsecond.start()
    print threadsecond.isAlive()
    threadthird = Thread(target=exebdls, args=(row_top[2], 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadthird.start()
    print threadthird.isAlive()
    threadfourth = Thread(target=exebdls, args=(row_top[3], 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
    threadfourth.start()
    print threadfourth.isAlive()

    flag_first=1
    flag_second=1
    flag_third=1
    flag_fourth = 1

    for each in row_top[4:]:

        while flag_first == 1 or flag_second == 1 or flag_third == 1 or flag_fourth == 1:
                if flag_first == 0:
                        threadfirst = Thread(target=exebdls, args=(each, 'first', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfirst.start()
                        flag_first = 1
			print "Assigning thread first with " + str(each)
			break
		if flag_second == 0:
			threadsecond = Thread(target=exebdls, args=(each, 'second', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadsecond.start()
			flag_second=1
			print "Assigning thread second with " + str(each)
			break
		if flag_third == 0:
			threadthird = Thread(target=exebdls, args=(each, 'third', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadthird.start()
			flag_third=1
			print "Assigning thread third with " + str(each)
			break
		if flag_fourth == 0:
			threadfourth = Thread(target=exebdls, args=(each, 'fourth', sidadm, dbuser, dbpasswd, dbname, clientname))
			threadfourth.start()
			flag_fourth = 1
			print "Assigning thread fourth with " + str(each)
			break

#------------------------------is alive---------------------------------
		if threadfirst.isAlive() == False:
			flag_first = 0
			print "thread first is not alive"

		if threadsecond.isAlive() == False:
			flag_second=0
			print "thread second  is not alive"
		
		if threadthird.isAlive() == False:
			flag_third = 0
			print "thread third  is not alive"

		if threadfourth.isAlive() == False:
                        flag_fourth = 0
			print "thread fourth is not alive"

    """
    while flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
		if flag_first == 1 or flag_second == 1 or flag_third == 1 or  flag_fourth ==1:
			continue
		else:
			break
    """
    print "first loop completed"
    while threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
    	if threadfirst.isAlive() != False or threadsecond.isAlive() != False or threadthird.isAlive() != False or threadfourth.isAlive() != False:
		continue
	else:
		print "second loop completed"
		break


    print 'POST|P|The BDLS is over'
    endtime = strftime("%H:%M:%S")

    FMT = '%H:%M:%S'
    total_duration = datetime.strptime(endtime, FMT) - datetime.strptime(starttime, FMT)

   
    write(refid + '.log', "POST:P: " + strftime("%Y-%m-%d %H:%M ") + ' The BDLS is over')
    write(refid + '_BDLS_detailed.log','\nThe BDLS is completed for ' + clientname + ' ' +  strftime("%Y-%m-%d %H:%M "))

    logf = open(refid + '_BDLS_detailed.log', 'r')
    count = 0
    logfl = logf.readlines()
    for i in logfl:
	    if 'client: ' + clientname + " from " + oldls + " to " + newls in str(i):
    		count = count + 1

    logf.close()

    write(refid + '_BDLS_detailed.log','\ntotal duration ' + str(total_duration))
    write(refid + '_BDLS_detailed.log', str(count)+' tables are converted for ' + clientname + ' ' )


    channel.close()
    client.close()
# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
    write (refid + '.log', "POST:F: " + strftime("%Y-%m-%d %H:%M ") + " The execution has failed with the error: " + str(e))
