# ---------------------------------- Import Modules ---------------------------------------------
import os
import sys
from sys import *
from threading import Thread
from log4erp import *
import paramiko
from paramiko import *
import operator
import re
import pandas as pd

try: 
    # --------------------- Variable declaration --------------------------------------------
    table_size = {}
    wholecolumn = ''
    hostname = argv[1]
    username = argv[2]
    password = argv[3]
    sid = argv[4]
    dbuser = argv[5]
    dbpasswd = argv[6]
    dbname = argv[7]
    oldls = argv[8]
    newls = argv[9]
    refid = argv[10]
    script_loc = argv[11].rstrip('/')
    sidadm = str(sid.strip()) + 'adm'
    sidadm = sidadm.lower()

#    print sidadm

    def find_data(inputs, dataframe, x='yes'):
        if x == 'yes':
            dat = dataframe.apply(lambda x: x.str.strip())
            cols = dat[2][dat[1].str.strip() == inputs]
            return inputs + '|' + (';'.join(list(cols)))
        else:
            cols = dataframe[0][dataframe[5] == inputs]
            return list(cols.apply(lambda x: x.split()[0]))

    # ---------------------------- Paramiko Object creation ---------------------------------
    client = SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    channel = client.invoke_shell()

    # ------------------------ Get the schema name -----------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select schemaname from domain.tables where tablename = \'T000\'\\\\\\\" > schema.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i schema.sql | grep -v \'OK\' | grep -v \"CONTINUE\"\\\"" | sudo bash'
    print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()
    schema =  out[-1].replace('|','').strip()
    print schema

    # ------------------------- Get table list with LS --------------------------------------
    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select ' + schema + '.DD03L.TABNAME, ' + schema + '.DD03L.FIELDNAME from ' + schema + '.DD03L inner join ' + schema + '.DD02L on ' + schema + '.DD02L.TABNAME = ' + schema + '.DD03L.TABNAME where ( ' + schema + '.DD03L.DOMNAME IN ( \'LOGSYS\', \'EDI_PARNUM\', \'LOGSYSADDR\' )) and ' + schema + '.DD02L.TABCLASS = \'TRANSP\'\\\\\\\" > bdls_max.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i bdls_max.sql | grep -v \'OK\' | grep -v \"CONTINUE\"\\\"" | sudo bash'
#    command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select SAPTEQ.DD03L.TABNAME, SAPTEQ.DD03L.FIELDNAME from SAPTEQ.DD03L inner join SAPTEQ.DD02L on SAPTEQ.DD02L.TABNAME = SAPTEQ.DD03L.TABNAME where ( SAPTEQ.DD03L.DOMNAME IN ( \'LOGSYS\', \'EDI_PARNUM\', \'LOGSYSADDR\' )) and SAPTEQ.DD02L.TABCLASS = \'TRANSP\'\\\\\\\" > bdls_max.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i bdls_max.sql | grep -v \'OK\' | grep -v \"CONTINUE\"\\\"" | sudo bash'
    print command
    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
    out = stdout.readlines()

    print out
    exist = os.path.isfile(script_loc + '/bdls_' + refid + '.txt')
    if exist == True:
        os.remove (script_loc +'/bdls_' + refid + '.txt')

    
    # --------------------------- Get number of rows ----------------------------------------
#    out = '| /BI0/SLOGSYS                   | LOGSYS                         |\n'
    for each in out:
        each = each.strip()
        if '---' in each or 'TABNAME' in each or '(' in each or ')' in each or 'rows' in each or not each:
            continue
        else:
            tablefile = open(script_loc + "/out_bdls.txt","a")
            tablefile.write(str(each) + '\n')
            tablefile.close()

            tablename = each.split('|')[1].strip() +'|' + ';' + each.split('|')[2].strip()
            print tablename


            command = 'echo "su - ' + sidadm + ' -c \\\"echo \\\\\\\"select rowcount from sysinfo.tablesize where tablename=\'%s' %(tablename.split('|')[0]) + '\'\\\\\\\" > table.sql; sqlcli -d ' + sid.upper() + ' -u ' + dbuser + ',' + dbpasswd + ' -j -i table.sql | grep -v \'OK\' | grep -v \"END\"| grep -v \"sql_execute\"\\\"" | sudo bash'
            print command
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
            out = stdout.readlines()
            print out
            jj = open(script_loc + "/rwcnt.txt", "a")
            jj.write(tablename.split('|')[0] + " " + str(out)+'\n')
            jj.close()

    fulldata = open(script_loc + '/out_bdls.txt', 'r')
    rowcnt = open(script_loc + '/rwcnt.txt', 'r')
    fd = fulldata.readlines()
    rowc = rowcnt.readlines()
    print type(rowc)

    #------------------------- Get the list of rowcounts --------------------------
    flag = []
    for each in rowc:
        flag.append(each.split()[8])

    #print flag
    rowc = sorted(set(flag), key=int, reverse=True)
    #print rowc
    # print str(fd[0])

    #------------------------ Remove duplicacy in table list --------------------
    bdls_upd = open(script_loc + '/bdls_upd.txt', 'a')

    var = ''
    flag = 0
    for each in fd:
        each = each.strip()
        if var == str(each.split('|')[1]):
            bdls_upd.write(str(each.split('|')[2]).strip() + ';')
        else:
            if flag == 0:
                bdls_upd.write(re.sub('\|$', '', each).strip() + ';')
                flag = 1
            else:
                bdls_upd.write('\n' + re.sub('\|$', '', each).strip() + ';')
            var = str(each.split('|')[1])
    bdls_upd.close()

    #------------------------ Get list of non-zero tables in descending order of rowcount --------------------

    rowct = pd.read_csv(script_loc + "/rwcnt.txt", header=None, sep='|', engine='python')
    rowct = rowct.dropna(axis=1, how='any')

    bdls_table = pd.read_csv(script_loc + "/bdls_upd.txt", header=None, sep='|')
    bdls_table = bdls_table.dropna(axis=1, how='all')

    bdls_final = open(script_loc + "/bdls_" + refid + ".txt","a")

    for each in rowc:
        each = int(each)
        if each > 0:
            table = find_data(each, rowct, x="no")
            table = list(set(table))

            for each_table in table:
                table_entry = find_data(each_table, bdls_table, x="yes")
                bdls_final.write(str(table_entry) + '\n')

    rowcnt.close()
    fulldata.close()
    bdls_final.close()

    os.remove(script_loc + '/out_bdls.txt')
    os.remove(script_loc + '/rwcnt.txt')
    os.remove(script_loc + '/bdls_upd.txt')

    # ------------------------------- Close connection -----------------------------------------
    channel.close()
    client.close()

# --------------------------------- Exception handling --------------------------------------------
except Exception as e:
    exc_type, exc_obj, tb = sys.exc_info()
    lineno = tb.tb_lineno
    print str(e) + ': ' + str(lineno)
