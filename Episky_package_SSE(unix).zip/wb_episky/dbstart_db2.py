import paramiko
from paramiko import *
from sys import *
from log4erp import *
import time

try:
#    if argv[1] == "--u":
#        print "python startdb.py <Target Host> <Target Login User Name> <Target Login User Password> <Target Database SID>"
    if len(argv) < 5:
        print "DBSTART_DB2:F:  Argument/s missing for the script [Error Code - 1202]"

    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        db_sid = argv[5]
	logfile1 = argv[6]
	app_sid = argv[4]
	logfile2 = argv[7]
	seqno = argv[8]

        user = "db2" + db_sid.lower()

        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()

        command = "echo \"su - " + user + " -c \"\\\"\"db2start\"\\\" | sudo bash"
	print command
	write(logfile1,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	status = stdout.channel.recv_exit_status()
#	write(logfile1,time.strftime("%c") + " " + stdout)

        if status == 0 or status == 1:
            print "DBSTART_DB2:P: The Database has been started on the target server :" + hostname + "_" + app_sid + "_" + seqno
	    log = time.strftime("%c") + " DBSTART_DB2:P: The Database has been started on the target server :" + hostname + "_" + app_sid + "_" + seqno
	    write(logfile2, log)
	    
#            command = "echo \" su - " + user + " -c \"\\\"\"db2 activate db " + db_sid.lower() + "\"\\\" | sudo bash"
#	    print command
#	    write(logfile1,command)
 #           stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#	    status = stdout.channel.recv_exit_status()
#	    output = stdout.readlines()
#	    print output
#	    write(logfile1,str(output))
 #           if "Activate database is successful" in output[0] or "command completed successfully" in output[0]:
  #              print "DBSTART_DB2:P: The Database has been activated on the target server :" + hostname + "_" + app_sid + "_" + seqno
#	        log = time.strftime("%c") + " DBSTART_DB2:P: The Database has been activated on the target server :" + hostname + "_" + app_sid + "_" + seqno
#	        write(logfile2, log)
#	    else:
#		print "DBSTART_DB2:F: The Database has not been successfully activated on the target server :" + hostname + "_" + app_sid + "_" + seqno
 #               log = time.strftime("%c") + " DBSTART_DB2:F: The Database has not been successfully activated on the target server :" + hostname + "_" + app_sid + "_" + seqno
  #              write(logfile2, log)
        else:
            print "DBSTART_DB2:F: The Database has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seqno
            log = time.strftime("%c") + " DBSTART_DB2:F: The Database has not been successfully started on the target server :" + hostname + "_" + app_sid + "_" + seqno
            write(logfile2, log)
	channel.close()
	client.close()

except Exception as e:
     if str(e) == "[Errno -2] Name or service not known":
                print "DBSTART_DB2:F:GERR_1301:Hostname unknown:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F: Hostname unknown [Error Code - 1301]:' + hostname + '_' + app_sid + '_' + seqno)
     elif str(e) == "list index out of range":
                print "DBSTART_DB2:F:GERR_1302:Argument/s missing for the script:" + hostname + "_" + app_sid + "_" + seqno
#                write(logfile2,'DBSTART_DB2:F: Argument/s missing for the script [Error Code - 1302]')
     elif str(e) == "Authentication failed.":
                print "DBSTART_DB2:F:GERR_1303:Authentication failed.:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F:Authentication failed.[Error Code - 1303]:' + hostname + '_' + app_sid + '_' + seqno)
     elif str(e) == "[Errno 110] Connection timed out":
                print "DBSTART_DB2:F:GERR_1304:Host Unreachable:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F:Host Unreachable.[Error Code - 1304]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "getaddrinfo failed" in str(e):
                print "DBSTART_DB2:F:GERR_1305: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F: Please check the hostname that you have provide [Error Code - 1305]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "[Errno None] Unable to connect to port 22 on" in str(e):
                print "DBSTART_DB2:F:GERR_1306:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F: Host Unreachable or Unable to connect to port 22 [Error Code - 1306]:' + hostname + '_' + app_sid + '_' + seqno)
     elif "invalid decimal" in str(e):
                print "DBSTART_DB2:F:GERR_1307:Unknown Error:" + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
                write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F: Unknown Error:' + str(e) + '[Error Code - 1307]:' + hostname + '_' + app_sid + '_' + seqno)
     else:
                print "DBSTART_DB2:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + seqno
		write(logfile2,time.strftime("%c") + ' DBSTART_DB2:F: ' + str(e) + ':' + hostname + '_' + app_sid + '_' + seqno)

