import paramiko
from paramiko import *
from sys import *
import log4erp
from log4erp import *
import time
import subprocess
from subprocess import *


def db(user,hostname,kernel_path,string, app_sid,re_execute):
  try:
    if string.lower() == "db":

########################################## FETCHING SCHEMA USER ###############################

                command = "echo \"su - " + user + " -c \"\\\"\"echo $dbs_ora_schema\"\\\"|sudo bash"
		log4erp.write(logfile,command)
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                schema = stdout.readlines().rstrip()
		log4erp.write(logfile,str(schema))

################################### STARTING LISTENER ########################################################

#        command = 'sudo su - ' + user + ' -c "lsnrctl start LISTENER"'
#        print command
#        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#        status = stdout.channel.recv_exit_status()
#	print status
#        if status != 0 and status != 1:
#            print "WRPRUN_SCRIPT:F: The listener has not been started on the target Server (HOSTNAME - " + hostname + "):" + app_sid
#	    log4erp.write(log,app_sid + ":F: The listener has not been started on the target Server (HOSTNAME - " + hostname + "):" + app_sid)
#            exit()
#        else:
#            print 'WRPRUN_SCRIPT:P: The listener has been started on the target Server (HOSTNAME - ' + hostname + '):' + app_sid
#	    log4erp.write(log,app_sid + ":P: The listener has been started on the target Server (HOSTNAME - " + hostname + '):' + app_sid)
#	    print "neha"
	    

################################### STARTING DATABASE #######################################################

	#    command1 = 'sudo'
#            command = 'sudo su - ' + user + ' -c \'echo "startup" | sqlplus / as sysdba\''
 #           print command
#            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
#            status = stdout.channel.recv_exit_status()
#	    print status
#            if status == 0:
#                print 'WRPRUN_SCRIPT:P: The database has been started on the target server (HOSTNAME - ' + hostname + '):' + app_sid
#		log4erp.write(log,app_sid + ":P: The database has been started on the target server (HOSTNAME - " + hostname + '):' + app_sid)"""
                command = "echo \"su - " + user + " -c \"\\\"\"echo \'@" + kernel_path + "/sapconn_role.sql\' | sqlplus / as sysdba\\\"\"|sudo bash"
                log4erp.write(logfile,command)
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		out = stdout.readlines()
		log4erp.write(logfile,str(out))
                status = stdout.channel.recv_exit_status()

################################### EXECUTING SQL FILES ######################################################

                if stdout.channel.recv_exit_status() == 0:
                    print 'WRPRUN_SCRIPT:P: The sapconn_role.sql file has been executed successfully on the target Server (HOSTNAME - ' + hostname + '):' + hostname + "_" + app_sid + "_" + re_execute
		    log4erp.write(log, app_sid + ':P: The sapconn_role.sql file has been executed successfully on the target Server (HOSTNAME - ' + hostname + '):' + app_sid)

                    command = "echo \"su - " + user + " -c \"\\\"\"echo \'@" + kernel_path + "/sapdba_role.sql " + schema + "\' | sqlplus / as sysdba\\\"\"|sudo bash"
		    log4erp.write(logfile,command)
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		    out = stdout.readlines()
		    log4erp.write(logfile,str(out))
		    status = stdout.channel.recv_exit_status()
                  
                    if status == 0:
                        print 'WRPRUN_SCRIPT:P: The sapdba_role.sql file has been executed successfully on the target Server (HOSTNAME - ' + hostname + '):' + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ':P: The sapdba_role.sql file has been executed successfully on the target Server (HOSTNAME - ' + hostname + '):' + app_sid)
                    else:
                        print 'WRPRUN_SCRIPT:F: The sapdba_role.sql file has been failed on the target Server (HOSTNAME - ' + hostname + '):' + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ':F: The sapdba_role.sql file has been failed on the target Server (HOSTNAME - ' + hostname + '):' + app_sid)
                        exit()
                else:
                    print 'WRPRUN_SCRIPT:F: The sapconn_role.sql file has been failed on the target Server (HOSTNAME - ' + hostname + '):' + hostname + "_" + app_sid + "_" + re_execute
		    log4erp.write(log, app_sid + ':F: The sapconn_role.sql file has been failed on the target Server (HOSTNAME - ' + hostname + '):' + app_sid)
 #  """                 exit()
 #           else:
 #               print "'WRPRUN_SCRIPT:F: Failed to start the database in the target server (HOSTNAME - " + hostname + "):" + app_sid
#		log4erp.write(log, app_sid + ':F: Failed to start the database in the target server (HOSTNAME - ' + hostname + '):' + app_sid)
#                exit()"""
  except Exception as e:
    if str(e) == "[Errno -2] Name or service not known":
         print "WRPRUN_SCRIPT:F:GERR_0201:Hostname unknown:" + hostname + "_" + app_sid + "_" + re_execute
    elif str(e).strip() == "list index out of range":
         print "WRPRUN_SCRIPT:F:GERR_0202:Argument/s missing for the script:" + app_sid
    elif str(e) == "Authentication failed.":
         print "WRPRUN_SCRIPT:F:GERR_0203:Authentication failed.:" + hostname + "_" + app_sid + "_" + re_execute
    elif str(e) == "[Errno 110] Connection timed out":
         print "WRPRUN_SCRIPT:F:GERR_0204:Host Unreachable:" + hostname + "_" + app_sid + "_" + re_execute
    elif "getaddrinfo failed" in str(e):
         print "WRPRUN_SCRIPT:F:GERR_0205: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + re_execute
    elif "[Errno None] Unable to connect to port 22" in str(e):
         print "WRPRUN_SCRIPT:F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + re_execute
    elif "Permission denied" in str(e):
         print "WRPRUN_SCRIPT:F:GERR_0206:Permission denied for the user" + t_user + ":" + hostname + "_" + app_sid + "_" + re_execute
    else:
         print "WRPRUN_SCRIPT:F: " + str(e) + ":" + hostname + "_" + app_sid + "_" + re_execute

try:
    if argv[1] == "--u":
        print "usage: python run_scripts.py <Target Hostname> <Target sudo User name> <Target User Password> <Target Application SID> <Database SID> <System Type App/Db> <kernel_id>"
    else:
        hostname = argv[1]
        username = argv[2]
        password = argv[3]
        app_sid = argv[4].lower()
        db_sid= argv[5].lower()
        db_user = "ora" + argv[5].lower()
        string = argv[6]
	logfile = argv[7]
	#date = (time.strftime("%d-%m-%Y_%H-%M"))
	log = argv[8]
	re_execute = argv[9]
	db_type = argv[10]

	client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname,username = username, password = password)
        channel = client.invoke_shell()


	if string.lower() == "ai" or string.lower() == "ci":
		user = app_sid + "adm"
                command = 'echo "su - ' + user + ' -c "\\\"ls\\\"| sudo bash'
		print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		print stdout.readlines()
                status = stdout.channel.recv_exit_status()
                if status != 0:
                        print "WRPRUN_SCRIPT:F:Provided input for the app SID ( " + app_sid + " ) is incorrect:" + hostname + "_" + app_sid + "_" + re_execute
                        log4erp.write(log,"WRPRUN_SCRIPT:F: Provided input for the app SID ( " + app_sid + " ) in " + hostname + " host is incorrect:" + app_sid)
                        exit()

		
	elif string.lower() == "db":
		user = "ora" + db_sid
                command = "ls /oracle/" + db_sid.upper() + " >&1 /dev/null"
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()

                if status != 0:
                        print "WRPRUN_SCRIPT:F: Provided input for the database SID ( " + db_sid + " ) is incorrect:" + hostname + "_" + app_sid + "_" + re_execute
                        log4erp.write(log,"WRPRUN_SCRIPT:F: Provided input for the database SID ( " + db_sid + " ) in " + hostname + " host is incorrect:" +app_sid)




######################################### FETCHING KERNEL PATH ###############################
	if string.lower() == "ai" or string.lower() == "ci":
		if not "ora" in db_type.lower():
			log4erp.write(logfile,"-----------RUNNING SAPROOT.SH---------------------------")
			command = "echo \"su - " + user + " -c \"\\\"\"which disp+work\"\\\"\" | sed \'s/\/disp+work//\' | grep -v MAIL \" |sudo bash"
			print command
		        log4erp.write(logfile,command)
		        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		        kernel_path = stdout.readlines()
		        kernel_path = kernel_path[0].strip()
		        log4erp.write(logfile,kernel_path)
			print kernel_path
			#command = 'echo "cd '+ kernel_path + ';sh ' + kernel_path + '/saproot.sh ' + app_sid + " " + db_sid + '" | sudo bash'
			#print command
                        #log4erp.write(logfile,command)
                        #stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                        #out = stdout.readlines()
                        #log4erp.write(logfile,str(out))
			#print out
                        #status = stdout.channel.recv_exit_status()
                        if status == 0:
                            print "WRPRUN_SCRIPT:P: saproot.sh file has been executed successfully in the target server :" + hostname + "_" + app_sid + "_" + re_execute
                            log4erp.write(log, app_sid + ":P: saproot.sh file has been executed successfully in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
			    exit()
                        else:
                            print "WRPRUN_SCRIPT:F: saproot.sh file has been failed in the target server :" + hostname + "_" + app_sid + "_" + re_execute
                            log4erp.write(log, app_sid + ":F: saproot.sh file has been failed in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                            exit()



		 

        command = "echo \"su - " + user + " -c \"\\\"\"which disp+work\"\\\"\" | sed \'s/\/disp+work//\'\" |sudo bash"
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        kernel_path = stdout.readlines()
        kernel_path = kernel_path[0].strip()
        log4erp.write(logfile,kernel_path)

######################################### EXECUTING .SH FILES ###############################

        command = "sudo ls " + kernel_path + "/root.sh"
        log4erp.write(logfile,command)
        stdin,stdout,stderr = client.exec_command(command, timeout=1000, get_pty=True)
	out = stdout.readlines()
        log4erp.write(logfile,str(out))
        status = stdout.channel.recv_exit_status()
        if status == 0:
            command = "sudo sh " + kernel_path + "/root.sh"
            log4erp.write(logfile,command)
            stdin,stdout,stderr = client.exec_command(command , timeout=1000, get_pty=True)
	    out = stdout.readlines()
	    log4erp.write(logfile,str(out))
            status = stdout.channel.recv_exit_status()
            if status == 0:
                print "WRPRUN_SCRIPT:P: root.sh file has been executed successfully in the target server :" + hostname + "_" + app_sid + "_" + re_execute
		log4erp.write(log, app_sid + ":P: root.sh file has been executed successfully in the target server HOSTNAME - " + argv[1] + ":" + app_sid )
                db(user,hostname,kernel_path,string, app_sid,re_execute)
            else:
                print "WRPRUN_SCRIPT:F: root.sh file has been failed in the target server :" +hostname + "_" + app_sid + "_" + re_execute
		log4erp.write(log, app_sid + ":F: root.sh file has been failed in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                exit()
        else:
#            print "WRPRUN_SCRIPT:I:root.sh file does not exist.Executing oraroot.sh and saproot.sh file:" + app_sid
	    log4erp.write(log, app_sid + ":I:root.sh file does not exist.Executing oraroot.sh and saproot.sh file:" + app_sid)
            command = "sudo ls " + kernel_path + "/oraroot.sh"
	    log4erp.write(logfile,command)
            stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
	    out = stdout.readlines()
	    log4erp.write(logfile,str(out))
            status = stdout.channel.recv_exit_status()
            if status == 0:
                command = "sudo sh " + kernel_path + "/oraroot.sh " + app_sid + " " + db_sid
		log4erp.write(logfile,command)
                stdin,stdout,stderr = client.exec_command(command ,timeout=1000, get_pty=True)
		out = stdout.readlines()
                log4erp.write(logfile,str(out))
                status = stdout.channel.recv_exit_status()
                if status == 0:
                    print "WRPRUN_SCRIPT:P:oraroot.sh file has been executed successfully in the target server : " + hostname + "_" + app_sid + "_" + re_execute
		    log4erp.write(log, app_sid + ":P: oraroot.sh file has been executed successfully in the target server  HOSTNAME - " + argv[1] + ":" + app_sid)
                    command = "sudo ls " + kernel_path + "/saproot.sh"
		    log4erp.write(logfile,command)
                    stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		    out = stdout.readlines()
		    log4erp.write(logfile,str(out))
                    status = stdout.channel.recv_exit_status()
                    if status == 0:
                        command = "sudo sh " + kernel_path + "/saproot.sh " + app_sid + " " + db_sid
                        log4erp.write(logfile,command)
                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
			out = stdout.readlines()
                        log4erp.write(logfile,str(out))
                        status = stdout.channel.recv_exit_status()
                        if status == 0:
                            print "WRPRUN_SCRIPT:P: saproot.sh file has been executed successfully in the target server :" + hostname + "_" + app_sid + "_" + re_execute
			    log4erp.write(log, app_sid + ":P: saproot.sh file has been executed successfully in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                            db(user, hostname, kernel_path, string, app_sid, re_execute)
                        else:
                            print "WRPRUN_SCRIPT:F: saproot.sh file has been failed in the target server :" + hostname + "_" + app_sid + "_" + re_execute
			    log4erp.write(log, app_sid + ":F: saproot.sh file has been failed in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                            exit()
                    else:
                        print "WRPRUN_SCRIPT:F: saproot.sh file not found in the target server :" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F: saproot.sh file not found in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                        exit()
                else:
                    print "WRPRUN_SCRIPT:F: oraroot.sh file has been failed in the target server :" + hostname + "_" + app_sid + "_" + re_execute
		    log4erp.write(log, app_sid + ":F: oraroot.sh file has been failed in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                    exit()
            else:
                print "WRPRUN_SCRIPT:F:oraroot.sh file not found in the target server :" + hostname + "_" + app_sid + "_" + re_execute
		log4erp.write(log, app_sid + ":F: oraroot.sh file not found in the target server HOSTNAME - " + argv[1] + ":" + app_sid)
                exit()

        channel.close()
        client.close()

except Exception as e:
                if str(e) == "[Errno -2] Name or service not known":
                        print "WRPRUN_SCRIPT:F:GERR_0201:Hostname unknown:" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0201:Hostname unknown:" + app_sid)
                elif str(e).strip() == "list index out of range":
                        print "WRPRUN_SCRIPT:F:GERR_0202:Argument/s missing for the script:"  + hostname
                elif str(e) == "Authentication failed.":
                        print "WRPRUN_SCRIPT:F:GERR_0203:Authentication failed.:" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0203:Authentication failed.:" + app_sid)
                elif str(e) == "[Errno 110] Connection timed out":
                        print "WRPRUN_SCRIPT:F:GERR_0204:Host Unreachable:" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0204:Host Unreachable:" + app_sid)
                elif "getaddrinfo failed" in str(e):
                        print "WRPRUN_SCRIPT:F:GERR_0205: Please check the hostname that you have provide:" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0205: Please check the hostname that you have provide:" + app_sid)
                elif "[Errno None] Unable to connect to port 22" in str(e):
                        print "WRPRUN_SCRIPT:F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + app_sid)
                elif "Permission denied" in str(e):
                        print "WRPRUN_SCRIPT:F:GERR_0206:Permission denied for the user" + t_user + ":" + hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log, app_sid + ":F:GERR_0206:Permission denied for the user" + t_user + ":" + app_sid)
                else:
                        print "WRPRUN_SCRIPT:F: " + str(e) + ":"+ hostname + "_" + app_sid + "_" + re_execute
			log4erp.write(log,"WRPRUN_SCRIPT:F: " + str(e) + ":" + app_sid)
