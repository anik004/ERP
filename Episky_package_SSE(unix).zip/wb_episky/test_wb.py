import sys
import os


print os.path.dirname(sys.argv[0])

print "test"

