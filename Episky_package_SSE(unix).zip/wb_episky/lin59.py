from sys import *
from os import *
import os
import subprocess
from subprocess import *
import log4erp
from log4erp import *

try:
    if argv[1] == "--u":
        print "python rename_files.py <old file name> <new file name>"
    else:
#	if argv[1] == "REDHAT":
		old_file = argv[1]
		new_file = argv[2]
		path = argv[3].rstrip('/')
		logfile = "Check_log.log"
		log = 'Episky_log.log'

		out = os.path.isfile(old_file) 
		log4erp.write(logfile,str(out))
		if str(out) == "True":
			command = "cd "+path+" ; mkdir files 2> /dev/null"
			log4erp.write(logfile,command)
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	                out, err = command.communicate()
			log4erp.write(logfile,out)
			
			file_new = os.path.dirname(old_file).strip()
			print file_new
			command ="cp -f " + old_file + " " +  path.rstrip() + '/files/' + new_file
			print command
			log4erp.write(logfile,command)
		        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		        out, err = command.communicate()
			log4erp.write(logfile,out)

			command ="ls "  +  path.rstrip() +"/files/ | grep " + new_file
			print command
			log4erp.write(logfile,command)
			command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                        out, err = command.communicate()
                        log4erp.write(logfile,out)
			print out
			if not out:
				print "WRPRENAME_FILES:F:Failed to rename the SAP Kernel File"
				log4erp.write(log,"RENAME_FILES:F:Failed to rename the SAP Kernel File")
			else:
				print "WRPRENAME_FILES:P:File " + old_file + " has been renamed to " + new_file
				log4erp.write(log,"RENAME_FILES:P:File " + old_file + " has been renamed to " + new_file)
		else:
			print "WRPRENAME_FILES:F:File " + old_file + " does not exist"
			log4erp.write(log,"RENAME_FILES:F:File " + old_file + " does not exist")
#	else:
#		print "script not found"

except Exception as e:
        if "list index out of range" in str(e):
               print "WRPRENAME_FILES:F:GERR_0202:Argument/s missing for the script"
        elif "Permission denied" in str(e):
               print "WRPRENAME_FILES:F:GERR_0206:Permission denied for the user" + t_user
	       log4erp.write(log,"RENAME_FILES:F:GERR_0206:Permission denied for the user" + t_user)
	elif "No such file or directory" in str(e):
	       print "WRPRENAME_FILES:F:GERR_0204:No such file or directory:"
	       log4erp.write(log,"RENAME_FILES:F:GERR_0204:No such file or directory:")
        else:
	       print "WRPRENAME_FILES:F " + str(e)
	       log4erp.write(log,"RENAME_FILES:F " + str(e))
