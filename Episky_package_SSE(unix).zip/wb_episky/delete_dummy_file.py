import sys
from sys import *
import paramiko
from paramiko import *
import subprocess
import os
from subprocess import *

try:

	host = argv[1]
	user = argv[2]
	passwd = argv[3]
	app_sid = argv[4]
	t_os_name = argv[5]
	ai_ci_db = argv[6]
	kernel_path = argv[7]
	user_app = app_sid.lower() + "adm"
	if ai_ci_db.lower() == "ai" or ai_ci_db.lower() == "ci":
		if t_os_name.lower() == "windows":



			print "hello"
		

		elif t_os_name.lower() == "redhat" or t_os_name.lower() == "aix": 
			kernel_path = ""
			client = SSHClient()	
			client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        		client.connect( host,username = user, password = passwd)
        		channel = client.invoke_shell()
			
			#command = "echo \" su - " + user_app + " -c 'which disp+work' | sed \'s/\/disp+work//\'\" | sudo bash "
			#print command
	 		command = "echo \"su - " + user_app  + " -c \"\\\"\"which disp+work\"\\\"\"| sed 's/\/disp+work//' | grep -v MAIL |tail -n -1\" | sudo bash "
			print command
	 		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
         		out = stdout.readlines()
			print out
			kernel_path = out[0].strip()
			print kernel_path
         		command = "echo \"su - " + user_app  + " -c \"\\\"\"ls " + kernel_path.strip() + "/ker_file.txt \"\\\"\" | grep -v MAIL \" | sudo bash "                  
			print command
         		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
         		out = stdout.readlines()
			print out
			if "No such file or directory" in str(out) or "does not exist" in str(out):
				print "dummy_file:P: File does not exist"
			else: 
				command = "echo \"su - " + user_app  + " -c \"\\\"\" rm " + kernel_path.strip() + "/ker_file.txt \"\\\"\" | grep -v MAIL \" | sudo bash "
				print command
	                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
        	                out = stdout.readlines()
				print out

				command = "echo \"su - " + user_app  + " -c \"\\\"\"ls " + kernel_path.strip() + "/ker_file.txt \"\\\"\"| grep -v MAIL \" | sudo bash "
				print command
				stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
				out = stdout.readlines()
				print out
				if "No such file or directory" in str(out) or "does not exist" in str(out) or "not found" in str(out) :
					print "dummy_file:P: File deleted successfully"
				else:
					print "dummy_file:F: Unable to delete the file from kernel location"
		else:
			print "dummy_file:F:script not found"
	else:
		print "dummy_file:F:string is DB"
		exit()
except Exception as e:
	print "WRPBACKUP_KERNEL:F: " + str(e) + ":" + app_sid
