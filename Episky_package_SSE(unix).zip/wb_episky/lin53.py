#!/usr/bin/sh
# This script is applicable for Multiple Kernel Files

import paramiko
import ntpath
from sys import *
from paramiko import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *
import os
try:
    if argv[1] == "--u":
        print "usage: python copy_files.py <target host> <Filename Initial with path> <target sudo user> <target sudo user password> <target_app_sid> <target_db_sid> <App/Db> <kernel_id>"
    else:
        target_host = argv[1]
        file_init1 = argv[2]
        target_user = argv[3]
        target_passwd = argv[4]
	t_app_sid = argv[5]
	t_db_sid = argv[6]
	string = argv[7]
	logfile = argv[9]
	log = argv[10]
	re_execute = argv[11]
	opt_ker = argv[12]
	command = "whoami"
	log4erp.write(logfile,command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	print out
	file_path = argv[13] + '/files'
	print file_path
	port = 22
	
        client = SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect( target_host,username = target_user, password = target_passwd)
        channel = client.invoke_shell()

	if string.lower() == "ai" or string.lower() == "ci":
		user_app = t_app_sid.lower() + "adm"
		print user_app
		command = "echo \"su - " + user_app + " -c \"\\\"\" ls \"\\\"\" |grep -v \"MAIL\"\" |sudo bash"
		print command
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()
                if status != 0:
                        print "copy_files:F: Provided input for the app SID ( " + t_app_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        log4erp.write(log,"copy_files:F: Provided input for the app SID ( " + t_app_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)
                        exit()

	elif string.lower() == "db":
		user_app = "ora" + t_db_sid.lower()
		command = "ls /oracle/" + t_db_sid.upper() + "\"MAIL\"" + " >&1 /dev/null"
		print command
		stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
                status = stdout.channel.recv_exit_status()

                if status != 0:
                        print "copy_files:F: Provided input for the database SID ( " + t_db_sid + " ) is incorrect:" + target_host + "_" + t_app_sid + "_" + re_execute
                        log4erp.write(log,"copy_files:F: Provided input for the database SID ( " + t_db_sid + " ) in " + target_host + " host is incorrect:" + t_app_sid)

	command = command = "echo \"su - " + user_app + " -c \"\\\"\" rm -rf /usr/sap/put/epsiky_files/* \"\\\"\" |grep -v \"MAIL\"\" |sudo bash"
	print command
	log4erp.write(logfile,command)
        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)	
	print stdout.readlines()
	out = stdout.readlines()
	log4erp.write(logfile,str(out))


        kernel_files_indi=" ls " + file_path + " | grep -i \"" + file_init1 + "_DBI\" "
	print kernel_files_indi

        log4erp.write(logfile,kernel_files_indi)
	command = subprocess.Popen(kernel_files_indi, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	log4erp.write(logfile,str(out))
	kernel_files_indi = out
	kernel_files_indi = kernel_files_indi.replace('\n',',')
	kernel_files_indi = kernel_files_indi.split(',')
	log4erp.write(logfile,str(kernel_files_indi))
   
        kernel_files_di="ls " + file_path + " |  grep -i \"" + file_init1 +"_DBD\""
	log4erp.write(logfile,kernel_files_di)
	command = subprocess.Popen(kernel_files_di, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	log4erp.write(logfile,str(out))
	kernel_files_di = out
	kernel_files_di = kernel_files_di.replace('\n',',')
	kernel_files_di = kernel_files_di.split(',')
	log4erp.write(logfile,str(kernel_files_di))

        kernel_files_opt="ls " + file_path + " | grep -i \"" + file_init1 + "_OPT\""
 	log4erp.write(logfile,kernel_files_opt)
	command = subprocess.Popen(kernel_files_opt, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
	log4erp.write(logfile,str(out))
	kernel_files_opt = out
	kernel_files_opt = kernel_files_opt.replace('\n',',')
	kernel_files_opt = kernel_files_opt.split(',')
	log4erp.write(logfile,str(kernel_files_opt))
	print opt_ker
	print opt_ker[1].lower()
	if opt_ker[0].lower() == "y":

		kernel_files_igs="ls " + file_path + " | grep -i \"" + file_init1 + "_IGSEXE\""
		print kernel_files_igs
	        log4erp.write(logfile,kernel_files_igs)
        	command = subprocess.Popen(kernel_files_igs, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
        	log4erp.write(logfile,str(out))
	        kernel_files_igs = out
        	kernel_files_igs = kernel_files_igs.replace('\n',',')
	        kernel_files_igs = kernel_files_igs.split(',')
        	log4erp.write(logfile,str(kernel_files_igs))


	if opt_ker[1].lower() == "y":
		print "hi"

		kernel_files_dw="ls " + file_path + " | grep -i \"" + file_init1 + "_DW\""
		print kernel_files_dw
	        log4erp.write(logfile,kernel_files_dw)
        	command = subprocess.Popen(kernel_files_dw, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
	        log4erp.write(logfile,str(out))
	        kernel_files_dw = out
        	kernel_files_dw = kernel_files_dw.replace('\n',',')
	        kernel_files_dw = kernel_files_dw.split(',')
        	log4erp.write(logfile,str(kernel_files_dw))


	if opt_ker[2].lower() == "y":

		kernel_files_r3="ls " + file_path + " | grep -i \"" + file_init1 + "_R3TRANS\""
		print kernel_files_r3
                log4erp.write(logfile,kernel_files_r3)
                command = subprocess.Popen(kernel_files_r3, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                log4erp.write(logfile,str(out))
                kernel_files_r3 = out
                kernel_files_r3 = kernel_files_r3.replace('\n',',')
                kernel_files_r3 = kernel_files_r3.split(',')
                log4erp.write(logfile,str(kernel_files_r3))


	if opt_ker[3].lower() == "y":

		kernel_files_tp="ls " + file_path + " | grep -i \"" + file_init1 + "_TP\""
		print kernel_files_tp
                log4erp.write(logfile,kernel_files_tp)
                command = subprocess.Popen(kernel_files_tp, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                log4erp.write(logfile,str(out))
                kernel_files_tp = out
                kernel_files_tp = kernel_files_tp.replace('\n',',')
                kernel_files_tp = kernel_files_tp.split(',')
                log4erp.write(logfile,str(kernel_files_tp))


	if opt_ker[4].lower() == "y":

		kernel_files_lib="ls " + file_path + " | grep -i \"" + file_init1 + "_LIB\""
		print kernel_files_lib
                log4erp.write(logfile,kernel_files_lib)
                command = subprocess.Popen(kernel_files_lib, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                log4erp.write(logfile,str(out))
                kernel_files_lib = out
                kernel_files_lib = kernel_files_lib.replace('\n',',')
                kernel_files_lib = kernel_files_lib.split(',')
                log4erp.write(logfile,str(kernel_files_lib))

       	kernel_files = []
#    	kernel_files = [kernel_files_indi] + [kernel_files_di] + [kernel_files_opt] + [kernel_files_igs]+[kernel_files_dw]+ [kernel_files_r3]+[ kernel_files_tp] + [kernel_files_lib]
	if opt_ker[1].lower() == "y" and opt_ker[2].lower() == "y" and opt_ker[3].lower() == "y" and opt_ker[4].lower() == "y":
		kernel_files = [kernel_files_indi]+[kernel_files_di] + [kernel_files_igs] + [kernel_files_dw] + [kernel_files_r3] + [kernel_files_tp]+[kernel_files_lib]
        	kernel_files1=kernel_files
	        log4erp.write(logfile,str(kernel_files1))
        	print kernel_files1	
	else:
		kernel_files = [kernel_files_indi]+[kernel_files_di] + [kernel_files_igs]
		kernel_files1=kernel_files
                log4erp.write(logfile,str(kernel_files1))
                print kernel_files1

        if kernel_files1 == [[''], [''], ['']]:
		print "WRPCOPY_FILES:F: There are no kernel binary present on the path (" + file_path + ") in SOLMAN:" + target_host + "_" + t_app_sid + "_" + re_execute
		log4erp.write(log,t_app_sid + ":F: There are no kernel binary present on the path (" + file_path + ") in SOLMAN:" + t_app_sid)
	else:
		kernel_path =  "echo \"su - " + user_app + " -c \"\\\"\" which disp+work\"\\\"\" | sed \'s/\/disp+work//\' | grep -v \"MAIL\"\"|sudo bash "
	 	log4erp.write(logfile,kernel_path)
		stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
		kernel_path = stdout.readlines()
		log4erp.write(logfile,str(kernel_path))
		kernel_path=kernel_path[0]
	        kernel_path=kernel_path.strip()
		
		command = "mkdir -p /usr/sap/put/episky_files"
		print command
		log4erp.write(logfile,command)
                stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True)
		print stdout.readlines()
		
		print kernel_path

		#command = "echo \" su - " + user_app + " -c \"\\\"\"chown -R " + user_app + " " + kernel_path +"\"\\\" | sudo bash"
		#print command
		#write(logfile,command) 
		#stdin, stdout, stderr = client.exec_command(kernel_path, timeout=1000, get_pty=True)
		#out = stdout.readlines()
		#print out
		print "gggg"
		print kernel_files
		for kernel_file1 in kernel_files:
			for kernel_file in kernel_file1:
			   print kernel_file
			   if kernel_file != "":
				filepath = "/usr/sap/put/episky_files/" + kernel_file.strip()
				log4erp.write(logfile,"filepath "+filepath)
				localpath = file_path + "/" +  kernel_file.strip()
				log4erp.write(logfile,"localpath "+localpath)
				command = "chmod -R 777 " + localpath
				print command 
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                                out, err = command.communicate()
				print out
				print localpath
				print filepath
				transport1 = paramiko.Transport((target_host, port))
				transport1.connect(username = target_user, password = target_passwd)
				sftp1 = paramiko.SFTPClient.from_transport(transport1)
				sftp1.put(localpath, filepath)
		flag = 1
		for kernel_file1 in kernel_files:
                        for kernel_file in kernel_file1:
                           if kernel_file != "":
				cmd = "ls /usr/sap/put/episky_files/" + kernel_file + "| grep -v \"MAIL\""
				print cmd
				log4erp.write(logfile,cmd)
				stdin, stdout, stderr = client.exec_command(cmd, timeout=1000, get_pty=True)
				out = stdout.readlines()
				print out
				log4erp.write(logfile,str(out))
		                #print stdout.channel.recv_exit_status()
		                #print stdout.readlines()
				if stdout.channel.recv_exit_status() == 0:
					
					print "WRPCOPY_FILES:P: The kernel file " + kernel_file.strip() + " are copied Successfuly  to the target SAP Server :" + target_host + "_" + t_app_sid + "_" + re_execute
					log4erp.write(log, t_app_sid + "WRPCOPY_FILES:P: The kernel file " + kernel_file.strip() + " are copied Successfuly  to the target SAP Server HOSTNAME - " + argv[1] + ":" + t_app_sid) 
				else:
					print "WRPCOPY_FILES:F: Kernel Files have not been copied successfuly to the target server :" + target_host + "_" + t_app_sid + "_" + re_execute
					log4erp.write(log, t_app_sid + "copy_file:F: Kernel Files have not been copied successfuly to the target server" + kernel_file)
					exit()
		

			for kernel_file1 in kernel_files:
#				print "kernel file"
#	                        print kernel_file1
        	                for kernel_file in kernel_file1:
                	           if kernel_file != "":
	                                command="chmod -R 777 /usr/sap/put/episky_files;chown -R " + user_app + ":sapsys /usr/sap/put/episky_files"
					print command
					log4erp.write(logfile,command)
        	                        stdin, stdout, stderr = client.exec_command(command, timeout=1000, get_pty=True) 
					log4erp.write(logfile,str(stdout.readlines()))
					if stdout.channel.recv_exit_status() == 0 or stdout.channel.recv_exit_status() == 1:
		                                flag = 1
                		        else:
                                		flag = flag+1
			if flag ==1:
				print "WRPCOPY_FILES:P:The permission for the file has been changed in the target server :"+ target_host + "_" + t_app_sid + "_" + re_execute
			        log4erp.write(log, t_app_sid + ":P:The permission for the file has been changed in the target server : " + argv[1] + ":" + t_app_sid)
			else:
			        print "WRPCOPY_FILES:F:The permission for the file has not been changed in the targe server HOSTNAME :" + target_host + "_" + t_app_sid + "_" + re_execute
			        log4erp.write(log, t_app_sid + ":F:The permission for the file has not been changed in the target server HOSTNAME : " + argv[1] + ":" + t_app_sid)
			
		    


        channel.close()
        client.close()

except Exception as e:
                if str(e) == "[Errno -2] Name or service not known":
                        print "WRPCOPY_FILES:F:GERR_0201:Hostname unknown:" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F::Hostname unknown:" + t_app_sid)
                elif str(e).strip() == "list index out of range":
                        print "WRPCOPY_FILES:F:GERR_0202:Argument/s missing for the script:" + target_host
                elif str(e) == "Authentication failed.":
                        print "WRPCOPY_FILES:F:GERR_0203:Authentication failed.:" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F:Authentication failed.:" + t_app_sid)
                elif str(e) == "[Errno 110] Connection timed out":
                        print "WRPCOPY_FILES:F:GERR_0204:Host Unreachable:" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F:Host Unreachable:" + t_app_sid)
                elif "getaddrinfo failed" in str(e):
                        print "WRPCOPY_FILES:F:GERR_0205: Please check the hostname that you have provide:" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F: Please check the hostname that you have provide:" + t_app_sid)
                elif "[Errno None] Unable to connect to port 22" in str(e):
                        print "WRPCOPY_FILES:F:GERR_0206:Host Unreachable or Unable to connect to port 22:" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F:Host Unreachable or Unable to connect to port 22:" + t_app_sid)
                elif "Permission denied" in str(e):
                        print "WRPCOPY_FILES:F:GERR_0206:Permission denied for the user :" + target_host + "_" + t_app_sid + "_" + re_execute
			log4erp.write(log, t_app_sid + ":F:Permission denied for the user " + target_user + ":" + t_app_sid)
                else:
                        print "WRPCOPY_FILES:F: " + str(e) + ":" + target_host + "_" + t_app_sid 
	#		log4erp.write(log, t_app_sid + ":F: " + str(e) + ":" + t_app_sid)

