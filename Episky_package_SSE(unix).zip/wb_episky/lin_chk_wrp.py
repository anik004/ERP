from __future__ import division
from paramiko import *
import paramiko
from sys import *
import subprocess
from threading import Thread
import time
import log4erp
from log4erp import *

def check(t_host, t_user, t_password, app_sid, t_db_sid, file_init, string1, path, folder_path, logfile, log, db_type,t_osname):
    try:

        string1 = string1.lower()
        command = "python "+ path +"/lin58.py " + t_host + " " + app_sid + " "+logfile+" "+log
	print command
	log4erp.write(logfile,command)
        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        out, err = command.communicate()
        print "WRP" + str(out)
	status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
        if status == "P":
            command = "python "+ path +"/lin64.py " + t_host + " " + t_user + " " + t_password + " " + app_sid + " " + string1 +" "+ logfile + " " + log + " " + t_db_sid + " " + db_type
	    print command
	    log4erp.write(logfile,command)
            command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
            out, err = command.communicate()
            print "WRP" + str(out)
	    status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
            if status == "P" and string1.lower() != "db":
                command = "python " + path + "/lin52.py " + t_host + " " + t_user + " " + t_password + " "+ file_init +" " + string1 + " " + app_sid +" "+ folder_path +" "+ logfile+ " " +log+ " " + t_db_sid + " " + db_type + " " + t_osname
	        print command
		log4erp.write(logfile,command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                print "WRP" + str(out)
		status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
                if status == "P" and string1.lower() != "db":
                    command = "python "+ path + "/lin61.py " + t_host + " " + t_user + " " + t_password + " " + string1+" "+app_sid+ " "+logfile+ " " +log
		    print command
		    log4erp.write(logfile,command)
                    command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                    out, err = command.communicate()
                    print "WRP" + str(out)
                    print "WRP:P:Check module for target server " + t_host + " has been completed"
    except Exception as e:
        print "CHECK_KERNEL:F: " + str(e)
try:
                       t_host = argv[1]
                       t_user = argv[2]
                       t_passwd = argv[3]
                       t_appsid = argv[4]
                       t_db_sid = argv[5]
                       file_init = argv[6]
                       logfile = "Check_log.log"
                       t_string = argv[8]
                       log = "EpiskyClient_log.log"
                       path = argv[9].rstrip('/')
		       folder_path = path.rstrip()+ '/files'
		       db_type = argv[10]
		       t_osname = argv[11]

	               check(t_host, t_user, t_passwd, t_appsid, t_db_sid, file_init, t_string, path, folder_path,logfile,log,db_type,t_osname)
except Exception as e:
    print "WRPCHECK_KERNEL:F:" + str(e)
    log4erp.write(log,"WRPCHECK_KERNEL:F:" + str(e))
