from __future__ import division
from sys import *
import paramiko
from paramiko import *
import subprocess
import os
from subprocess import *
import log4erp
from log4erp import *
from threading import Thread
import time


def ker(t_host, t_user, t_passwd, t_app_sid, t_db_sid, ai_ci_db, t_kernelpath, scriptloc, k_id, db_type, ker_refid, t_osname, folder_path, re_execute,logfile1,logfile2,step_name,opt_ker):
	try:

		path_exist = os.path.isdir(scriptloc)
	        if "False" in str(path_exist):
        		print 'WRPSTOPSAPDEP:F:Script location ( ' + scriptloc + ' ) is incorrect : ' + t_host + "_" + t_app_sid.upper() + "_" + step_name
            		exit()

		sol_osname = os.name
		if sol_osname.lower() == "nt":
			if t_osname.lower() == "windows" :
				path = scriptloc.rstrip('\\')
				command = "c:\\python27\\python.exe " + path + "\win67 " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_kernelpath + " " + scriptloc + " " + k_id + " " + ker_refid + " " + folder_path + " " + re_execute + " " + logfile1 + " " + logfile2
				write(logfile1,command)
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				out = out.split('\n')
				output = ''
				for i in out:
					if i.strip():
						output = output + i.strip() + '\n'
						print output.strip()


	
		elif sol_osname.lower() == "posix":
			if t_osname.lower() == "windows":
				path = scriptloc.rstrip('/')
				command = "python " + path + "/lwin67 " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_kernelpath + " " + scriptloc + " " + k_id + " " + ker_refid + " " + folder_path + " " + re_execute + " " + logfile1 + " " + logfile2
				write(logfile1, command)
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				print out.strip() + ":" + step_name

			elif t_osname.lower() == "redhat" or t_osname.lower() == "aix" or t_osname.lower() == "suse_linux":
				path = scriptloc.rstrip('/')
				logfille1 = path + "/" + ker_refid + "_log.log"
				command = "python " + path + "/lin_upgrd_wrp.py "  + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_db_sid + " " + k_id + " " + logfile1+ " " + ai_ci_db + " " + path + " " + ker_refid + " " + re_execute + " " + db_type + " " + opt_ker
			
				print command
				write(logfile1,command)
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                                out, err = command.communicate()
                                print out.strip() + ":" + step_name
			else:
				print "WRPKERNEL_UPGRADE:F:Script not found for the OS (" + t_osname.upper() + "):" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
			 	write(logfile1, "KERNEL_UPGRADE:F:Script not found for the OS (" + t_osname.upper() + "):"+ t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name)
		

		else:
			print "WRPKERNEL_UPGRADE: F: script not found :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
			write(logfile1, "KERNEL_UPGRADE: F: script not found")

	except Exception as e:
		if str(e) == "[Errno -2] Name or service not known":
			print "WRPKERNEL_UPGRADE:F:GERR_0201:Hostname unknown :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
		elif str(e).strip() == "list index out of range":
			print "WRPKERNEL_UPGRADE:F:GERR_0202:Argument/s missing for the script"
		elif str(e) == "Authentication failed.":
			print "WRPKERNEL_UPGRADE:F:GERR_0203:Authentication failed. :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
		elif str(e) == "[Errno 110] Connection timed out":
			print "WRPKERNEL_UPGRADE:F:GERR_0204:Host Unreachable :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
		elif "getaddrinfo failed" in str(e):
			print "WRPKERNEL_UPGRADE:F:GERR_0205: Please check the hostname that you have provide :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
		elif "[Errno None] Unable to connect to port 22" in str(e):
			print "WRPKERNEL_UPGRADE:F:GERR_0206:Host Unreachable or Unable to connect to port 22 :" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
		else:
			print "WRPKERNEL_UPGRADE:F: " + str(e) + ":" + t_host + "_" + t_app_sid + "_" + re_execute + ":" + step_name
			write(logfile1, "KERNEL_UPGRADE:F: " + str(e))

try:

	file_path = argv[1]
	error_code = argv[2].split("_")
	e_host = error_code[0]
	e_sid = error_code[1]
	re_execute = error_code[2]
	step_name = argv[3]

	f = open(file_path, 'r')
	content = f.read()

	if re_execute == "0":
		arg_string = ""
		for line in content.split():
			arg_string = arg_string + "|" + line

		arg_string = arg_string.replace("|", " ")
		arg_string = arg_string.lstrip()
		argv = arg_string.split(" ")
		count = len(argv)
		arg = 18
		a = 0
		index_number = ""
		if count % arg == 0:
			count = (count / arg)
			count = int(count)
			if count >= 1:
				arr = ''	
				for i in range(0, count - 1):
					host = argv[18*i+0]
					user = argv[18*i+1]
					passwd = argv[18*i+2]
					app_sid = argv[18*i+3]
					scriptloc = argv[18*i+6]
					t_osname = argv[18*i+7]
					ai_ci_db = argv[18*i+14]
					kernel_path = argv[18*i+5]
					command = "python " + scriptloc + "/dummy_file.py " + host + " " + user + " " + passwd + " " + app_sid + " " + t_osname + " " + ai_ci_db +" " + kernel_path
					print command
                                	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                                	out, err = command.communicate()
					status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
					print status
				
					if status == 'P':
						j = 18*i
						arr = arr + ',' + str(j)

			arr = (arr.strip(',')).split('\n')
			index_number = arr[0].split(',')
			index_number = map(int,index_number)
			if len(index_number) == 0:
				print "WRPKERNEL_UPGRADE:F: Delete ker_file.txt from kernel location"
				exit()
			for index in index_number:
				hostname = argv[index]
				username = argv[index+1]
				password = argv[index+2]
				appsid = argv[index+3].upper()
				dbsid = argv[index+4].upper()
				kernel_path = argv[index+5]
				scriptloc = argv[index+6].rstrip('\\')
				t_osname = argv[index+7].lower()
				k_id = argv[index+8]
				ker_refid = argv[index+9]
				db_type = argv[index+13]
				ai_ci_db = argv[index+14]
				print ai_ci_db
				#sys_type = argv[index+10]  # ABAP/JAVA
				opt_ker = argv[index+17]
				logfile1 = scriptloc + "/" + ker_refid + "_log.log"
				logfile2 = scriptloc + "/" + "EpiskyClient_log.log"

				folder_path = scriptloc + "\\files"
				if ai_ci_db.upper() == "DB":
                                        write(logfile1, "No Kernel upgrade for db")
                                else:
                                        thread = Thread(target=ker, args=(hostname, username, password, appsid, dbsid, ai_ci_db, kernel_path, scriptloc, k_id, db_type, ker_refid, t_osname, folder_path, re_execute,logfile1,logfile2, step_name, opt_ker))
                                        thread.start()
                                        time.sleep(10)
				command = "python " + scriptloc + "/delete_dummy_file.py " + host + " " + user + " " + passwd + " " + app_sid + " " + t_osname + " " + ai_ci_db +" " + kernel_path
				print command
				command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
				out, err = command.communicate()
				print out
						

			


		else:
			"WRPKERNEL_UPGRADE:F:argument/s missing "


	if re_execute != "0":
		f = open(file_path, 'r')
		content = f.read()

		for line in content.split():
			if e_sid in line and e_host in line:
				line = line.replace("|", " ")
				line = line.split(" ")
				t_host = line[0]
				t_user = line[1]
				t_passwd = line[2]
				t_app_sid = line[3].lower()
				t_db_sid = line[4].lower()
				t_kernelpath = line[5]
				scriptloc = line[6].rstrip('\\')
				t_osname = line[7]
				k_id = line[8]
				ker_refid = line[9]
				db_type = line[13]
				ai_ci_db = line[14]
				#sys_type = line[10]
				opt_ker = line[17]
				logfile1 = scriptloc + "/" + ker_refid + "_log.log"
				folder_path = scriptloc + "\\files"
				logfile2 = scriptloc + "/" + "EpiskyClient_log.log"

				if ai_ci_db.upper() == "DB":
                                        write(logfile1, "No Kernel upgrade for hana db")
				else:
					ker(t_host, t_user, t_passwd, t_app_sid, t_db_sid, ai_ci_db, t_kernelpath, scriptloc, k_id, db_type, ker_refid, t_osname, folder_path, re_execute,logfile1,logfile2, step_name, opt_ker)
					break

except Exception as e:
	print "WRPKERNEL_UPGRADE:F: " + str(e)
