from __future__ import division
from paramiko import *
import paramiko
from sys import *
import subprocess
from subprocess import *
import log4erp
from log4erp import *
from threading import Thread
import time


def check(t_host, t_user, t_passwd, t_app_sid, t_db_sid, t_in_id, t_file, logfile, t_string, path, log, ker_ref, re_execute, db_type, opt_ker):
    try:
	if re_execute == "0":
        	command = "python " + path + "/lin50.py " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_db_sid + " " + t_string + " " + logfile + " " + log + " " + ker_ref + " " + re_execute
		print command
	        write(logfile,command)
	        command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	        out, err = command.communicate()
	#	print out
	        status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
	#	print status
        	if status == "P":
			print out
	                re_execute = "1"
		else:
			print out
	                exit()
	if re_execute == "1":
		command = "python " + path + "/lin53.py " + t_host + " " + t_in_id + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_db_sid + " " + t_string + " " + t_file + " " + logfile + " " +log + " " + re_execute + " " + opt_ker + " " + path
		print command
		write(logfile,command)
        	command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		out, err = command.communicate()
		status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]	
		if status == "P":
                        print out
                        re_execute = "2"
		else:
			print out
			exit()

	if re_execute == "2":
                command = "python " + path  + "/lin57.py " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_db_sid + " " + t_in_id + " " + t_string + " " + logfile + " " + log + " " + ker_ref + " " + re_execute
		print command
		write(logfile,command)
                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
                out, err = command.communicate()
                status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
                if status == "P":
			print out
                        re_execute = "3"
			print "WRPKERNELEXTRACTION:P: KERNEL UPGRADE has been completed successfully : " + t_host + "_" + t_app_sid.upper() + "_" + re_execute

		else:
			print out
                        exit()

#	if re_execute == "3":
#	                command = "python " + path + "/lin60.py " + t_host + " " + t_user + " " + t_passwd + " " + t_app_sid + " " + t_db_sid + " " + t_string + " " + logfile + " " +log + " " + re_execute + " " + db_type
#			print command
#			write(logfile,command)
#	                command = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
 #       	        out, err = command.communicate()
  #              	status = (out.split('\n')[len(out.split('\n')) - 2]).split(':')[1]
            #   if status == "P":
	#		print "WRPKERNELEXTRACTION:P: KERNEL UPGRADE has been completed successfully : " + t_host + "_" + t_app_sid.upper() + "_" + re_execute



    except Exception as e:
        print "WRPKU:F:" + str(e) + " :" + t_host + "_" + t_app_sid.upper() + "_" + re_execute
	write(log, t_app_sid + ':F:' + str(e))

try:

	        	t_host = argv[1]
		        t_user = argv[2]
                	t_passwd = argv[3]
		        t_app_sid = argv[4]
                	t_db_sid = argv[5]
		        t_in_id = argv[6]
                	logfile = argv[7]
		        t_string = argv[8] 
			ker_ref = argv[10]
			log = "EpiskyClient_log.log"
			path = argv[9].rstrip('/')
			seq_no = argv[11]
			t_file = path+'/files'
			db_type = argv[12]
			opt_ker = argv[13]

		        check(t_host, t_user, t_passwd, t_app_sid, t_db_sid, t_in_id, t_file, logfile, t_string, path, log, ker_ref, seq_no, db_type, opt_ker)
	        	
			

except Exception as e:
    print str(e) + " :" + t_host + "_" + t_app_sid.upper() + "_" + seq_no
